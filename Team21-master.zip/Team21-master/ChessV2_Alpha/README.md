# Team21
Welcome to Panda Chess!    

Authors: Team Panda-emic Programmers  
1. Onis Tripathi 
2. Christina Wong 
3. Chi-Yuan (George) Ting
4. Gianna Calderon Fortu 
5. Michael Choi 

Version: 1.0   
Date: 05/31/21 

This is the second version of the Panda Chess software. 
To run our game, simply follow the instructions in our INSTALL file. 
General instructions and rules of the game are stated in the user manual. 

