/*********************************************************************/
/* Board.c                                                           */
/* C file for board structure                                        */ 
/*                                                                   */
/* Authors: Christina Wong                                           */ 
/*          Michael Choi                                             */
/* Modifications:                                                    */
/* 04/25/21 MC  removed player parameter from CreateBoard            */
/* 04/24/21 CW  added comments and retouched some functions          */
/* 04/23/21 CW  initial version                                      */
/*********************************************************************/

#include "Board.h"

//Returns the pointer to the board
BOARD *CreateBoard(char board[8][8], int precol, int prerow, int postcol, int postrow, int ai)
{
    BOARD *newboard;                            //creates a new board pointer
    
    //calloc() allocates memory and intializes values to 0 (using for 2D array in struct)
    //newboard = calloc(1, sizeof(newboard)); 
    
    newboard = malloc(sizeof(BOARD));

    //checking if there's enough memory
    if(!newboard)
    {
        perror("Out of memory! Aborting... ");
        exit(10);
    }
    newboard->precol = (char)(precol + 65);
    newboard->prerow = (char)(56 - prerow);
    newboard->postcol = (char)(postcol + 65);
    newboard->postrow = (char)(56 - postrow);
    newboard->player = ai;

    for (int x = 0; x < 8; x++){
        for (int y = 0; y < 8; y++){
            newboard->newboard[x][y] = board[x][y];
        }
    }
    
    return newboard;
}

//Free memory for values in BOARD struct
void DeleteBoard(BOARD *newboard)
{
    //checking if board exists
    if (!newboard)
    {
        perror("board doesn't exist... ");
        exit(10);
    }
    
    free(newboard);
}

//allocate memory for a new board entry
ENTRY *NewBoardEntry(BOARD *newboard)
{
    ENTRY *entry;                               //creates a new entry pointer
    entry = calloc(1, sizeof(ENTRY));
    
    //checking if there's enough memory
    if (!entry)
    {
        perror("Out of memory! Aborting... ");
        exit(10); 
    }
    
    entry->List = NULL;
    entry->Next = NULL;
    entry->Prev = NULL;
    entry->board = newboard;
    return entry;
}

//deletes a board entry 
BOARD *DeleteBoardEntry(ENTRY *entry)
{
    //checking if entry exists 
    if (!entry)
    {
        perror("entry doesn't exist... ");
        exit(10);
    }
    
    BOARD *n;                                   //creates a new pointer 
    n = entry->board;                           //n holds value of board 
    free(entry);
    return n;
}

//allocates memory for a new board list
LIST *NewBoardList(void)
{
    LIST *list;                                 //creates a new list pointer
    list = calloc(1, sizeof(LIST));

    //checking if there's enogh memory
    if (!list)
    {
        perror("Out of memory! Aborting... ");
        exit(10);
    }
    
    list->Length = 0;
    list->First = NULL;
    list->Last = NULL;  
    
    return list;
}

//deletes entire list of boards 
void DeleteBoardList(LIST *list){
    //checking if list exists 
    if (!list)
    {
        perror("list doesn't exist... ");
        exit(10);
    }
    
    ENTRY *entry, *n;                           //creates new entry pointers
    BOARD *newboard;                            //creates a new board pointer
    
    entry = list->First;                        //look at first board 
    while(entry){                               //while there is still an entry in the list, run
        n = entry->Next;                        //set n as the next entry
        newboard = DeleteBoardEntry(entry);     //sets newboard to the board you are looking at 
        DeleteBoard(newboard);                  //deletes board
        entry = n;                              //entry is now the next board in list
    }                                           //continue until there are no more entries
    free(list);
}

//append a board at the end of the list 
void AppendBoard(LIST *list, BOARD *newboard){
    //checking if list exists 
    if (!list)
    {
        perror("list doesn't exist... ");
        exit(10);
    }
    //checking if newboard exists
    if (!newboard)
    {
        perror("board doesn't exist... ");
        exit(10);
    }
    
    ENTRY *entry;                               //creates a new entry pointer
    
    entry = NewBoardEntry(newboard);            //create a new entry with the board already created 
    if(list->Last)                              //if there are more than one entries in list existing already (not first entry of list)
    {                       
        entry->List = list;                     //put entry in list
        entry->Next = NULL;                     //NULL bc new entry is the last entry 
        entry->Prev = list->Last;               //set this entry's prev to what used to be the last entry in list
        list->Last->Next = entry;               //previous entry's next is now current entry 
        list->Last = entry;                     //last entry is now the current entry 
    }
    else                                        //if this is the first entry of the list...
    {
        entry->List = list;                     //put entry in list
        entry->Next = NULL;                     //bc it's the only entry in list
        entry->Prev = NULL;                     //bc it's the only entry in list
        list->First = entry;                    //entry is first entry 
        list->Last = entry;                     //entry is also last entry 
    }
    list->Length++;                             //adding an entry increases length pf list by 1
}

//removes the last board from the list 
BOARD *RemoveLastBoard(LIST *list){
    //checking if list exists 
    if (!list)
    {
        perror("list doesn't exist... ");
        exit(10);
    }
    
    ENTRY *entry;                               //creates a new entry pointer
    
    if(list->Last)                              //if there is an entry in list...
    {
        entry = list->Last;                     //entry points at last board entry in list 
        list->Last = entry->Prev;               //last item of list is now the previous entry 
        if(list->Last)                          //if previous entry exists...
        {
            list->Last->Next = NULL;            //set previous entry's next to NULL (no more entries after) 
        }
        else                                    //if there's no previous entry...
        {   
            list->First = NULL;                 //set first entry to NULL (no entries left in list)
        }
        list->Length--;                         //removing entry decreases length of list by 1
        return DeleteBoardEntry(entry);         //delete current board entry 
    }
    else                                        //if there are no entries in list...
    {
        return(NULL);                           //do nothing (bc there's no board to remove)
    }
}

BOARD *aitakeback(BOARD *newboard, LIST *list, char board[8][8]) {

	int count = 0;

	if (list->Last->board){
		RemoveLastBoard(list);
		RemoveLastBoard(list);
		newboard = list->Last->board;
		for (int x =0; x < 8; x++)
		{
			for (int y=0; y < 8; y++){
				board[x][y] = newboard->newboard[x][y];
				count++;
			}
		}
	}
	return newboard;
}

BOARD *humtakeback(BOARD *newboard, LIST *list, char board[8][8]) {

	int count = 0;

	if (list->Last->board){
		RemoveLastBoard(list);
		newboard = list->Last->board;
		for (int x =0; x < 8; x++)
		{
			for (int y=0; y < 8; y++){
				board[x][y] = newboard->newboard[x][y];
				count++;
			}
		}
	}
	return newboard;
}


/* EOF */

