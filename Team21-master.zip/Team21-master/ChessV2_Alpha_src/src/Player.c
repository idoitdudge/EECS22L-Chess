/*********************************************************************/
/* Player.c                                                          */
/* C file for player structure                                       */ 
/*                                                                   */
/* Authors: Christina Wong                                           */
/* Modifications:                                                    */
/* 04/24/21 CW  fixed error message                                  */
/* 04/23/21 CW  initial version                                      */
/*********************************************************************/

#include "Board.h"

//Return the pointer to the player
PLAYER *CreatePlayer(int pnum, char pcolor, int points)
{
    PLAYER *player;
    player = malloc(sizeof(PLAYER));

    //checking if there's enough memory 
    if(!player)
    {
        perror("Out of memory! Aborting... ");
        exit(10);
    }

    player->pnum = pnum;
    player->pcolor = pcolor;
    player->points = points;
    return player;
}

//Free memory for values in PLAYER struct 
void DeletePlayer(PLAYER *player)
{
    free(player);
}

/* EOF */
