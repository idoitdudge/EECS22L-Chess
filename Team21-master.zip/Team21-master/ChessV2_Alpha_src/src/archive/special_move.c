/* en passant

int check_en_passant(char board [8][8], int turn, int w_premove_row, int w_premove_col, int w_postmove_row, int w_postmove_col, int b_premove_row, int b_premove_col, int b_postmove_row, int b_postmove_col)
{
	int n; //for loop counter
	
	if (turn==1)//*****white move*****b
	{
		for(n=0; n<8; n++)
		{
			if(b_premove_row==1 && b_premove_col==n && b_postmove_row==3 && b_postmove_col==n)//check condition if black moved pawn 2 squares up
			{
				if(w_premove_row==3 && (w_premove_col==n+1 || w_postmove_col==n+1) && w_postmove_row==2 && w_postmove_col=n) //if white inputs right coordinate
				{
					board[2][n] = 'p'
					board[3][n] = ' '
				}
			}
		}
	}
	
	
	 if (turn == 2)//*****black move*****
	 {
		for(n=0; n<8; n++)
		{
			if(w_premove_row==6 && w_premove_col==n && w_postmove_row==4 && w_postmove_col==n)//check condition if white moved pawn 2 squares up
			{
				if(b_premove_row==4 && (b_premove_col==n+1 || b_postmove_col==n+1) && b_postmove_row==5 && b_postmove_col=n) //if white inputs right coordinate
				{
					board[6][n] = 'P'
					board[5][n] = ' '
				}
			}
		}
	 }
}















*/
fff
/*
int check_castle(char board [8][8], int turn, int premove_row, int premove_col, int postmove_row, int postmove_col)
{	//*****white move*****
	if (turn==1)
	{
		//king castle for white
		if (board[premove_row][premove_col]=='k' && board[7][7]=='r' && board[postmove_row][postmove_col]== ' ' && board[7][5]== ' ' )
		{//condition if if statement check if the inbetween places are empty
			board[7][5] = 'r'
			board[postmove_row][postmove_col]== 'k'
		}	
		//queen castle for white
		if (board[premove_row][premove_col]=='k' && board[7][0]=='r' && board[postmove_row][postmove_col]== ' ' && board[7][3]== ' ' && board[7][1]==' ')
		{//condition if if statement check if the inbetween places are empty
			board[7][3] = 'r'
			board[postmove_row][postmove_col]== 'k'
		}

	}

	//*****black move*****
	if (turn == 2)
	{
		 
		if (board[premove_row][premove_col]=='k' && board[0][7]=='r' && board[postmove_row][postmove_col]== ' ' && board[0][5]== ' ' )
		{//condition if if statement check if the inbetween places are empty
			board[0][5] = 'r'
			board[postmove_row][postmove_col]== 'k'
		}	

		if (board[premove_row][premove_col]=='k' && board[0][0]=='r' && board[postmove_row][postmove_col]== ' ' && board[0][3]== ' ' && board[0][1]==' ')
		{//condition if if statement check if the inbetween places are empty
			board[0][3] = 'r'
			board[postmove_row][postmove_col]== 'k'
		}	
	 }
}
	

*/







