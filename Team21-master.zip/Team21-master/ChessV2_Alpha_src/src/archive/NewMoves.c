/*********************************************************************/
/* Moves.c                                                           */
/* functions for legal moves for chess pieces                        */
/*                                                                   */
/* Authors: Chih-Yuan Ting, Christina Wong, Michael Choi             */
/* Modifications:                                                    */
/* 04/29/21 MC   added WinCheck and isCheck                          */
/* 04/26/21 CW   fixed some errors                                   */
/* 04/26/21 CW   added comments and converter for columns            */ 
/* 04/26/21 CYT  initial version                                     */
/*********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "Board.h"     
#include "Moves.h"

int CheckMove (char board [8][8], int turn, int row1, int col1, int row2, int col2){
	// WHITE MOVES 
    if (turn == 1){  
		// *************** GENERAL INPUT CHECKS ***************
		// if new location is the same spot, don't move
	    if (row2 == row1 && col2 == col1)
		    return 0;
	
	    // if new location is outside of board 
	    if (row2 > 7 || row2 < 0 || col2 > 7 || col2 < 0)
		    return 0;
		
		// *************** WHITE PAWN MOVES ***************
		// WHITE pawns' first move
		if (row1 == 6 && board[row1][col1] == 'p'){
			// move 2 up ---------------------------------------------- move 1 up
			if ((row2 == row1 - 2 && board[row2][col2] == ' ') || (row2 == row1 - 1 && board[row2][col2] == ' '))
				return 1;
			else
				return 0;
		}	
		// general white pawn move (after first move)
	    else if (row1 != 6 && board[row1][col1] == 'p')
        {
		    if (row2 == row1 - 1 && board[row2][col2] == ' ')
			    return 1;
		    else
			    return 0;
	    }
		// taking a piece
	    else if ((board[row2][col2] != ' ' && row2 == row1 - 1 && col2 == col1 - 1) || 
				 (board[row2][col2] != ' ' && row2 == row1 - 1 && col2 == col1 + 1))  // checks left then right (front only)
		    return 1;
	    else
		    return 0;
		
		//rook move 
	    if (board[row1][col1] == 'r' || board[row1][col1] == 'R')
        {
		    for (int i = 0; i < 8; i++){
			    if ((col2 == col1 && row2 == row1 + i) || (row2 == row1 && col2 == col1 + i) || (col2 == col1 && row2 == row1 - i) || (row2 == row1 && col2 == col1 - i))
				    return 1;
		    }
		    return 70;
	    }

//
	    //knight move
	    if (board [row1][col1] == 'h' || board[row1][col1] == 'H')
        {
		    if ((row2 == row1 + 2 && col2 == col1 + 1) || (row2 == row1 + 2 && col2 == col1 - 1) || (row2 == row1 - 2 && col2 == col1 + 1) || (row2 == row1 - 2 && col2 == col1 - 1) || (row2 == row1 + 1 && col2 == col1 + 2) || (row2 == row1 - 1 && col2 == col1 + 2) || (row2 == row1 + 1 && col2 == col1 - 2) || (row2 == row1 - 1 && col2 == col1 - 2))
			    return 1;
		    else 
			    return 80;
	    }   

//	
	    // bishop move
	    if (board[row1][col1] == 'b' || board[row1][col1] == 'B')
        {
		    for (int i = 0; i < 8; i++)
            {
			    if ((row2 == row1 + i && col2 == col1 + i) || (row2 == row1 + i && col2 == col1 - i) || (row2 == row1 - i && col2 == col1 + i) || (row2 == row1 - i && col2 == col1 - i))
				    return 1;
		    }
		    return 90;
	    }

//	
	    // king move
	    if (board[row1][col1] == 'k' || board[row1][col1] == 'K')
        {
		    if ((row2 == row1 + 1 && col2 == col1 + 1) || (row2 == row1 - 1 && col2 == col1 + 1) || (row2 == row1 + 1 && col2 == col1 - 1) || (row2 == row1 - 1 && col2 == col1 - 1) || (row2 == row1 && col2 == col1 + 1) || (row2 == row1 && col2 == col1 - 1) || (row2 == row1 + 1 && col2 == col1) || (row2 == row1 - 1 && col2 == col1))
			    return 1;
		    else
			    return 100;
	    }
	
//
	    //queen move
	    if (board[row1][col1] == 'q' || board[row1][col1] == 'Q')
        {
		    for (int i = 0; i < 8; i++)
            {
			    if ((row2 == row1 + i && col2 == col1 + i) || (row2 == row1 + i && col2 == col1 - i) || (row2 == row1 - i && col2 == col1 + i) || (row2 == row1 - i && col2 == col1 - i) || (col2 == col1 && row2 == row1 + i) || (row2 == row1 && col2 == col1 + i) || (col2 == col1 && row2 == row1 - i) || (row2 == row1 && col2 == col1 - i))
		    		return 1;
		    }
		    return 110;
	    }
	}

	// BLACK MOVES
	if (turn == 2){
		// *************** GENERAL INPUT CHECKS ***************
		// if new location is the same spot, don't move
	    if (row2 == row1 && col2 == col1)
		    return 20;
	
	    // if new location is outside of board 
	    if (row2 > 7 || row2 < 0 || col2 > 7 || col2 < 0)
		    return 30;
		
		// *************** BLACK PAWN MOVES ***************
		// black pawns' first move
	    if (row1 == 1 && board[row1][col1] == 'P'){
			// move 2 down ---------------------------------------------- move 1 down
            if ((row2 == row1 + 2 && board[row2][col2] == ' ') || (row2 == row1 + 1 && board[row2][col2] == ' '))
                return 1;
            else
                return 40;
        }
	    // general black pawn move (after first move)
        else if (row1 != 1 && board[row1][col1] == 'P'){
            if (row2 == row1 + 1 && board[row2][col2] == ' ')
                return 1;
            else
      		    return 50;
  	    }
        // taking a piece
        else if ((board[row2][col2] != ' ' && row2 == row1 + 1 && col2 == col1 + 1) || 
				 (board[row2][col2] != ' ' && row2 == row1 + 1 && col2 == col1 - 1)) // checks left then right (front only)
            return 1;
        else
            return 60;
		
		 //rook move 
	    if (board[row1][col1] == 'r' || board[row1][col1] == 'R')
        {
		    for (int i = 0; i < 8; i++){
			    if ((col2 == col1 && row2 == row1 + i) || (row2 == row1 && col2 == col1 + i) || (col2 == col1 && row2 == row1 - i) || (row2 == row1 && col2 == col1 - i))
				    return 1;
		    }
		    return 70;
	    }

//
	    //knight move
	    if (board [row1][col1] == 'h' || board[row1][col1] == 'H')
        {
		    if ((row2 == row1 + 2 && col2 == col1 + 1) || (row2 == row1 + 2 && col2 == col1 - 1) || (row2 == row1 - 2 && col2 == col1 + 1) || (row2 == row1 - 2 && col2 == col1 - 1) || (row2 == row1 + 1 && col2 == col1 + 2) || (row2 == row1 - 1 && col2 == col1 + 2) || (row2 == row1 + 1 && col2 == col1 - 2) || (row2 == row1 - 1 && col2 == col1 - 2))
			    return 1;
		    else 
			    return 80;
	    }   

//	
	    // bishop move
	    if (board[row1][col1] == 'b' || board[row1][col1] == 'B')
        {
		    for (int i = 0; i < 8; i++)
            {
			    if ((row2 == row1 + i && col2 == col1 + i) || (row2 == row1 + i && col2 == col1 - i) || (row2 == row1 - i && col2 == col1 + i) || (row2 == row1 - i && col2 == col1 - i))
				    return 1;
		    }
		    return 90;
	    }

//	
	    // king move
	    if (board[row1][col1] == 'k' || board[row1][col1] == 'K')
        {
		    if ((row2 == row1 + 1 && col2 == col1 + 1) || (row2 == row1 - 1 && col2 == col1 + 1) || (row2 == row1 + 1 && col2 == col1 - 1) || (row2 == row1 - 1 && col2 == col1 - 1) || (row2 == row1 && col2 == col1 + 1) || (row2 == row1 && col2 == col1 - 1) || (row2 == row1 + 1 && col2 == col1) || (row2 == row1 - 1 && col2 == col1))
			    return 1;
		    else
			    return 100;
	    }
	
//
	    //queen move
	    if (board[row1][col1] == 'q' || board[row1][col1] == 'Q')
        {
		    for (int i = 0; i < 8; i++)
            {
			    if ((row2 == row1 + i && col2 == col1 + i) || (row2 == row1 + i && col2 == col1 - i) || (row2 == row1 - i && col2 == col1 + i) || (row2 == row1 - i && col2 == col1 - i) || (col2 == col1 && row2 == row1 + i) || (row2 == row1 && col2 == col1 + i) || (col2 == col1 && row2 == row1 - i) || (row2 == row1 && col2 == col1 - i))
		    		return 1;
		    }
		    return 110;
	    }
    }
}	
		
		
		
		
		