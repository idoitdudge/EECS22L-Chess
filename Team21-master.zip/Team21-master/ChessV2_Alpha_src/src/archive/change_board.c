change( int return_col , int return_row , int go_to_col , int go_to_column )
{
    char temp ;

    temp = board[return_col][return_row] ;
    board[return_row][return_col] = board[go_to_col][go_to_column] ;
    board[go_to_col][go_to_row] = temp ;

}
