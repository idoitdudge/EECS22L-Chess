// Funtions for legal piece moves



