/*********************************************************************/
/* Data Structures                                                   */
/*                                                                   */
/* Authors: Onis Tripathi                                            */
/* Modifications:                                                    */
/* 04/19/21 OT  started board structures                             */
/*********************************************************************/

enum {white,
      black,
      both }; //for pawn to determine if any on the spot

enum { file_a, file_b, file_c, file_d, file_e, file_f, file_G, file_h, file_empty };
enum { rank_1, rank_2, rank_3, rank_4, rank_5, rank_6, rank_7, rank_8, rank_empty };


typedef unsigned long long U64;



 which_piece
{
    w_pawn=-6
    w_rook=-5;
    w_horse=-4;
    w_bishop=-3;
    w_king=-2;
    w_queen=-1;
    empty_spot=0;
    b_queen=1;
    b_king=2;
    b_bishop=3;
    b_horse=4;
    b_rook=5;
    b_pawn=6;
};

int board_1[120] = 
{
empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, 
empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, 
empty_spot, b_rook,     b_horse,    b_bishop,   b_queen,    b_king,     b_bishop,   b_horse,    b_rook,     empty_spot,
empty_spot, b_pawn,     b_pawn,     b_pawn,     b_pawn,     b_pawn,     b_pawn,     b_pawn,     b_pawn,     empty_spot,
empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, 
empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, 
empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, 
empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, 
empty_spot, w_pawn,     w_pawn,     w_pawn,     w_pawn,     w_pawn,     w_pawn,     w_pawn,     w_pawn,     empty_spot,
empty_spot, w_rook,     w_horse,    w_bishop,   w_queen,    w_king,     w_bishop,   w_horse,    w_rook,     empty_spot,
empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, 
empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, empty_spot, 
};

int board_2[120] = {
     -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
     -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
     -1,  0,  1,  2,  3,  4,  5,  6,  7, -1,
     -1,  8,  9, 10, 11, 12, 13, 14, 15, -1,
     -1, 16, 17, 18, 19, 20, 21, 22, 23, -1,
     -1, 24, 25, 26, 27, 28, 29, 30, 31, -1,
     -1, 32, 33, 34, 35, 36, 37, 38, 39, -1,
     -1, 40, 41, 42, 43, 44, 45, 46, 47, -1,
     -1, 48, 49, 50, 51, 52, 53, 54, 55, -1,
     -1, 56, 57, 58, 59, 60, 61, 62, 63, -1,
     -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
     -1, -1, -1, -1, -1, -1, -1, -1, -1, -1
};


enum {
  a1 = 21, b1, c1, d1, e1, f1, g1, h1,
  a2 = 31, b2, c2, d2, e2, f2, g2, h2,
  a3 = 41, b3, c3, d3, e3, f3, g3, h3,
  a4 = 51, b4, c4, d4, e4, f4, g4, h4,
  a5 = 61, b5, c5, d5, e5, f5, g5, h5,
  a6 = 71, b6, c6, d6, e6, f6, g6, h6,
  a7 = 81, b7, c7, d7, e7, f7, g7, h7,
  a8 = 91, b8, c8, d8, e8, f8, g8, h8, 
  nonw
};
















