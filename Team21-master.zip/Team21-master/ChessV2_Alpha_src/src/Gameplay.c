/*********************************************************************/
/* Gameplay.c                                                        */
/* functions for gameplay                                            */ 
/*                                                                   */
/* Authors: Christina, Michael, Gianna                               */
/* Modifications:           					                     */
/* 05/09/21 CW  fixed implementation of castling and GUI             */ 
/* 05/09/21 CW  changed input format and added exit function         */
/* 05/08/21 MC  fixed input issue                                    */
/* 05/06/21 CW  fixed AI function                                    */
/* 05/02/21 GF	New AI function                                      */
/* 05/01/21 CW  remodeled HvH function to work properly              */
/* 05/01/21 CW  black pieces can move!                               */
/* 04/29/21 MC  added checks for win condition                       */
/* 04/27/21 CW  added color and formatting                           */
/* 04/26/21 MC  Added to HumanVsHuman function                       */
/* 04/26/21 GF  Added to HumanVsHuman function                       */
/* 04/25/21 CW  implemented new player struct to fix errors          */
/* 04/25/21 GF  HumanVsHuman outline                                 */
/* 04/25/21 GF  Added to HumanVsHuman function                       */
/* 04/24/21 CW  initial version                                      */
/*********************************************************************/

#include "BoardFunctions.h"     
#include "Moves.h"

// debugger tool
#define cat(x) # x
#define stringify(x) cat(x)
#define debugf(msg, ...) {\
    printf("\x1b[1;31mDEBUG [L " stringify(__LINE__) "]: " msg "\n\x1b[0m", ##__VA_ARGS__);\
}

// This function prints the board 
void print_board(char board[8][8]){
    int i, j, k;
	
	printf("\n"); // formatting
	
    for(k = 0; k < 8; k++){
        printf("  "); // leave space for vertical indeces
    
        // prints a set of dash lines (row separation)
        for(i = 0; i < 33; i++){ 
            printf("-"); 
        } 
        printf("\n"); 
        
        int a = 8;
        // printf("%d ", k + 1);  // prints vertical indeces from 1-8
        printf("%d ", a - k); // prints vertical indeces from 8-1 
        
        // prints character at the location with adjacent borders
        for(j = 0; j < 8; j++){
            if (j % 2 == 0){
                if (k % 2 != 0)
                    printf("|\x1b[1;37;5;40m %c \x1b[0m", board[k][j]); // white font, black background
                else 
                    printf("|\x1b[1;37;5;44m %c \x1b[0m", board[k][j]); // black font, white background
            }else{
                if (k % 2 == 0)
                    printf("|\x1b[1;37;5;40m %c \x1b[0m", board[k][j]); // white font, black background
                else 
                    printf("|\x1b[1;37;5;44m %c \x1b[0m", board[k][j]); // black font, white background
            }
        }
        printf("| \n");
    }

    printf("  "); // formatting of last line of dashes
    
    // prints last line of dashes 
    for(i = 0; i < 33; i++){ 
        printf("-"); 
    }
    printf("\n ");

    // prints horizontal indeces A-H 
    for(i = 65; i < 73; i++){
        printf("   %c", i);
    }
    printf("\n\n");
}

// game points addition function
void gamepoints(char board[8][8], int turn, int postmove1, int postmove2,  PLAYER *player1, PLAYER *player2) {
	
	if (turn == 1) {	
	if (player1->pcolor == 'b') {
		switch (board[postmove1][postmove2]){
			case 'p':
				player1->points += 10;
				break;
			case 'n': 
				player1->points += 30;
				break;
			case 'b':
				player1->points += 30;
				break;
			case 'r':
				player1->points += 50;
				break;
			case 'q':
				player1->points += 90;
				break;
			case 'k':
				player1->points += 900;
				break;
			default:
				player1->points += 0;
				break;
		}	
	}
	else if (player1->pcolor == 'w') {
	
		switch (board[postmove1][postmove2]){
			case 'P': 
				player1->points += 10;
				break;
			case 'N':
				player1->points += 30;
				break;
			case 'B':
				player1->points += 30;
				break;
			case 'R':
				player1->points += 50;
				break;
			case 'Q':
				player1->points += 90;
				break;
			case 'K':
				player1->points += 900;
				break;
			default:
				player1->points += 0;
				break;
		}
	}
	}

	else if (turn == 2) {	
	if (player2->pcolor == 'b') {
		switch (board[postmove1][postmove2]){
			case 'p':
				player2->points += 10;
				break;
			case 'n': 
				player2->points += 30;
				break;
			case 'b':
				player2->points += 30;
				break;
			case 'r':
				player2->points += 50;
				break;
			case 'q':
				player2->points += 90;
				break;
			case 'k':
				player2->points += 900;
				break;
			default:
				player2->points += 0;
				break;
		}	
	}
	else if (player2->pcolor == 'w') {
	
		switch (board[postmove1][postmove2]){
			case 'P': 
				player2->points += 10;
				break;
			case 'N':
				player2->points += 30;
				break;
			case 'B':
				player2->points += 30;
				break;
			case 'R':
				player2->points += 50;
				break;
			case 'Q':
				player2->points += 90;
				break;
			case 'K':
				player2->points += 900;
				break;
			default:
				player2->points += 0;
				break;
		}
	}
	}
}

// Human vs. Human gameplay 
void HumanVsHuman(char board[8][8], PLAYER *player1, PLAYER *player2){

    time_t start_time, end_time;
    double time_elapsed;

    int winner = 0; // temporary win condition
    type("\n\x1b[1;34mHuman vs. Human Game Started!\x1b[0m\n", 0.075); 
		
	int turn = 1;   // checks which player's turn it is
	
	// switches color if user chooses to change colors 
	if (player1->pcolor == 'b')
        turn = 2; // change player number to set move limitations

    // *** moves variables ***
    // white current location
    char wprecol;       // white's current column
    int wprecol_con = 0;    // column ASCII conversion
    char wprerow;       // white's current row
    int wprerow_con = 0;    // row ASCII conversion 

    // white post location
    char wpostcol;      // white's post column
    int wpostcol_con = 0;   // column ASCII conversion
    char wpostrow;      // white's post row
    int wpostrow_con = 0;   // row ASCII conversion 

    // black current location
    char bprecol;       // white's current column
    int bprecol_con = 0;    // column ASCII conversion
    char bprerow;       // white's current row
    int bprerow_con = 0;    // row ASCII conversion 

    // black post location
    char bpostcol;      // white's post column
    int bpostcol_con = 0;   // column ASCII conversion
    char bpostrow;      // white's post row
    int bpostrow_con = 0;   // row ASCII conversion 

    // variables for checking conditions
    char side;
    int legal = 0;      // check general legality
    int samecolor = 0;     // check if same color
    int block = 0;     // check if anything's samecoloring
    int castle = 0;     // checks for castling

    char tempval;       // temp holder when making a move
    int firstmove = 1;

    LIST *list = NewBoardList();
    BOARD *newboard = CreateBoard(board, 0, 0, 0, 0, 0); // first board, no moves made
    AppendBoard(list, newboard);
    int win = 0;

    char tempboard[8][8]; // holds starting board values (mostly to implement custom board)
    for (int i = 0; i < 8; i++){
        for (int j = 0; j < 8; j++){
            tempboard[i][j] = board[i][j];
        }
    }

   	while (winner == 0){   
        int exit = 0;

		// *************** WHITE's turn ***************
        while (turn == 1){   
			print_board(board);
	    
            time(&start_time);   // puts current time into start_time 

            // take in player's move 
            printf("Enter \x1b[1;31mQUIT\x1b[0m to exit out of the game. \n");
            printf("Enter \x1b[1;34mBACK\x1b[0m to take back your last move. \n"); // take back
            printf("Enter \x1b[1;34mCAST\x1b[0m for castling. \n");                             
//            printf("Enter \x1b[1;34mPASSANT\x1b[0m for el passant");                             
	
            printf("\nYou have \x1b[4;36m60\x1b[0m seconds to complete your turn.\n");
            printf("\x1b[36mWhite, please pick your move (i.e. A2A3):\x1b[0m ");
	        scanf(" %c %c %c %c", &wprecol, &wprerow, &wpostcol, &wpostrow);
            getchar();

            if ((wprecol == 'B' && wprerow == 'A' && wpostcol == 'C' && wpostrow == 'K') ||
                (wprecol == 'b' && wprerow == 'a' && wpostcol == 'c' && wpostrow == 'k')){
                if(!firstmove){
                    humtakeback(newboard, list, board);
                    break;            
                }else{
                    printf("\x1b[1;31mAlready at beginning! Can't take back move!\x1b[0m\n");
                    printf("\x1b[36mWhite, please pick your move (i.e. A2A3):\x1b[0m ");
	                scanf(" %c%c%c%c", &wprecol, &wprerow, &wpostcol, &wpostrow);
                    getchar();
                }
            }

            // check for exit game code
            if ((wprecol == 'Q' && wprerow == 'U' && wpostcol == 'I' && wpostrow == 'T') ||
                (wprecol == 'q' && wprerow == 'u' && wpostcol == 'i' && wpostrow == 't')){
                exit = 1;
                break;
            }    	        
            else if (wprecol == 'C' && wprerow == 'A' && wpostcol == 'S' && wpostrow == 'T'){
                printf("\nEnter 'L' or 'R' to castle left or right...\n");
                scanf("%c", &side);
                getchar();
            }
            else{
                // conversions
                wprecol_con = ((int) wprecol) - 65;		        // convert current column from char into int (ASCII)
                wprerow_con = 8 - (((int) wprerow) - 48);	    // convert current row to reflect wanted row (ASCII)
                wpostrow_con = 8 - (((int) wpostrow) - 48);	    // convert new row to reflect wanted row (ASCII)
                wpostcol_con = ((int) wpostcol) - 65;       	// convert new column from char into int (ASCII)
            }
 
            // check if move is legal
			// UPDATE: added "turn" parameter to track player number
	        if (wprecol == 'C' && wprerow == 'A' && wpostcol == 'S' && wpostrow == 'T')
               	castle = Castling (board, turn, side);

            else{
                legal = CheckMove(board, turn, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con);
               	samecolor = SameColor(board, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con);
               	block = BlockingPiece(board, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con);
			    castle = 1;
           	}
			
            // debugger lines
            //debugf("Legal? Here's what's happening: %d %d %d %d", legal, samecolor, block, castle);
            //debugf("\nTurn: %d", turn);
            
            while (legal != 1 || samecolor != 1 || block != 1 || castle != 1){
                printf("Illegal move, please try again\n"); 
                printf("\x1b[36mWhite, please pick your move (i.e. A2A3):\x1b[0m ");
	            scanf(" %c%c%c%c", &wprecol, &wprerow, &wpostcol, &wpostrow);
                getchar();

                if ((wprecol == 'B' && wprerow == 'A' && wpostcol == 'C' && wpostrow == 'K') ||
                    (wprecol == 'b' && wprerow == 'a' && wpostcol == 'c' && wpostrow == 'k')){
                    if(!firstmove){
                        humtakeback(newboard, list, board);
                        break;            
                    }else{
                        printf("\x1b[1;31mAlready at beginning! Can't take back move!\x1b[0m\n");
                        printf("\x1b[36mWhite, please pick your move (i.e. A2A3):\x1b[0m ");
                        scanf(" %c%c%c%c", &wprecol, &wprerow, &wpostcol, &wpostrow);
                        getchar();
                    }
                }

                // check for exit game code
                if ((wprecol == 'Q' && wprerow == 'U' && wpostcol == 'I' && wpostrow == 'T') ||
                    (wprecol == 'q' && wprerow == 'u' && wpostcol == 'i' && wpostrow == 't')){
                    exit = 1;
                    break;
                }
                else if (wprecol == 'C' && wprerow == 'A' && wpostcol == 'S' && wpostrow == 'T'){
                    printf("\nEnter 'L' or 'R' to castle left or right...\n");
                    scanf("%c", &side);
                    getchar();
                }
                else {
                    wprecol_con = ((int) wprecol) - 65;		        // convert current column from char into int (ASCII)
                    wprerow_con = 8 - (((int) wprerow) - 48);	    // convert current row to reflect wanted row (ASCII)
                    wpostrow_con = 8 - (((int) wpostrow) - 48);	    // convert new row to reflect wanted row (ASCII)
                    wpostcol_con = ((int) wpostcol) - 65;	        // convert new column from char into int (ASCII)
                }

                // check if move is legal
		        if (wprecol == 'C' && wprerow == 'A' && wpostcol == 'S' && wpostrow == 'T')
                    castle = Castling (board, turn, side);

		        else{
                    legal = CheckMove(board, turn, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con);
                    samecolor = SameColor(board, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con);
                    block = BlockingPiece (board, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con);
                    castle = 1;
                }
			    //debugf("Legal? Here's what's happening: %d %d %d %d", legal, samecolor, block, castle);
                //debugf("\nTurn: %d", turn);
            
   		    } 
            
            if(exit == 1) break;
    
			if (legal == 1 && samecolor == 1 && block == 1 && castle == 1){
                if (wprerow != 'A' && wpostrow != 'T'){
		            //if (board [wprerow_con][wprecol_con] == 'p')
                            //	WhitePawnPromotion (board, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con);
			    tempval = board[wprerow_con][wprecol_con]; 
		            board[wpostrow_con][wpostcol_con] = tempval; // moves piece to new location and captures if there's a piece already there
		            board[wprerow_con][wprecol_con] = ' '; // set old location to blank 
 			        // check = 0; //move has been made 
 			    for (int i = 0; i < 8; i++){
                        	if (board [0][i] == 'p')
                                	WhitePawnPromotion (board, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con);}
                }
   
                time(&end_time); // initialize end_time

                time_elapsed = difftime(end_time, start_time); // if time elapsed is more than 30s, black wins and game terminates
                if (time_elapsed > 60)
                {
                    printf("\nYou ran out of time, white, black wins\n");
                    win = 2;
                    exit = 1;	
                    break;
                }

                int wincheck = WinCheck(board, turn + 1);
                //debugf(" %d", wincheck);
                // add points function here:
			    gamepoints(board, 1, wpostrow_con, wpostcol_con, player2, player1); 
			    printf("\tPlayer 1 Points: %d \n", player1->points);
			    printf("\tPlayer 2 Points: %d \n", player2->points);

                // check win condition function 
                if(wincheck == 1){
                    print_board(board);
                    newboard = CreateBoard(board, bprecol_con, bprerow_con, bpostcol_con, bpostrow_con, 1);
                    AppendBoard(list, newboard);
                    printf("\x1b[1;34mPlayer %d Wins!\x1b[0m\n", turn);
                    win = 1;
                    //debugf(" %d", wincheck);
                    winner = 1;
                    break;
                }else{
                    //debugf(" %d", wincheck);
                    newboard = CreateBoard(board, bprecol_con, bprerow_con, bpostcol_con, bpostrow_con, 1);
                    AppendBoard(list, newboard);
                    printf("\n");
                    turn++;  // move has been made & no win --> player 2's turn
                }
            }
            firstmove = 0;
        }
        if(exit == 1) break;       
 
        // *************** BLACK's turn ***************
        while(turn == 2){
            print_board(board);
	       
            time(&start_time);   
            //take in player's move
            printf("Enter \x1b[1;31mQUIT\x1b[0m to exit out of the game. \n");
            printf("Enter \x1b[1;34mBACK\x1b[0m to take back your last move. \n"); // take back
            printf("Enter \x1b[1;34mCAST\x1b[0m for castling. \n");
            printf("\nYou have \x1b[4;36m60\x1b[0m seconds to complete your turn.\n");
  	        printf("\x1b[36mBlack, please pick your move (i.e. A2A3):\x1b[0m "); // take in player's move
	        scanf(" %c%c%c%c", &bprecol, &bprerow, &bpostcol, &bpostrow);
	        getchar();

            if ((bprecol == 'B' && bprerow == 'A' && bpostcol == 'C' && bpostrow == 'K') ||
                (bprecol == 'b' && bprerow == 'a' && bpostcol == 'c' && bpostrow == 'k')){
                if(!firstmove){
                    humtakeback(newboard, list, board);
                    break;            
                }else{
                    printf("\x1b[1;31mAlready at beginning! Can't take back move!\x1b[0m\n");
                    printf("\x1b[36mBlack, please pick your move (i.e. A2A3):\x1b[0m ");
	                scanf(" %c%c%c%c", &bprecol, &bprerow, &bpostcol, &bpostrow);
                    getchar();
                }
            }

            // check for exit game code
            if ((bprecol == 'Q' && bprerow == 'U' && bpostcol == 'I' && bpostrow == 'T') ||
                (bprecol == 'q' && bprerow == 'u' && bpostcol == 'i' && bpostrow == 't')){
                exit = 1; 
                break;            
            }
            else if (bprecol == 'C' && bprerow == 'A' && bpostcol == 'S' && bpostrow == 'T'){
                printf("\nEnter 'L' or 'R' to castle left or right...\n");
                scanf("%c", &side);
                getchar();
            }
            else {
                // conversions
                bprecol_con = ((int) bprecol) - 65;             // convert input char into int (ASCII)
                bprerow_con = 8 - (((int) bprerow) - 48);       // convert current row to reflect wanted row (ASCII)
                bpostrow_con = 8 - (((int) bpostrow) - 48);     // convert new row to reflect wanted row (ASCII)
                bpostcol_con = ((int) bpostcol) - 65;           // convert input char into int (ASCII)
            }

            // check if move is legal
            if (bprecol == 'C' && bprerow == 'A' && bpostcol == 'S' && bpostrow == 'T')
                castle = Castling (board, turn, side);
            else{
                legal = CheckMove(board, turn, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);
                samecolor = SameColor(board, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);
                block = BlockingPiece (board, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);
                castle = 1;
            }
            //debugf("Legal? Here's what's happening: %d %d %d %d", legal, samecolor, block, castle);
            //debugf("\nTurn: %d", turn);

			int exit = 0;
            while (legal != 1 || samecolor != 1 || block != 1 || castle != 1){
                printf("Illegal move, please try again\n"); 
                printf("\x1b[36mBlack, please pick your move (i.e. A2A3):\x1b[0m ");
	            scanf(" %c%c%c%c", &bprecol, &bprerow, &bpostcol, &bpostrow);
                getchar();

                if ((bprecol == 'B' && bprerow == 'A' && bpostcol == 'C' && bpostrow == 'K') ||
                    (bprecol == 'b' && bprerow == 'a' && bpostcol == 'c' && bpostrow == 'k')){
                    if(!firstmove){
                        humtakeback(newboard, list, board);
                        break;            
                    }else{
                        printf("\x1b[1;31mAlready at beginning! Can't take back move!\x1b[0m\n");
                        printf("\x1b[36mBlack, please pick your move (i.e. A2A3):\x1b[0m ");
                        scanf(" %c%c%c%c", &bprecol, &bprerow, &bpostcol, &bpostrow);
                        getchar();
                    }
                }
                // check for exit game code
                if ((bprecol == 'Q' && bprerow == 'U' && bpostcol == 'I' && bpostrow == 'T') ||
                    (bprecol == 'q' && bprerow == 'u' && bpostcol == 'i' && bpostrow == 't')){
                    exit = 1; 
                    break;            
                }
                else if (bprecol == 'C' && bprerow == 'A' && bpostcol == 'S' && bpostrow == 'T'){
                    printf("\nEnter 'L' or 'R' to castle left or right...\n");
                    scanf("%c", &side);
                    getchar();
                }
                else {
                    // conversions
                    bprecol_con = ((int) bprecol) - 65;             // convert input char into int (ASCII)
                    bprerow_con = 8 - (((int) bprerow) - 48);       // convert current row to reflect wanted row (ASCII)
                    bpostrow_con = 8 - (((int) bpostrow) - 48);     // convert new row to reflect wanted row (ASCII)
                    bpostcol_con = ((int) bpostcol) - 65;           // convert input char into int (ASCII)
                }

                // check if move is legal
                if (bprecol == 'C' && bprerow == 'A' && bpostcol == 'S' && bpostrow == 'T')
                    castle = Castling (board, turn, side);
		        else{
                    legal = CheckMove(board, turn, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);
                    samecolor = SameColor(board, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);
                    block = BlockingPiece (board, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);
                    castle = 1;
                }
                //debugf("Legal? Here's what's happening: %d %d %d %d", legal, samecolor, block, castle);
                //debugf("\nTurn: %d", turn);
            }

            if(exit == 1) break;

	        if (legal == 1 && samecolor == 1 && block == 1 && castle == 1){
                if (bprerow != 'A' && bpostrow != 'T'){
                    //if (board [bprerow_con][bprecol_con] == 'P')
                      //  BlackPawnPromotion (board, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);
		    tempval = board[bprerow_con][bprecol_con];
                    board[bpostrow_con][bpostcol_con] = tempval;
                    board[bprerow_con][bprecol_con] = ' ';
		    for (int i = 0; i < 8; i++){
                        if (board[7][i] == 'P')
                                BlackPawnPromotion (board, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);}
                } 

                time(&end_time);

                time_elapsed= difftime(end_time, start_time); // if time elapsed is more than 30s, black wins and game terminates
                if (time_elapsed>30)//i put 30 seconds to make move but easier to check with 3
                {
                    printf("\nYou ran out of time black, white wins!\n");
                    win = 1;
                    exit = 1;
                    break;	
                }

                int wincheck = WinCheck(board, turn - 1);
                //debugf(" %d", wincheck);

                // update points
                gamepoints(board, 2, bpostrow_con, bpostcol_con, player1, player2);
		        printf("\tPlayer 1 Points: %d \n", player1->points);
		        printf("\tPlayer 2 Points: %d \n", player2->points);

                // check win condition function 
                if(wincheck == 1){
                    print_board(board);
                    newboard = CreateBoard(board, bprecol_con, bprerow_con, bpostcol_con, bpostrow_con, 1);
                    AppendBoard(list, newboard);
                    printf("\x1b[1;34mPlayer %d Wins!\x1b[0m\n", turn);
                    //debugf(" %d", wincheck);
                    win = 2;
                    winner = 1; 
                    break;
                }else{
                    //debugf(" %d", wincheck);
                    printf("\n");
                    newboard = CreateBoard(board, bprecol_con, bprerow_con, bpostcol_con, bpostrow_con, 1);
                    AppendBoard(list, newboard);
                    turn--; // white's turn next 
                }
            }
            firstmove = 0;
        }
        if(exit == 1) break;
        
    }  
    //if(exit == 1)
      //  win = 0;
    Replay(list, player1, player2, 0, win); 
    DeleteBoardList(list);
    DeletePlayer(player1);
    DeletePlayer(player2);
    
    // set board back to starting positions
    for (int i = 0; i < 8; i++){
        for (int j = 0; j < 8; j++){
            board[i][j] = tempboard[i][j];
        }
    }

    printf("\nThanks for playing! Returning to main menu");
    type(".....\n", 0.3); 
}

void HumanVsAI(char board[8][8], PLAYER *player1, PLAYER *player2){
	
    //int first = 0;
    int winner = 0; // temporary win condition

    time_t start_time, end_time;
    double time_elapsed;

    type("\n\x1b[1;34mHuman vs. AI Game Started!\x1b[0m\n", 0.075); 
		
	int turn = 1;   // checks which player's turn it is
	
	// switches color if user chooses to change colors 
	if (player1->pcolor == 'b')
		turn = 2; // change player number to set move limitations                 
    
	// *** moves variables ***
    // white current location
    char wprecol;       // white's current column
    int wprecol_con = 0;    // column ASCII conversion
    char wprerow;       // white's current row
    int wprerow_con = 0;    // row ASCII conversion 

    // white post location
    char wpostcol;      // white's post column
    int wpostcol_con = 0;   // column ASCII conversion
    char wpostrow;      // white's post row
    int wpostrow_con = 0;   // row ASCII conversion 

    // black current location
    //char bprecol;       // white's current column
    int bprecol_con = 0;    // column ASCII conversion
    int bprerow_con = 0;    // row ASCII conversion 

    // black post location
    int bpostcol_con = 0;   // column ASCII conversion
    int bpostrow_con = 0;   // row ASCII conversion 

    // variables for checking conditions
    char side;
    int legal = 0;      // check general legality
    int samecolor = 0;     // check if same color
    int block = 0;     // check if anything's samecoloring
    int castle = 0;	// check if castling is allowed
    
    char tempval;       // temp holder when making a move
    int firstmove = 1;
    //int counter = 0;    // used for testing                         (DELETE LATER)

    LIST *list = NewBoardList();
    BOARD *newboard = CreateBoard(board, 0, 0, 0, 0, 0); // first board, no moves made
    AppendBoard(list, newboard);
    int win = 0;

    char tempboard[8][8]; // holds starting board values (mostly to implement custom board)
    for (int i = 0; i < 8; i++){
        for (int j = 0; j < 8; j++){
            tempboard[i][j] = board[i][j];
        }
    }

   	while (winner == 0){   
        int exit = 0;
		// *************** WHITE's turn ***************
        while (turn == 1){   
			print_board(board);
            time(&start_time); 

            // take in player's move 
            printf("Enter \x1b[1;31mQUIT\x1b[0m to exit out of the game. \n"); // quit game
	        printf("Enter \x1b[1;34mCAST\x1b[0m for castling. \n"); // castling
            printf("Enter \x1b[1;34mBACK\x1b[0m to take back your last move. \n"); // take back

            printf("\nYou have \x1b[4;36m60\x1b[0m seconds to complete your turn.\n");
            printf("\x1b[36mWhite, please pick your move (i.e. A2A3):\x1b[0m ");
	        scanf(" %c%c%c%c", &wprecol, &wprerow, &wpostcol, &wpostrow);
            getchar();

            if ((wprecol == 'B' && wprerow == 'A' && wpostcol == 'C' && wpostrow == 'K') ||
                     (wprecol == 'b' && wprerow == 'a' && wpostcol == 'c' && wpostrow == 'k')){
                if(!firstmove){
                    aitakeback(newboard, list, board);
                    break;            
                }else{
                    printf("\x1b[1;31mAlready at beginning! Can't take back move!\x1b[0m\n");
                    printf("\x1b[36mWhite, please pick your move (i.e. A2A3):\x1b[0m ");
	                scanf(" %c%c%c%c", &wprecol, &wprerow, &wpostcol, &wpostrow);
                    getchar();
                }
            }

			// check for exit game code
			if ((wprecol == 'Q' && wprerow == 'U' && wpostcol == 'I' && wpostrow == 'T') ||
                (wprecol == 'q' && wprerow == 'u' && wpostcol == 'i' && wpostrow == 't')){
                exit = 1;   
                break;          
            }

			else if ((wprecol == 'C' && wprerow == 'A' && wpostcol == 'S' && wpostrow == 'T') ||
                     (wprecol == 'c' && wprerow == 'a' && wpostcol == 's' && wpostrow == 't')){
                printf("\nEnter 'L' or 'R' to castle left or right...\n");
                scanf("%c", &side);
                getchar();
            }
            else{
                // conversions
                wprecol_con = ((int) wprecol) - 65;		// convert current column from char into int (ASCII)
                wprerow_con = 8 - (((int) wprerow) - 48);	    // convert current row to reflect wanted row (ASCII)
                wpostrow_con = 8 - (((int) wpostrow) - 48);	// convert new row to reflect wanted row (ASCII)
                wpostcol_con = ((int) wpostcol) - 65;	// convert new column from char into int (ASCII)
            }
 
            // check if move is legal
	        if (wprecol == 'C' && wprerow == 'A' && wpostcol == 'S' && wpostrow == 'T')
                castle = Castling (board, turn, side);
	        else{
	    	    legal = CheckMove(board, turn, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con); 
            	samecolor = SameColor(board, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con);
            	block = BlockingPiece (board, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con); 
                castle = 1;
	        }
            // debugger lines
            //debugf("Legal? Here's what's happening: %d %d %d %d", legal, samecolor, block, castle);
            //debugf("\nTurn: %d\n Premove: row: %d   col: %c concol: %d\n Postmove: row: %d   col: %c concol: %d", 
                //    turn, wprerow_con, wprecol, wprecol_con, wpostrow_con, wpostcol, wpostcol_con);
            

            while (legal != 1 || samecolor != 1 || block != 1 || castle != 1){
                printf("Illegal move, please try again\n"); 
                printf("\x1b[36mWhite, please pick your move (i.e. A2A3):\x1b[0m ");
	            scanf(" %c%c%c%c", &wprecol, &wprerow, &wpostcol, &wpostrow);
                getchar();
                
                if ((wprecol == 'B' && wprerow == 'A' && wpostcol == 'C' && wpostrow == 'K') ||
                         (wprecol == 'b' && wprerow == 'a' && wpostcol == 'c' && wpostrow == 'k')){
                    if(!firstmove){
                        aitakeback(newboard, list, board);
                        break;            
                    }else{
                        printf("\x1b[1;31mAlready at beginning! Can't take back move!\x1b[0m\n");
                        printf("\x1b[36mWhite, please pick your move (i.e. A2A3):\x1b[0m ");
                        scanf(" %c%c%c%c", &wprecol, &wprerow, &wpostcol, &wpostrow);
                        getchar();
                    }
                }

                // check for exit game code
                if ((wprecol == 'Q' && wprerow == 'U' && wpostcol == 'I' && wpostrow == 'T') ||
                    (wprecol == 'q' && wprerow == 'u' && wpostcol == 'i' && wpostrow == 't')){
                    exit = 1;
                    break;           
                }
                else if (wprecol == 'C' && wprerow == 'A' && wpostcol == 'S' && wpostrow == 'T'){
                	printf("\nEnter 'L' or 'R' to castle left or right...\n");
                	scanf("%c", &side);
                	getchar();
            	} 
                else{
                    wprecol_con = ((int) wprecol) - 65;		        // convert current column from char into int (ASCII)
                    wprerow_con = 8 - (((int) wprerow) - 48);	    // convert current row to reflect wanted row (ASCII)
                    wpostrow_con = 8 - (((int) wpostrow) - 48);	    // convert new row to reflect wanted row (ASCII)
                    wpostcol_con = ((int) wpostcol) - 65;	        // convert new column from char into int (ASCII)
                }

                // check if move is legal
                if (wprecol != 'C' && wprerow != 'A' && wpostcol != 'S' && wpostrow != 'T'){    
                    legal = CheckMove(board, turn, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con);  
                    samecolor = SameColor(board, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con);
                    block = BlockingPiece (board, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con);
                    castle = 1;
                }
                else if (wprecol == 'C' && wprerow == 'A' && wpostcol == 'S' && wpostrow == 'T')
                    castle = Castling (board, turn, side);		
                //debugf("Legal? Here's what's happening: %d %d %d %d", legal, samecolor, block, castle);
                //debugf("\nTurn: %d", turn);
            }

            if(exit == 1) break;

            if (legal == 1 && samecolor == 1 && block == 1 && castle == 1){
                if (wprerow != 'A'  && wpostrow != 'T'){
		    tempval = board[wprerow_con][wprecol_con]; 
                    board[wpostrow_con][wpostcol_con] = tempval; // moves piece to new location and captures if there's a piece already there
                    board[wprerow_con][wprecol_con] = ' '; // set old location to blank 
                    // check = 0; //move has been made 
                    for (int i = 0; i < 8; i++){
                        if (board [0][i] == 'p')
                                WhitePawnPromotion (board, wprerow_con, wprecol_con, wpostrow_con, wpostcol_con);}
                    
                }

                time(&end_time); // initialize end_time

                time_elapsed = difftime(end_time, start_time); // if time elapsed is more than 30s, black wins and game terminates
                if (time_elapsed > 60)
                {
                    printf("\nYou ran out of time, white, black wins\n");
                    win = 2;
                    exit = 1;
                    break;	
                }

                int wincheck = WinCheck(board, turn + 1);
                //debugf(" %d", wincheck);
                // add points function here:
			    gamepoints(board, 1, wpostrow_con, wpostcol_con, player2, player1); 
			    printf("\tPlayer 1 Points: %d \n", player1->points);
			    printf("\tPlayer 2 Points: %d \n", player2->points);
	
                // check win condition function 
                if(wincheck == 1){
                    print_board(board);
                    newboard = CreateBoard(board, bprecol_con, bprerow_con, bpostcol_con, bpostrow_con, 1);
                    AppendBoard(list, newboard);
                    printf("\x1b[1;34mPlayer %d Wins!\x1b[0m\n", turn);
                    //debugf(" %d", wincheck);
                    win = 1;
                    winner = 1; 
                    break;
                }else{
                    //debugf(" %d", wincheck);
                    newboard = CreateBoard(board, bprecol_con, bprerow_con, bpostcol_con, bpostrow_con, 1);
                    AppendBoard(list, newboard);
                    printf("\n");
                    turn++; // black's turn next 
                }
            }
            firstmove = 0;	
        }
        
        if(exit == 1) break;

        // *************** BLACK's turn ***************
        while(turn == 2){
            print_board(board);

            srand(time(0));
			
            // Basic AI : will choose random coordinates until legal one is found
			printf("AI is making its move...\n");
			// randomgen produces a random integer between 1-8 
			int find = 0;
			int first = 0;
			//int find2 = 0;
			
			// loop will run until black piece is found 
		    while(find == 0){	
				bprerow_con = rand()%8;        // generates random numbers (1-8) for starting/ending rows & columns 
                bprecol_con = rand()%8;
                bpostrow_con = rand()%8;
                bpostcol_con = rand()%8;
		   
				tempval = board[bprerow_con][bprecol_con];   // stores current location's character
 
		        // checks if coordinate is a black piece

		        if (first == 0) {	// error checking for first move
	    	    	if (tempval == 'P' || tempval == 'N') {
	    	    		find = 1;
	    	    		first = 1;
	    	    	}
    		    	else {
    			    	find = 0;
  		        	}
	        	}				           
	        	else  if (first == 1) {	// second move and on 
		        	if(tempval == 'K' || tempval == 'Q' || tempval == 'R' || tempval == 'P' || tempval == 'N' || tempval == 'B') {
		    			find = 1;   // move is found
    
                      //debugf("PRE: row %d column %d", bprecol_con, bprerow_con);
                      //debugf("POST: row %d column %d", bpostcol_con, bpostrow_con);
			    	}
    	    	}
	            else {
			       find = 0;  // move is not found
		    	} 
			}
           
            //debugf("find: %d , tempval: %c ", find, tempval); // debugger to see what value find and tempval is
            
            // check if move is legal
            legal = CheckMove(board, turn, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);
            samecolor = SameColor(board, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);
          	block = BlockingPiece (board, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);
			 
            // debugger lines **********
            //debugf("Legal? Here's what's happening: %d %d %d", legal, samecolor, block);
            //debugf("\nTurn: %d", turn);
            //debugf("PRE: row %d column %d", bprecol_con, bprerow_con);
            //debugf("POST: row %d column %d", bpostcol_con, bpostrow_con);
            //debugf("tempval: %c ", tempval);
 		
	        // not sure if this loop is needed for AI?, probably needs to be updated     
	        // UPDATE: definitely need it to regenerate new location and check it after      
            while (legal != 1 || samecolor != 1 || block != 1){
                bpostrow_con = rand()%8;
				bpostcol_con = rand()%8;
			
		    	legal = CheckMove(board, turn, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);
			    samecolor = SameColor(board, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);
          	    block = BlockingPiece (board, bprerow_con, bprecol_con, bpostrow_con, bpostcol_con);

                // debugger lines
                //debugf("Legal? Here's what's happening: %d %d %d", legal, samecolor, block);
                //debugf("\nTurn: %d", turn);
                //debugf("PRE: row %d column %d", bprecol_con, bprerow_con);
                //debugf("POST: row %d column %d", bpostcol_con, bpostrow_con);

            }

	        if (legal == 1 && samecolor == 1 && block == 1){
		        // update game points 
                gamepoints(board, turn, bpostrow_con, bpostcol_con, player1, player2);
                printf("\tPlayer 1 Points: %d \n", player1->points);
                printf("\tPlayer 2 Points: %d \n", player2->points);

                // update board function
		        tempval = board[bprerow_con][bprecol_con];
		        board[bpostrow_con][bpostcol_con] = tempval;
		        board[bprerow_con][bprecol_con] = ' '; 
                //check = 0;

                int wincheck = WinCheck(board, turn - 1);
                //debugf(" %d", wincheck);

                // check win condition function 
                if(wincheck == 1){
                    print_board(board);
                    newboard = CreateBoard(board, bprecol_con, bprerow_con, bpostcol_con, bpostrow_con, 1);
                    AppendBoard(list, newboard);
                    printf("\x1b[1;34mPlayer %d Wins!\x1b[0m\n", turn);
                    win = 2;
                    //debugf(" %d", wincheck);
                    winner = 1;
                    break;
                }else{
                    //debugf(" %d", wincheck);
                    newboard = CreateBoard(board, bprecol_con, bprerow_con, bpostcol_con, bpostrow_con, 1);
                    AppendBoard(list, newboard);
                    printf("\n");
                    turn--;  // white's turn
                }
            }
        }
        
    } 
    //if(exit == 1) 
      //  win = 0;
    Replay(list, player1, player2, 1, win);
    DeleteBoardList(list);
    DeletePlayer(player1);
    DeletePlayer(player2);

    // set board back to starting positions
    for (int i = 0; i < 8; i++){
        for (int j = 0; j < 8; j++){
            board[i][j] = tempboard[i][j];
        }
    }

    printf("\nThanks for playing! Returning to main menu");
    type(".....\n", 0.3); 
}









