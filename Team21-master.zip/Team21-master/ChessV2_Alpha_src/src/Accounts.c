/* File for account logins and creation */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define clear printf("\e[1;1H\e[2J")
struct account {
	char username[10];
	char password[10];
//	char name[20];
	char username2[10];
	char password2[10];
};

void login(void);
void registering(void);

void login(void){

	char username[10];
	char password[10];

	FILE *accountlog;

	accountlog = fopen("accountlogin.txt", "r");
	
	if (accountlog == NULL) {
		fputs("Error", stderr);
		exit(1);
	}

	struct account a;
	printf("------\n");
	printf("LOGIN \n");
	printf("------\n");

	printf("Username: ");
//	fgets(username, 10, stdin);
	scanf("%s", &username);
	printf("Password: ");
	scanf("%s", &password);

	while (fread(&a, sizeof(a),1,accountlog)){
		if(strcmp(username, a.username) ==0 && strcmp(password, a.password)==0){
			printf("------------------\n");
			printf("Login Successful! \n");
		}
		else {
			printf("Login Failure, Please Try Again \n");
		}
	}
	fclose(accountlog);
	return;
}

void registering(void){
	
//	char name[20];
	FILE *accountlog;

	accountlog = fopen("accountlogin.txt", "w");
	if (accountlog == NULL) {
		fputs("Error", stderr);
		exit(1);
	}
	struct account a;
	printf("----------------\n");
	printf("ACCOUNT CREATION\n");
	printf("----------------\n");
//	printf("Enter First Name: \n");
//	scanf("%c", a.name);
	
	printf("Enter Username: \n");
	scanf("%s", a.username);
	

	printf("Enter Password: \n");	
	scanf("%s", a.password);
	

	fwrite(&a, sizeof(a),1,accountlog);	
	fclose(accountlog);

	printf("-----------------------\n");
	printf("Registration Complete! \n");
	printf("Welcome %s! \n", a.username);
	printf("-----------------------\n");
	printf("Press the Enter Key to Continue \n");
		getchar();

	clear;
//	system("cls");
//	login();

}

int main (void){

	int choice;
	printf("Enter 1 to Login, 2 to Register \n");
	scanf("%d", &choice);

	getchar();

	if (choice == 2) {
		clear;
		registering();
		login();
	}
	else if (choice == 1) {
		clear;
		login();
	}
}
