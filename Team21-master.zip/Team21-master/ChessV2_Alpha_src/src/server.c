/* server.c */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include <time.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <assert.h>
#include "Chess.h"

// type definitions
typedef void (*ClientHandler)(int DataSocketFD); //  
typedef void (*TimeoutHandler)(void); // variable used in parameter of ServerMainLoop as a function caller (calls )

// global variables
const char *Program = NULL; // program name for descriptive diagnostics
int Shutdown = 0; // keep running until Shutdown == 1
char ClockBuffer[26] = ""; // current time in printable format

/*** global functions ****************************************************/

/* prints error diagnostics and abort */
void FatalError(const char *ErrorMsg){ 
	// stderr = standard error message
	fputs(Program, stderr); // adding program name to error message
	fputs(": ", stderr); // adding :
	perror(ErrorMsg); // error message (what's wrong)
	fputs(Program, stderr); 
	fputs(": Exiting!\n", stderr);
	exit(20);
} /* end of FatalError */

/* creates a socket on this server */
int MakeServerSocket(uint16_t PortNo){ 
    int ServSocketFD;
    struct sockaddr_in ServSocketName;

    ServSocketFD = socket(PF_INET, SOCK_STREAM, 0); // creates socket 
    if (ServSocketFD < 0){   
        FatalError("service socket creation failed");
    }
    
    /* bind the socket to this server */
    ServSocketName.sin_family = AF_INET; // connects server to internet domain
	ServSocketName.sin_port = htons(PortNo); // sets server to specified port number
	ServSocketName.sin_addr.s_addr = htonl(INADDR_ANY); // sets server to an unspecified host server
	
   // bind(): binds socket to the address & port number specified
	if(bind(ServSocketFD, (struct sockaddr*)&ServSocketName, sizeof(ServSocketName)) < 0){
		FatalError("binding the server to a socket failed");
	}

	// listen(): puts server socket in passive mode, where it waits for the client to approach
	//				the server to make a connection
	if(listen(ServSocketFD, 5) < 0){
		FatalError("listening to socket failed");
	}

    return ServSocketFD;
} /* end of MakeServerSocket */

/* prints/updates the current real time */
void PrintCurrentTime(void){
    time_t CurrentTime; // seconds since 1970
	char *TimeString; // printable time string
	char Wheel, *WheelChars = "|/-\\"; // spinning wheel animation
	static int WheelIndex = 0;

    CurrentTime = time(NULL); // get current real time (in seconds)
	TimeString = ctime(&CurrentTime); // converts time_t value to string
	strncpy(ClockBuffer, TimeString, 25); // copies 25 characters from CLockBuffer to TimeString
	ClockBuffer[24] = 0; // remove unwanted '\n' at then end
    
    WheelIndex = (WheelIndex + 1) % 4; // decides index of WheelChars
	Wheel = WheelChars[WheelIndex]; // prints the stage of the wheel
	// \r -- prints from beginning of current line
	printf("\rClock: %s %c", ClockBuffer, Wheel); // prints time plus a rotating wheel
	fflush (stdout); // flushes out the buffer created by the printf statement	
} /* end of PrintCurrentTime */

/* process a time request by a client */
void ProcessRequest(int DataSocketFD){ 
	int l; // stores string length of input SendBuf
	int n; // stores return value of read() and write()
	char SendBuf[256]; // message buffer for sending a message
					   // stores input data in buffer
	char RecvBuf[256]; // message buffer for receiving a response
					   // stores output data in buffer

	n = read(DataSocketFD, RecvBuf, sizeof(RecvBuf) - 1); // reading received message from buffer
    if (n < 0){
		FatalError("reading from data socket failed");
	}

    RecvBuf[n] = 0; // sets last character of buffer to NULL
#ifdef DEBUG
    printf("%s: Received message: %s\n", Program, RecvBuf);
#endif

    if (0 == strcmp(RecvBuf, "TIME")){ // checking if input command was TIME
		strncpy(SendBuf, "OK TIME: ", sizeof(SendBuf) - 1); // putting text into buffer to send to user
		SendBuf[sizeof(SendBuf) - 1] = 0; // last character = NULL
		strncat(SendBuf, ClockBuffer, sizeof(SendBuf) - 1 - strlen(SendBuf)); // concatentate printable clock information
	}
	else if (0 == strcmp(RecvBuf, "SHUTDOWN")){
		Shutdown = 1;
		strncpy(SendBuf, "OK SHUTDOWN", sizeof(SendBuf) - 1); // putting text into buffer to send to user
		SendBuf[sizeof(SendBuf) - 1] = 0; // last character = NULL
	}
	else if ( 0 == strcmp(RecvBuf, "GAME")){
		strncpy(SendBuf, "Starting the chess game...", sizeof(SendBuf) - 1); 
		SendBuf[sizeof(SendBuf) - 1] = 0;
		Chess();
	}
	else{
		strncpy(SendBuf, "ERROR unkown command ",sizeof(SendBuf) - 1); // putting text into buffer to send to user
		SendBuf[sizeof(SendBuf) - 1] = 0; // last character = NULL
		strncat(SendBuf, RecvBuf, sizeof(SendBuf) - 1 - strlen(SendBuf)); // concatentate received message
	}

	l = strlen(SendBuf); // string length of buffer to be sent 

#ifdef DEBUG
	printf("%s: Sending response: %s.\n", Program, SendBuf);
#endif

	n = write(DataSocketFD, SendBuf, l); // writes from buffer to file

	if (n < 0){
		FatalError("writing to socket failed");
	}
} /* end of ProcessRequest */

/* simple serer main loop */
void ServerMainLoop(  
	int ServSocketFD,  // server socket file to wait on
	ClientHandler HandleClient, // client handler to call
	TimeoutHandler HandleTimeout, // timout handler to call
	int Timeout){ // timeout: specifies max interval to wait for the selection to complete

	int DataSocketFD; // socket for a new client
	// socklen_t: integer type of width of at least 32 bits
	socklen_t ClientLen; // size of address
	
	struct sockaddr_in
	ClientAddress; // client address we connect with

	// fd_set: sets the bit for the file descriptor fd in teh file descriptor set fdset
	fd_set ActiveFDs; // socket file descriptors to select from
	fd_set ReadFDs; //socket file descriptors ready to read from 

	struct timeval TimeVal; // specifies a maximum interval to wait for the selection to complete
	int res; // used to check return value of select()
	int i; // used in for loop

	FD_ZERO(&ActiveFDs); // set of active sockets
	FD_SET(ServSocketFD, &ActiveFDs); // server socket is active

    while(!Shutdown){
		ReadFDs = ActiveFDs; // read the active server socket
		TimeVal.tv_sec = Timeout / 1000000; // seconds
		TimeVal.tv_usec = Timeout % 1000000; // microseconds 

	    /* block until input arrives on active sockets or until timeout */
		res = select(FD_SETSIZE, &ReadFDs, NULL, NULL, &TimeVal); // block until input arrives on active sockets or until timeout
	    if (res < 0){
			FatalError("wait for input or timeout (select) failed");
		}
        
        if (res == 0){
#ifdef DEBUG
			printf("%s: Handling timeout...\n", Program);
#endif
			HandleTimeout();
		}
        else{ // some FDs have data ready to read
			for (i = 0; i < FD_SETSIZE; i++){
				// FD_ISSET(): returns a non-zero value if the bit for the file descriptor fd is set in the file descriptor set pointed by the fdset, and 0 otherwise
				if (FD_ISSET(i, &ReadFDs)){
					if(i == ServSocketFD){ // connection request on a server socket
#ifdef DEBUG
						printf("%s: Accepting new client %d...\n", Program, i);
#endif
						ClientLen = sizeof(ClientAddress); // set to string length of client address
						// accept(): accepts a connection request from a client
						// when a connection is available, socket created is ready to use to read data 
						DataSocketFD = accept(ServSocketFD, (struct sockaddr*)&ClientAddress, &ClientLen);
						
						if(DataSocketFD < 0){
							FatalError("data socket creation (accept) failed");
						}
#ifdef DEBUG
						printf("%s: Client %d connected from %s: %hu.\n", 
									Program, i, 
									inet_ntoa(ClientAddress.sin_addr), // converts Internet host address from IPv4 numbers&dots notation into binary 
									ntohs(ClientAddress.sin_port)); // converts unsigned integer from network byte to host byte order
#endif						
						FD_SET(DataSocketFD, &ActiveFDs); // setting current data socket as active socket
					}
					else{ // active communication with a client 
#ifdef DEBUG
						printf("%s: Dealing with client %d...\n", Program, i);
#endif
						HandleClient(i);
#ifdef DEBUG			
						printf("%s: CLosing client %d connection.\n", Program, i);
#endif
						close(i);
						FD_CLR(i, &ActiveFDs); // clears the bit for the file descriptor fd in teh file descriptor set fdset
					}
				}
			}
		}
    }
} /* end of ServerMainLoop */

/*** main function *******************************************************/

// main function 
int main(int argc, char *argv[]){
	int ServSocketFD; // socket file descriptor for service
	int PortNo; // port number

	Program = argv[0]; // publish program name (for diagnostics)

#ifdef DEBUG
	printf("%s: Starting...\n", Program);
#endif

	if (argc < 2){ 
		fprintf(stderr, "Usage: %s port\n", Program);
		exit(10);
	} // error is less than 2 arguments entered on command line

	PortNo = atoi(argv[1]); // get port number from command line argument

	if (PortNo <= 2000){
		fprintf(stderr, "%s: invalid port number %d, should be >2000\n", Program, PortNo);
		exit(10);
	} 

#ifdef DEBUG
	printf("%s: Creating the server socket...\n", Program);
#endif

	ServSocketFD = MakeServerSocket(PortNo);
	printf("%s: Providing current time at port %d...\n", Program, PortNo);
	ServerMainLoop(ServSocketFD, ProcessRequest, PrintCurrentTime, 250000);
	printf("\n%s: Shutting down.\n", Program);
	close(ServSocketFD);
	return 0;
}

/* EOF ClockServer.c */
