/*********************************************************************/
/* Moves.h                                                           */
/* header file for legal moves for chess pieces                      */
/*                                                                   */
/* Authors: Chih-Yuan Ting, Michael Choi, Christina Wong             */
/* Modifications:                                                    */
/* 05/09/21 MC   added isCheck2                                      */
/* 05/01/21 CW   don't need converting functions anymore             */
/* 04/29/21 MC   Added WinCheck and isCheck                          */
/* 04/26/21 CYT  initial version                                     */
/*********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "Board.h"

#ifndef MOVES_H
#define MOVES_H

int CheckMove (char board [8][8], int turn, int row1, int col1, int row2, int col2);

//int ConvertChar (char piece);

//int ConvertCol(char col);
int SameColor (char board [8][8], int row1, int col1, int row2, int col2);

int BlockingPiece (char board [8][8], int row1, int col1, int row2, int col2);

int Castling (char (*board) [8], int turn, char side);

void WhitePawnPromotion (char board [8][8], int row1, int col1, int row2, int col2);

void BlackPawnPromotion (char board [8][8], int row1, int col1, int row2, int col2);

int isCheck(char board [8][8], int turn);

int isCheck2(char board [8][8], int turn, int x, int y);

int WinCheck(char Board [8][8], int turn);

//int check_en_passant(char board [8][8], int turn, int w_premove_row, int w_premove_col, int w_postmove_row, int w_postmove_col, int b_premove_row, int b_premove_col, int b_postmove_row, int b_postmove_col);

#endif
