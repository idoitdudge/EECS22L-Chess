/*********************************************************************/
/* Test.c                                                            */
/* Functions Testing Enviroment                                      */
/*                                                                   */
/* Authors: Michael Choi                                             */
/* Modifications:                                                    */
/* 05/08/21 MC  initial version                                      */
/*********************************************************************/#include <stdio.h>
#include "Moves.h"
#include "BoardFunctions.h"

int main(){
    char board[8][8] = {{ 'R' , 'N' , 'B' , 'Q' , 'K' , 'B' , 'N' , 'R' },
                        { 'P' , 'P' , 'P' , 'P' , 'P' , 'P' , 'P' , 'P' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { 'p' , 'p' , 'p' , 'p' , 'p' , 'p' , 'p' , 'p' },
                        { 'r' , 'n' , 'b' , 'q' , 'k' , 'b' , 'n' , 'r' }};
    /*
    char board[8][8] = {{ 'R' , 'N' , 'B' , 'Q' , 'K' , 'B' , 'N' , 'R' },
                        { 'P' , 'P' , 'P' , 'P' , ' ' , 'q' , 'P' , 'P' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , 'P' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , 'b' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { 'p' , 'p' , 'p' , 'p' , 'p' , 'p' , 'p' , 'p' },
                        { 'r' , 'n' , 'b' , 'q' , 'k' , 'b' , 'n' , 'r' }};*/
    int win;
    int spot;
    int legal;
    char wprecol;       // white's current column
    int wprecol_con;    // column ASCII conversion
    char wprerow;       // white's current row
    int wprerow_con;    // row ASCII conversion 
    char wpostcol;      // white's post column
    int wpostcol_con;   // column ASCII conversion
    char wpostrow;      // white's post row
    int wpostrow_con;   // row ASCII conversion 
    int run = 1;
    int turn = 2;
    while(run){
        char tempval;
        print_board(board);
        printf("\x1b[36mWhite, please pick your move (i.e. A2A3):\x1b[0m ");
        scanf(" %c %c %c %c", &wprecol, &wprerow, &wpostcol, &wpostrow);
        getchar();
        wprecol_con = ((int) wprecol) - 65;             // convert current column from char into int (ASCII)
        wprerow_con = 8 - (((int) wprerow) - 48);       // convert current row to reflect wanted row (ASCII)
        wpostrow_con = 8 - (((int) wpostrow) - 48);     // convert new row to reflect wanted row (ASCII)
        wpostcol_con = ((int) wpostcol) - 65;           // convert new column from char into int (ASCII)
        if(wprerow_con == 0 && wprecol_con == 0 && wpostrow_con == 0 && wpostcol_con == 0){
            break;
        }
        int isToo = isCheck2(board, turn, 0, 4);
        tempval = board[wprerow_con][wprecol_con]; 
        board[wpostrow_con][wpostcol_con] = tempval; // moves piece to new location and captures if there's a piece already there
        board[wprerow_con][wprecol_con] = ' '; // set old location to blank }
        spot = isCheck(board, turn);
        legal = CheckMove(board, turn, 0, 4, 1, 5);
        //legal = isCheck2(board, 2, wpostmove2, wpostmove_con);
        win = WinCheck(board, turn);
        printf("%d %d %d %d\n", wprerow_con, wprecol_con, wpostrow_con, wpostcol_con); 
        printf("isCheck2 Result %d\n", isToo);
        printf("WinCheck Result %d\n", win);
        printf("CheckMove Result %d\n", legal);
        printf("isCheck Result %d\n", spot);
    }
}
