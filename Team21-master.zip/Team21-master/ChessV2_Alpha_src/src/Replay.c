/*********************************************************************/
/* Replay.c                                                          */
/* creates and prints replay of the game                             */ 
/*                                                                   */
/* Authors: Christina                                                */
/* Modifications:                                                    */
/* 05/07/21 CW  finished most of replay -- need MovesList            */
/* 05/01/21 CW  initial version                                      */
/*********************************************************************/

#include "BoardFunctions.h"

// prints replay if user wants it
void Replay (LIST *list, PLAYER *player1, PLAYER *player2, int ai, int win){
    int replaychoice; 
    // asks user if they want a copy of the replay 
    printf("Would you like a replay of the game? (1. Yes or 2. No)\n");
    printf("Please enter your choice: ");
    scanf(" %d", &replaychoice);
    getchar();

    while (replaychoice != 1 && replaychoice != 2){
        printf("\x1b[1;31mInvalid input!\x1b[0m Please enter your choice: ");
        scanf(" %d", &replaychoice);
        getchar();
    }

    if(replaychoice == 1){
        FILE *File;
        char fname[40];

        // asks user for the file name
        printf("What would you like to name the file? ");
        scanf(" %s", fname);
        getchar();

        char ftype[] = ".txt";   // setting file type to be txt
        strcat(fname, ftype);

        File = fopen(fname, "w");

        if(!File)
            printf("\nCan't open file \"%s\" for reading!\n", fname);

        // initialize pointer to access time struct 
        struct tm *date;
        time_t rawtime = 0;
        time(&rawtime);
        date = localtime(&rawtime);

        // ************ BEGINNING OF FILE ***************
        fprintf(File, "************* PANDA CHESS *************\n\n");                    // name of game
        fprintf(File, "Version: v1.0\n");                   // version 
        fprintf(File, "File name: %s", fname);              // file name 
        fprintf(File, "\nDate: %d/", date->tm_year+1900);   // set year
        // set month
        if (date->tm_mon + 1 < 10)
            fprintf(File, "0%d/", date->tm_mon + 1);     // add 0 in front of numbers less than 10 (i.e. 03)
        else 
            fprintf(File, "%d/", date->tm_mon + 1);      // if 10+, print as is

        // set date
        if (date->tm_mday < 10)
            fprintf(File, "%d ", date->tm_mday);
        else 
            fprintf(File, "%d ", date->tm_mday);
    
        // set hour (12-hour clock)
        if (date->tm_hour == 0)
            fprintf(File, "12");   // print 12 for midnight           
        else if (date->tm_hour < 10)
            fprintf(File, "0%d:", date->tm_hour);   // add 0 for single digit numbers
        else if (date->tm_hour < 12)
            fprintf(File, "%d:", date->tm_hour);
        else if (date->tm_hour < 22)
            fprintf(File, "0%d:", (date->tm_hour) - 12); // to get 1-9pm
        else 
            fprintf(File, "%d:", (date->tm_hour) - 12); // for 10pm & 11pm

        // set minute
        if (date->tm_min < 10)
            fprintf(File, "0%d", date->tm_min);
        else 
            fprintf(File, "%d", date->tm_min);

        // set am or pm
        if (date->tm_hour < 12) 
            fprintf(File, "am\n\n");    // hour is less than 12 --> am
        else 
            fprintf(File, "pm\n\n");    
        
        // *********** SETTINGS *************
        // printing the settings used in the game
        fprintf(File, "*************** SETTINGS **************\n\n");
        
        // color of player 1
        switch (player1->pcolor){
            case 'w':
                fprintf(File, "Player 1 (Human): \'White\'\n");
                break;
            case 'b':
                fprintf(File, "Player 1 (Human): \'Black\'\n");
                break;
            default: 
                fprintf(File, "bug in player 1 setting\n");                
        }
        // color of human (player 2)
        if (ai == 0){
            switch (player2->pcolor){
                case 'w':
                    fprintf(File, "Player 2 (Human): \'White\'\n");
                    break;
                case 'b':
                    fprintf(File, "Player 2 (Human): \'Black\'\n");
                    break;
                default: 
                    fprintf(File, "bug in player 2 setting\n"); 
            }
        }
        // color of ai (player 2)
        else if (ai == 1){
             switch (player2->pcolor){
                case 'w':
                    fprintf(File, "Player 2 (AI): \'White\'\n");
                    break;
                case 'b':
                    fprintf(File, "Player 2 (AI): \'Black\'\n");
                    break;
                default: 
                    fprintf(File, "bug in player 2 setting\n");
            }
        }

        
        // *********** REPLAY *************
        // prints replay of the game
        fprintf(File, "\n**************** REPLAY ***************\n\n");
        fprintf(File, "Game Started! \n\n");
        ENTRY *entry = list->First->Next;
        BOARD *repboard = NULL;

        int turn = 1;       // keeps track of which player 
        int len = list->Length - 1; 
        char tempboard[8][8];
        //fprintf(File, "141 %d", len);
        fflush(File); 
        for (int i = 0; i < len - 1; i++){
            if (entry == NULL) break;
            repboard = entry->board; //repboard points to board of entry
            //fprintf(File, "144");
            fflush(File); 

            while (entry){   // if entry exists 
                //fprintf(File, "147");
                fflush(File); 

                repboard = entry->board;
                //fprintf(File, " %d", repboard == NULL);
                for (int x = 0; x < 8; x++){
                    for (int y = 0; y < 8; y++)
                        tempboard[x][y] = repboard->newboard[x][y];
                }
                //fprintf(File, " %d", tempboard == NULL);
                
                fprintf(File, "Player %d's move: %c%c%c%c \n", turn, entry->board->precol, entry->board->prerow, 
                                                                    entry->board->postcol, entry->board->postrow);
                fflush(File); 

                //fprintf(File, " %d", tempboard == NULL);

                FPrintBoard(File, tempboard, player1, player2);
                fflush(File); 

                fprintf(File, "POINTS: \n");
                fprintf(File, "\tPlayer 1: %d\n", player1->points);
                fprintf(File, "\tPlayer 2: %d\n\n", player2->points);

                if (turn == 1)        
                    turn++;
                else
                    turn--;

                entry = entry->Next;
            }
        }

        // *********** MOVESLIST *************
        // prints out full moves list in log format
        fprintf(File, "\n************** MOVES LOG **************\n\n");
        entry = list->First->Next; 
        for(int i = 0; i < len - 1; i++){
            while(entry){
                fprintf(File, "Player %d's move: %c%c%c%c \n", turn, entry->board->precol, entry->board->prerow, 
                                                                    entry->board->postcol, entry->board->postrow);
                fflush(File); 
               
                if (turn == 1)        
                    turn++;
                else
                    turn--;

                entry = entry->Next;
            }
        }

        fprintf(File, "\nTOTAL POINTS: \n");
        fprintf(File, "\tPlayer 1: %d\n", player1->points);
        fprintf(File, "\tPlayer 2: %d\n\n", player2->points);

        // *********** WINNER *************
        // prints winner of the game
        fprintf(File, "\n**************** WINNER ****************\n\n");
        if (win == 0)
            fprintf(File, "The game is a tie!\n\n");
        else
            fprintf(File, "Player %d wins!\n\n", win);

        fprintf(File, "~~~~~~~~~ Thanks for playing! ~~~~~~~~~\n");

        // *********** CLOSING FILE *************
        fclose(File);
        printf("%s was saved successfully!\n", fname);
    }
    else
        printf("Replay will be deleted...\n");
}

// prints board into file
void FPrintBoard(FILE *File, char board[8][8], PLAYER *player1, PLAYER *player2){
    int i, j, k;
	
	fprintf(File, "\n"); // formatting
    fflush(File); 
	
    for(k = 0; k < 8; k++){
        fprintf(File, "  ");                       // leave space for vertical indeces
    
        // prints a set of dash lines (row separation)
        for(i = 0; i < 33; i++){ 
            fprintf(File, "-"); 
        } 
        fprintf(File, "\n"); 
        
        int a = 8;
        // printf(File, "%d ", k + 1);             // prints vertical indeces from 1-8
        fprintf(File, "%d ", a - k);                // prints vertical indeces from 8-1 
        
        // prints character at the location with adjacent borders
        for(j = 0; j < 8; j++){
            if (j % 2 == 0){
                if (k % 2 != 0)
                    fprintf(File, "| %c ", board[k][j]); // white font, black background
                else 
                    fprintf(File, "| %c ", board[k][j]); // black font, white background
            }else{
                if (k % 2 == 0)
                    fprintf(File, "| %c ", board[k][j]); // white font, black background
                else 
                    fprintf(File, "| %c ", board[k][j]); // black font, white background
            }
        }
        fprintf(File, "| \n");
    }

    fprintf(File, "  ");                           // formatting of last line of dashes
    
    // prints last line of dashes 
    for(i = 0; i < 33; i++){ 
        fprintf(File, "-"); 
    }
    fprintf(File, "\n ");

    // prints horizontal indeces A-H 
    for(i = 65; i < 73; i++){
        fprintf(File, "   %c", i);
    }
    fprintf(File, "\n\n");
    fflush(File); 

}

/* EOF */
