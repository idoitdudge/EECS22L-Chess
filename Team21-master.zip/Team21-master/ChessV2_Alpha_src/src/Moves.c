/*********************************************************************/
/* Moves.c                                                           */
/* functions for legal moves for chess pieces                        */
/*                                                                   */
/* Authors: Chih-Yuan Ting, Christina Wong, Michael Choi             */
/* Modifications:                                                    */
/* 05/10/21 MC   finished WinCheck                                   */
/* 05/09/21 CW   fixed castling and some issues in pawn check moves  */
/* 05/09/21 MC   added isCheck2 and modified CheckMoves              */
/* 05/09/21 CW   added debug lines for return 1's                    */
/* 05/08/21 MC   added knight functionality to isCheck               */
/* 05/08/21 MC   fixed isCheck                                       */
/* 05/06/21 CW   added debugging tools for CheckMoves                */
/* 05/05/21 CW   fixed some borders in CheckMoves                    */
/* 05/03/21 MC   edited isCheck                                      */
/* 05/01/21 CW   fixed CheckMove function and removed converters     */
/* 04/29/21 MC   added WinCheck and isCheck                          */
/* 04/26/21 CW   fixed some errors                                   */
/* 04/26/21 CW   added comments and converter for columns            */ 
/* 04/26/21 CYT  initial version                                     */
/*********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "Board.h"     
#include "Moves.h"

// debugger tool
#define cat(x) # x
#define stringify(x) cat(x)

#define debugf(msg, ...) {\
    printf("\x1b[1;31mDEBUG [L " stringify(__LINE__) "]: " msg "\n\x1b[0m", ##__VA_ARGS__);\
}

int CheckMove (char board [8][8], int turn, int row1, int col1, int row2, int col2){
    //debugf("turn: %d", turn);	// debugs turn value
    int i;
    // *************** WHITE MOVES ***************
    if (turn == 1){ 
        //debugf("%d %d %d %d", row1, col1, row2, col2); 	// debugs row and column values 
		// *************** GENERAL INPUT CHECKS ***************
		// if new location is the same spot, don't move
	    if (row2 == row1 && col2 == col1)
		    return 10;
	
	    // if new location is outside of board 
	    if (row2 > 7 || row2 < 0 || col2 > 7 || col2 < 0)
		    return 20;
		
		// *************** PAWN MOVES ***************
		// WHITE pawns' first move
		if (row1 == 6 && board[row1][col1] == 'p'){
			// move 2 up ---------------------------------------------- move 1 up
			if (((board [row1 - 1][col1] == ' ') && (col1 == col2) && ((row2 == row1 - 2 && board[row2][col2] == ' ') || (row2 == row1 - 1 && board[row2][col2] == ' '))) || ((board[row2][col2] != ' ' && row2 == row1 - 1 && col2 == col1 - 1) || (board[row2][col2] != ' ' && row2 == row1 - 1 && col2 == col1 + 1)))
				{return 1;}
			else
				return 30;
		}	

 	//check pawn promotion for white
 	/*if(row2 == 0 && board [row1][col1] == 'p')
        {
                char piece_selection;
                printf("What would you like your pawn to become?\n");
                printf("R for rook\n N for knight\n B for bishop \n Q for queen \n");
                scanf(" %c", &piece_selection);
		getchar ();
                if (piece_selection == 'Q'){
                        board [row1][col1] = 'q';}
                else if (piece_selection == 'B'){
                        board [row1][col1] = 'b';}
                else if (piece_selection == 'R'){
                        board [row1][col1] = 'r';}
                else if (piece_selection == 'N'){
                        board [row1][col1] = 'n';}
                return 1;
        }*/
		// general white pawn move (after first move)
	    else if (row1 != 6 && col1 == col2 && board[row1][col1] == 'p'){
		    if (row2 == row1 - 1 && board[row2][col2] == ' ')
			    {return 1;}
		    else
			    return 40;
	    }
		// taking a piece
	     else if ((board[row2][col2] != ' ' && row2 == row1 - 1 && col2 == col1 - 1) || 
				 (board[row2][col2] != ' ' && row2 == row1 - 1 && col2 == col1 + 1))  // checks left then right (front only)
		    {return 1;}
	    
		// en passant
	    else if ((row1 == 3 && board[row1][col1] == 'p')){
            	for (i = 0; i < 8; i++){
                	if (board [3][i] == 'P' && (board [3][i+1] == 'p' || board [3][i-1] == 'p') && board [row2][col2] ==  ' ' && ((row2 == row1 - 1 && col2 == col1 - 1) || (row2 == row1 - 1 && col2 == col1 + 1)))
                        {board [3][i] = ' ';
			 return 1;}
                }
		return 500;
		
        }
			
			
	
		// *************** ROOK *************** 
	    if (board[row1][col1] == 'r'){
		    for (int i = 0; i < 8; i++){
			    if ((col2 == col1 && row2 == row1 + i) || (row2 == row1 && col2 == col1 + i) || 
                    (col2 == col1 && row2 == row1 - i) || (row2 == row1 && col2 == col1 - i))
				    {return 1;}
		    }
		    return 60;
	    }

	    // *************** KNIGHT ***************
	    if (board [row1][col1] == 'n'){
		    if ((row2 == row1 + 2 && col2 == col1 + 1) || (row2 == row1 + 2 && col2 == col1 - 1) || 
                (row2 == row1 - 2 && col2 == col1 + 1) || (row2 == row1 - 2 && col2 == col1 - 1) || 
                (row2 == row1 + 1 && col2 == col1 + 2) || (row2 == row1 - 1 && col2 == col1 + 2) || 
                (row2 == row1 + 1 && col2 == col1 - 2) || (row2 == row1 - 1 && col2 == col1 - 2))
			    {return 1;}
		    else 
			    return 70;
	    }   

	    // *************** BISHOP ***************
	    if (board[row1][col1] == 'b') {
		    for (int i = 0; i < 8; i++){
			    if ((row2 == row1 + i && col2 == col1 + i) || (row2 == row1 + i && col2 == col1 - i) || 
                    (row2 == row1 - i && col2 == col1 + i) || (row2 == row1 - i && col2 == col1 - i))
				    {return 1;}
		    }
		    return 80;
	    }

	    // *************** KING ***************
	    if (board[row1][col1] == 'k'){
            if(isCheck2(board, turn, row2, col2) == 1)
                return 90;
		    else if ((row2 == row1 + 1 && col2 == col1 + 1) || (row2 == row1 - 1 && col2 == col1 + 1) || 
                (row2 == row1 + 1 && col2 == col1 - 1) || (row2 == row1 - 1 && col2 == col1 - 1) || 
                (row2 == row1 && col2 == col1 + 1) || (row2 == row1 && col2 == col1 - 1) || 
                (row2 == row1 + 1 && col2 == col1) || (row2 == row1 - 1 && col2 == col1))
			    {return 1;}
		    else
			    return 90;
	    }

	    // *************** QUEEN ***************
	    if (board[row1][col1] == 'q'){
		    for (int i = 0; i < 8; i++){
			    if ((row2 == row1 + i && col2 == col1 + i) || (row2 == row1 + i && col2 == col1 - i) || 
                    (row2 == row1 - i && col2 == col1 + i) || (row2 == row1 - i && col2 == col1 - i) || 
                    (col2 == col1 && row2 == row1 + i) || (row2 == row1 && col2 == col1 + i) || 
                    (col2 == col1 && row2 == row1 - i) || (row2 == row1 && col2 == col1 - i))
		    		{return 1;}
		    }
		    return 100;
	    }
	}

	// *************** BLACK MOVES ***************
	if (turn == 2){
		//debugf("%d %d %d %d", row1, col1, row2, col2);
        // *************** GENERAL INPUT CHECKS ***************
		// if new location is the same spot, don't move
	    if (row2 == row1 && col2 == col1)
		    return 200;
	
	    // if new location is outside of board 
	    if (row2 > 7 || row2 < 0 || col2 > 7 || col2 < 0)
		    return 210;
		
		// *************** BLACK PAWN MOVES ***************
	//check black pawn promotion
	/*if(row2 == 7 && board [row1][col1] == 'P')
	{
		char piece_selection;
		printf("What would you like your pawn to become?\n");
		printf("R for rook\n N for knight\n B for bishop \n Q for queen \n");
		scanf(" %c", &piece_selection);
		getchar ();
		if (piece_selection == 'Q'){
			board [row1][col1] = 'Q';}
		else if (piece_selection == 'B'){
                        board [row1][col1] = 'B';}
		else if (piece_selection == 'R'){
                        board [row1][col1] = 'R';}
		else if (piece_selection == 'N'){
                        board [row1][col1] = 'N';}
		return 1;
	}*/
	
		// black pawns' first move
	    if (row1 == 1 && board[row1][col1] == 'P'){
			// move 2 down ---------------------------------------------- move 1 down
            if (((board [row1 + 1][col1] == ' ') && (col1 == col2) && ((row2 == row1 + 2 && board[row2][col2] == ' ') || (row2 == row1 + 1 && board[row2][col2] == ' '))) || ((board[row2][col2] != ' ' && row2 == row1 + 1 && col2 == col1 + 1) || (board[row2][col2] != ' ' && row2 == row1 + 1 && col2 == col1 - 1)))
                {return 1;}
            else
                return 220;
        }
	    // general black pawn move (after first move)
        else if (row1 != 1 && col1 == col2 && board[row1][col1] == 'P'){
            if (row2 == row1 + 1 && board[row2][col2] == ' ')
                {return 1;}
            else
      		    return 230;
  	    }
        // taking a piece
	 else if ((board[row2][col2] != ' ' && row2 == row1 + 1 && col2 == col1 + 1) || 
				 (board[row2][col2] != ' ' && row2 == row1 + 1 && col2 == col1 - 1)) // checks left then right (front only)
            {return 1;}
	else if (row1 == 4 && board[row1][col1] == 'P'){
            for (i = 0; i < 8; i++){
                if (board [4][i] == 'p' && (board [4][i+1] == 'P' || board [4][i-1] == 'P') && board [row2][col2] ==  ' ' && ((row2 == row1 + 1 && col2 == col1 - 1) || (row2 == row1 + 1 && col2 == col1 + 1)))
                        {board [4][i] = ' ';
			 return 1;}
		}
             return 510;
	}	

		// *************** ROOK ***************
	    if (board[row1][col1] == 'R'){
		    for (int i = 0; i < 8; i++){
			    if ((col2 == col1 && row2 == row1 + i) || (row2 == row1 && col2 == col1 + i) || 
                    (col2 == col1 && row2 == row1 - i) || (row2 == row1 && col2 == col1 - i))
				    {return 1;}
		    }
		    return 250;
	    }


	    // *************** KNIGHT ***************
	    if (board[row1][col1] == 'N'){
		    if ((row2 == row1 + 2 && col2 == col1 + 1) || (row2 == row1 + 2 && col2 == col1 - 1) || 
                (row2 == row1 - 2 && col2 == col1 + 1) || (row2 == row1 - 2 && col2 == col1 - 1) || 
                (row2 == row1 + 1 && col2 == col1 + 2) || (row2 == row1 - 1 && col2 == col1 + 2) || 
                (row2 == row1 + 1 && col2 == col1 - 2) || (row2 == row1 - 1 && col2 == col1 - 2))
			    {return 1;}
		    else 
			    return 260;
	    }
   
	    // *************** BISHOP ***************
	    if (board[row1][col1] == 'B'){
		    for (int i = 0; i < 8; i++){
			    if ((row2 == row1 + i && col2 == col1 + i) || (row2 == row1 + i && col2 == col1 - i) || 
                    (row2 == row1 - i && col2 == col1 + i) || (row2 == row1 - i && col2 == col1 - i))
				    {return 1;}
		    }
		    return 270;
	    }

	    // *************** KING ***************
	    if (board[row1][col1] == 'K'){
            if(isCheck2(board, turn, row2, col2) == 1)
                return 280;
		    else if ((row2 == row1 + 1 && col2 == col1 + 1) || (row2 == row1 - 1 && col2 == col1 + 1) || 
                     (row2 == row1 + 1 && col2 == col1 - 1) || (row2 == row1 - 1 && col2 == col1 - 1) || 
                     (row2 == row1 && col2 == col1 + 1) || (row2 == row1 && col2 == col1 - 1) || 
                     (row2 == row1 + 1 && col2 == col1) || (row2 == row1 - 1 && col2 == col1))
			    {return 1;}
		    else
			    return 280;
	    }
	

	    // *************** QUEEN ***************
	    if (board[row1][col1] == 'Q'){
		    for (int i = 0; i < 8; i++){
			    if ((row2 == row1 + i && col2 == col1 + i) || (row2 == row1 + i && col2 == col1 - i) || 
                    (row2 == row1 - i && col2 == col1 + i) || (row2 == row1 - i && col2 == col1 - i) || 
                    (col2 == col1 && row2 == row1 + i) || (row2 == row1 && col2 == col1 + i) || 
                    (col2 == col1 && row2 == row1 - i) || (row2 == row1 && col2 == col1 - i))
		    		{return 1;}
		    }
		    return 290;
	    }
    }
    return 400; 
}

int SameColor (char board [8][8], int row1, int col1, int row2, int col2)
{
	if (board [row1][col1] == 'p' || board [row1][col1] == 'r' || board [row1][col1] == 'n' || 
        board [row1][col1] == 'b' || board [row1][col1] == 'k' || board [row1][col1] == 'q'){
		if (board [row2][col2] == 'p' || board [row2][col2] == 'r' || board [row2][col2] == 'n' || 
            board [row2][col2] == 'b' || board [row2][col2] == 'k' || board [row2][col2] == 'q')
			return 11; // white -> white
	}
	
	if (board [row1][col1] == 'P' || board [row1][col1] == 'R' || board [row1][col1] == 'N' || 
        board [row1][col1] == 'B' || board [row1][col1] == 'K' || board [row1][col1] == 'Q'){
        if (board [row2][col2] == 'P' || board [row2][col2] == 'R' || board [row2][col2] == 'N' || 
            board [row2][col2] == 'B' || board [row2][col2] == 'K' || board [row2][col2] == 'Q')
            return 12; // black -> black
        }
	{return 1;}
}

int BlockingPiece (char board [8][8], int row1, int col1, int row2, int col2)
{
	int i, j;
	//rook movement
	if (board [row1][col1] == 'r' || board [row1][col1] == 'R'){
		if (col1 < col2){
			for (i = col1+1; i < col2; i++){
				if (board [row1][i] != ' ')
					return 20; // down
			}
			{return 1;}
		}
		else if (col1 > col2){
			for (i = col1-1; i > col2; i--){
				if (board [row1][i] != ' ')
					return 30; // up
			}
			{return 1;}
			
		}
		else if (row1 < row2){
            for (i = row1+1; i < row2; i++){
                if (board [i][col1] != ' ')
                    return 40; // right
			}
            {return 1;}
        }
		else if (row1 > row2){
            for (i = row1-1; i > row2; i--){
                if (board [i][col1] != ' ')
                    return 50; // left 
            }
			{return 1;}
       }
	}
	
	//bishop movement
	if (board [row1][col1] == 'b' || board [row1][col1] == 'B'){
		if ((col1 < col2) && (row1 < row2)){
			j = col1;
			for ( i = row1+1; i < row2; i++){
				j++;
				if (board [i][j] != ' '){
					return 60; // up & right
				}
			}
			{return 1;}
		}
		else if ((col1 < col2) && (row1 > row2)){
            j = col1;
            for ( i = row1-1; i > row2; i--){
                j++;
                if (board [i][j] != ' ')
                    return 70; // down & right
			}
            {return 1;}
        }
		else if ((col1 > col2) && (row1 < row2)){
            j = col1;
            for ( i = row1+1; i < row2; i++){
                j--;
                if (board [i][j] != ' ')
                    return 80; // up & left
			}
            {return 1;}
        }
		else if ((col1 > col2) && (row1 > row2)){
            j = col1;
            for ( i = row1-1; i > row2; i--){
                j--;
                if (board [i][j] != ' ')
                    return 90; //down & left 
            }
			{return 1;}
        }
	}

	//queen movement
	if (board [row1][col1] == 'q' || board [row1][col1] == 'Q'){
		if ((col1 == col2 && row1 != row2) || (col1 != col2 && row1 == row2)){
			if (col1 < col2){
              	for (i = col1+1; i < col2; i++){
                  	if (board [row1][i] != ' ')
                      	return 100; // vertically up 
				}
                {return 1;}
            }
            else if (col1 > col2){
               	for (i = col1-1; i > col2; i--){
                   	if (board [row1][i] != ' ')
                       	return 110; // vertically down
               	}
				{return 1;}
      		}
           	else if (row1 < row2){
               	for (i = row1+1; i < row2; i++){
                   	if (board [i][col1] != ' ')
                      	return 120; // horizontally right
               	}
				{return 1;}
           	}
          	else if (row1 > row2){
               	for (i = row1-1; i > row2; i--){
                   	if (board [i][col1] != ' ')
                      	return 130; // horizontally left 
                }
			{return 1;}                        	
            }
		}
		if (col1 != col2 && row1 != row2){
			if ((col1 < col2) && (row1 < row2)){
                j = col1;
                for ( i = row1+1; i < row2; i++){
                     j++;
                     if (board [i][j] != ' ')
                         return 140; // diagonally up and right
                }
				{return 1;}                        	
            }
        	else if ((col1 < col2) && (row1 > row2)){
               	j = col1;
               	for ( i = row1-1; i > row2; i--){
                   	j++;
                   	if (board [i][j] != ' ')
                      	return 150; // diagonally down and right
              	}
				{return 1;}                        	
            }
           	else if ((col1 > col2) && (row1 < row2)){
              	j = col1;
               	for ( i = row1+1; i < row2; i++){
                   	j--;
                   	if (board [i][j] != ' ')
                      	return 160; // diagonally up and left 
               	}
				{return 1;}                        	
           	}
      		else if ((col1 > col2) && (row1 > row2)){
               	j = col1;
               	for ( i = row1-1; i > row2; i--){
                  	j--;
			        if (board [i][j] != ' ')
                     	return 170; // diagonally down and left 
                }
		    {return 1;}
          	}
		}
	}
	{return 1;}
}

void WhitePawnPromotion (char board[8][8], int row1, int col1, int row2, int col2)
{
                char piece_selection;
                printf("What would you like your pawn to become?\n");
                printf("R for rook\n N for knight\n B for bishop \n Q for queen \n");
                scanf(" %c", &piece_selection);
                getchar ();
                if (piece_selection == 'Q'){
                        board [row2][col2] = 'q';}
                else if (piece_selection == 'B'){
                        board [row2][col2] = 'b';}
                else if (piece_selection == 'R'){
                        board [row2][col2] = 'r';}
                else if (piece_selection == 'N'){
                        board [row2][col2] = 'n';}
}

void BlackPawnPromotion (char board[8][8], int row1, int col1, int row2, int col2)
{
                char piece_selection;
                printf("What would you like your pawn to become?\n");
                printf("R for rook\n N for knight\n B for bishop \n Q for queen \n");
                scanf(" %c", &piece_selection);
                getchar ();
                if (piece_selection == 'Q'){
                        board [row2][col2] = 'Q';}
                else if (piece_selection == 'B'){
                        board [row2][col2] = 'B';}
                else if (piece_selection == 'R'){
                        board [row2][col2] = 'R';}
                else if (piece_selection == 'N'){
                        board [row2][col2] = 'N';}
}

int Castling (char board[8][8], int turn, char side)
{
	if (turn == 1){
        if (side == 'L'){
            if (board [7][0] == 'r' && board [7][4] == 'k' && board [7][1] == ' ' && board [7][2] == ' ' && board [7][3] == ' '){
                board [7][2] = 'k';     // moves king to new position
                board [7][3] = 'r';     // moves rook to new position
                board [7][0] = ' ';     // clear old position
                board [7][4] = ' ';     
                {return 1;}
            }else
                return 21;
        }else if (side == 'R'){
            if (board [7][7] == 'r' && board [7][4] == 'k' && board [7][5] == ' ' && board [7][6] == ' '){
                board [7][5] = 'r';     // moves rook to new position
                board [7][6] = 'k';     // moves king to new position
                board [7][7] = ' ';     // clear old position
                board [7][4] = ' ';     
                {return 1;}
            }else
                return 22;
        }
        return 23;
    }
    if (turn == 2){
        if (side == 'L'){
            if (board [0][0] == 'R' && board [0][4] == 'K' && board [0][1] == ' ' && board [0][2] == ' ' && board [0][3] == ' ') {
                board [0][2] = 'K';     // moves king to new position 
                board [0][3] = 'R';     // moves rook to new position
                board [0][0] = ' ';     // clear old position
                board [0][4] = ' ';     
                {return 1;}
            }else
                return 24;
        }else if (side == 'R'){
            if (board [0][7] == 'R' && board [0][4] == 'K' && board [0][5] == ' ' && board [0][6] == ' '){
                board [0][5] = 'R';     // moves rook to new position 
                board [0][6] = 'K';     // mvoes king to new position
                board [0][7] = ' ';     // clear old position
                board [0][4] = ' ';
                {return 1;}
            }else
                return 25;
        }
        return 26;
    }
	return 27;
}



/*
//converts input column (A-H) into int 
int ConvertCol (char col)
{
	int val;
	if (col == 'A')
		val = 0;
	else if (col == 'B')
		val = 1;
	else if (col == 'C')
		val = 2;
        else if (col == 'D')
        	val = 3;
    	else if (col == 'E')
        	val = 4;
	else if (col == 'F')
        	val = 5;
    	else if (col == 'G')
        	val = 6;
    	else if (col == 'H')
        	val = 7;
	
	return val;
}

//converts rows from (1-8) to (0-7)
int ConvertRow(char row)
{
	int val;
	if(row == '1')
		val = 0;
	else if (row == '2')
		val = 1;
	else if (row == '3')
		val = 2;
	else if (row == '4')
		val = 3;
	else if (row == '5')
		val = 4;
	else if (row == '6')
		val = 5;
	else if (row == '7')
		val = 6;
	else if (row == '8')
		val = 7;
	return val;
}*/

int isCheck(char board [8][8], int turn)
{
    char search;
    int count = 0;
    int x;
    int y;
    //used to find King
    if(turn == 1)
        search = 'k';
    else
        search = 'K';
    for(int i = 0; i < 8; i++)
    {
        for(int j = 0; j < 8; j++)
        {
            if(board[i][j] == search)
            {
                x = i;
                y = j;
            }
        }
    }
    /*
    //if king is on edge
    if(x == 0 || x == 7 || y == 0 || y == 7){
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                if(CheckMove(board, turn, i, j, x, y) == 1 && SameColor(board, i, j, x, y) == 1 && BlockingPiece(board, i, j, x, y) == 1)
                    return 1;
            }
        }
    }
    */
    int bigger;
    int smaller;
    if(y < x){
        bigger = x;
        smaller = y;       
    }
    else{
        bigger = y;
        smaller = x;
    }
    //down right diagonal
    for(int i = 1; i < 8 - bigger; i++)
    {
        if(board[x+i][y+i] != ' ')
        {
            if(turn == 1)
            {
                if(board[x+i][y+i] == 'Q' || board[x+i][y+i] == 'B')
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(count == 0 && board[x+i][y+i] == 'p')
                    {return 1;}
                else if(board[x+i][y+i] == 'q' || board[x+i][y+i] == 'b')
                    {return 1;}
                else
                    break;
            }
        }
        count++;
    }
    count = 0;
    int l = smaller;
    //up right diagonal
    for(int i = 1; l >= 0; l--, i++)
    {
        if(board[x-i][y-i] != ' ')
        {
            if(turn == 1)
            {
                if(count == 0 && board[x-i][y-i] == 'P')
                    {return 1;}
                else if(board[x-i][y-i] == 'Q' || board[x-i][y-i] == 'B')
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(board[x-i][y-i] == 'q' || board[x-i][y-i] == 'b')
                    {return 1;}
                else
                    break;
            }
        }
        count++;
    }
    count = 0;
    //down left diagonal
    int temp = y-1;
    for(int i = x+1; i < 8 || temp >= 0; i++)
    {
        if(board[i][temp] != ' ')
        {
            if(turn == 1)
            {
                 if(board[i][temp] == 'Q' || board[i][temp] == 'B')
                    {return 1;}
                 else
                    break;
            }
            else
            {
                if(count == 0 && board[i][temp] == 'p')
                    {return 1;}
                else if(board[i][temp] == 'q' || board[i][temp] == 'b')
                    {return 1;}
                else
                    break;
            }
        }
        temp--;
        count++;
    }
    count = 0;
    temp = y+1;
    //up right diagonal
    for(int i = x-1; i >= 0 || temp < 8; i--)
    {
        if(board[i][temp] != ' ')
        {
            if(turn == 1)
            {
                if(count == 0 && board[i][temp] == 'P')
                    {return 1;}
                else if((board[i][temp] == 'Q' || board[i][temp] == 'B') && count != 0)
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(board[i][temp] == 'q' || board[i][temp] == 'b')
                    {return 1;}
                else
                    break;
            }
        }
        temp++;
        count++;
    }
    //left horizontal
    for(int i = y-1; i >= 0 ; i--)    
    {
        if(board[x][i] != ' ')
        {
            if(turn == 1)
            {
                if(board[x][i] == 'Q' || board[x][i] == 'R')
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(board[x][i] == 'q' || board[x][i] == 'r')
                    {return 1;}
                else
                    break;
            }
        }
    }
    //right horizontal
    for(int i = y+1; i < 8; i++)
    {
        if(board[x][i] != ' ')
        {
            if(turn == 1)
            {
                if(board[x][i] == 'Q' || board[x][i] == 'R')
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(board[x][i] == 'q' || board[x][i] == 'r')
                    {return 1;}
                else
                    break;
            }
        }
    }
    count = 0;
    //bottom vertical
    for(int i = x+1; i < 8; i++)
    {
        if(board[i][y] != ' ')
        {
            if(turn == 1)
            {
                if(board[i][y] == 'Q' || board[i][y] == 'R')
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(board[i][y] == 'q' || board[i][y] == 'r')
                    {return 1;}
                else
                    break;     
            }
        }
    }
    //top vetical
    for(int i = x-1; i >= 0; i--)
    {
        if(board[i][y] != ' ')
        {
            if(turn == 1)
            {
                if(board[i][y] == 'Q' || board[i][y] == 'R')
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(board[i][y] == 'q' || board[i][y] == 'r')
                    {return 1;}
                else
                    break;
            }
        }
    }
    //All lines below this is for Knight Check
    if((x-2 >= 0 || x+2 <= 8) && (y-2 >= 0 || y+2 <= 8)){
        if(turn == 1){
            if(board[x-2][y-1] == 'N' || board[x-2][y+1] == 'N' || board[x+2][y-1] == 'N' || board[x+2][y+1] == 'N' || board[x+1][y-2] == 'N' || board[x-1][y-2] == 'N' || board[x+1][y+2] == 'N' || board[x-1][y+2] == 'N')
                {return 1;}
        }
        else{
            if(board[x-2][y-1] == 'n' || board[x-2][y+1] == 'n' || board[x+2][y-1] == 'n' || board[x+2][y+1] == 'n' || board[x+1][y-2] == 'n' || board[x-1][y-2] == 'n' || board[x+1][y+2] == 'n' || board[x-1][y+2] == 'n')
                {return 1;}
        }
    }
    //if king is on top edge
    else if(x == 0 && (y-2 >= 0 || y+2 <= 8)){
        if(turn == 1){
            if(board[x-2][y-1] == 'N' || board[x-2][y+1] == 'N')
                {return 1;}
        }
        else{
            if(board[x-2][y-1] == 'n' || board[x-2][y+1] == 'n')
                {return 1;}
        }
    }
    //if king is on bottom edge
    else if(x == 8 && (y-2 >= 0 || y+2 <= 0)){
        if(turn == 1){
            if(board[x+2][y-1] == 'N' || board[x+2][y+1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+2][y-1] == 'n' || board[x+2][y+1] == 'n')
                {return 1;}
        }
    }
    //if king is on left edge
    else if(y == 0 && (x-2 >= 0 || x+2 <= 0)){
        if(turn == 1){
            if(board[x+1][y+2] == 'N' || board[x-1][y+2] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y+2] == 'n' || board[x-1][y+2] == 'n')
                {return 1;}
        }
    }
    //if king is on right edge
    else if(y == 8 && (x-2 >= 0 || x+2 <= 0)){
        if(turn == 1){
            if(board[x+1][y-2] == 'N' || board[x-1][y-2] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y-2] == 'n' || board[x-1][y-2] == 'n')
                {return 1;}
        }
    }
    //top left corner
    else if(x == 0 && y == 0){
        if(turn == 1){
            if(board[x+1][y+2] == 'N' || board[x+2][y+1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y+2] == 'n' || board[x+2][y+1] == 'n')
                {return 1;}
        }
    }
    //top right corner
    else if(x == 0 && y == 8){
        if(turn == 1){
            if(board[x+1][y-2] == 'N' || board[x+2][y-1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y-2] == 'n' || board[x+2][y-1] == 'n')
                {return 1;}
        }
    }
    //bottom left corner
    else if(x == 8 && y == 0){
        if(turn == 1){
            if(board[x+1][y+2] == 'N' || board[x+2][y+1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y+2] == 'n' || board[x+2][y+1] == 'n')
                {return 1;}
        }
    }
    //bottom right corner
    else if(x == 8 && y == 8){
        if(turn == 1){
            if(board[x+1][y-2] == 'N' || board[x+2][y-1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y-2] == 'n' || board[x+2][y-1] == 'n')
                {return 1;}
        }
    }
    //if king is 1 space away from the left side
    else if(x-2 == 0 && y-1 == 0){
        if(turn == 1){
            if(board[x+2][y-1] == 'N' || board[x+2][y+1] == 'N' || board[x-2][y-1] == 'N' || board[x-2][y+1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+2][y-1] == 'n' || board[x+2][y+1] == 'n' || board[x-2][y-1] == 'n' || board[x-2][y+1] == 'n')
                {return 1;}
        }
    }
    //if king is 1 space away from the right side
    else if(x-2 == 8 && y+1 == 8){
        if(turn == 1){
            if(board[x+2][y-1] == 'N' || board[x+2][y+1] == 'N' || board[x-2][y-1] == 'N' || board[x-2][y+1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+2][y-1] == 'n' || board[x+2][y+1] == 'n' || board[x-2][y-1] == 'n' || board[x-2][y+1] == 'n')
                {return 1;}
        }
    }
    //if king is 1 space away from the top side
    else if(x-1 == 0 && y-2 == 0){
        if(turn == 1){
            if(board[x+1][y-2] == 'N' || board[x+1][y+2] == 'N' || board[x-1][y-2] == 'N' || board[x-1][y+2] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y-2] == 'n' || board[x+1][y+2] == 'n' || board[x-1][y-2] == 'n' || board[x-1][y+2] == 'n')
                {return 1;}
        }
    }
    //if king is 1 space away from the bottom side
    else if(x+1 == 8 && y-2 == 0){
        if(turn == 1){
            if(board[x+1][y-2] == 'N' || board[x+1][y+2] == 'N' || board[x-1][y-2] == 'N' || board[x-1][y+2] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y-2] == 'n' || board[x+1][y+2] == 'n' || board[x-1][y-2] == 'n' || board[x-1][y+2] == 'n')
                {return 1;}
        }
    }
    //if king is in square B7
    else if(x == 1 && y == 1){
        if(turn == 1){
            if(board[x-2][y+1] == 'N' || board[x-2][y-1] == 'N' || board[x+1][y+2] == 'N' || board[x-1][y+2] == 'N')
                {return 1;}
        }
        else{
            if(board[x-2][y+1] == 'n' || board[x-2][y-1] == 'n' || board[x+1][y+2] == 'n' || board[x-1][y+2] == 'n')
                {return 1;}
        }
    }
    //if king is in square G7
    else if(x == 1 && y == 7){
        if(turn == 1){
            if(board[x-2][y+1] == 'N' || board[x-2][y-1] == 'N' || board[x+1][y-2] == 'N' || board[x-1][y-2] == 'N')
                {return 1;}
        }
        else{
            if(board[x-2][y+1] == 'n' || board[x-2][y-1] == 'n' || board[x+1][y-2] == 'n' || board[x-1][y-2] == 'n')
                {return 1;}
        }
    }
    //if king is in square B2
    else if(x == 7 && y == 1){
        if(turn == 1){
            if(board[x+2][y+1] == 'N' || board[x+2][y-1] == 'N' || board[x+1][y+2] == 'N' || board[x-1][y+2] == 'N')
                {return 1;}
        }
        else{
            if(board[x+2][y+1] == 'n' || board[x+2][y-1] == 'n' || board[x+1][y+2] == 'n' || board[x-1][y+2] == 'n')
                {return 1;}
        }
    }
    //if king is in square G2
    else if(x == 7 && y == 7){
        if(turn == 1){
            if(board[x+2][y+1] == 'N' || board[x+2][y-1] == 'N' || board[x+1][y-2] == 'N' || board[x-1][y-2] == 'N')
                {return 1;}
        }
        else{
            if(board[x+2][y+1] == 'n' || board[x+2][y-1] == 'n' || board[x+1][y-2] == 'n' || board[x-1][y-2] == 'n')
                {return 1;}
        }
    }
    return 0;
}

int isCheck2(char board [8][8], int turn, int x, int y)
{
    int count = 0;
    //down right diagonal
    int bigger;
    int smaller;
    if(y < x){
        bigger = x;
        smaller = y;       
    }
    else{
        bigger = y;
        smaller = x;
    }
    for(int i = 1; i < 8 - bigger; i++)
    {
        if(board[x+i][y+i] != ' ')
        {
            if(turn == 1)
            {
                if(board[x+i][y+i] == 'Q' || board[x+i][y+i] == 'B')
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(count == 0 && board[x+i][y+i] == 'p')
                    {return 1;}
                else if(board[x+i][y+i] == 'q' || board[x+i][y+i] == 'b')
                    {return 1;}
                else
                    break;
            }
        }
        count++;
    }
    count = 0;
    //up right diagonal
    for(int i = 1,l = smaller; l >= 0; l--, i++)
    {
        if(board[x-i][y-i] != ' ')
        {
            if(turn == 1)
            {
                if(count == 0 && board[i][i] == 'P')
                    {return 1;}
                else if(board[i][i] == 'Q' || board[i][i] == 'B')
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(board[i][i] == 'q' || board[i][i] == 'b')
                    {return 1;}
                else
                    break;
            }
        }
        count++;
    }
    count = 0;
    //down left diagonal
    int temp = y-1;
    for(int i = x+1; i < 8 || temp >= 0; i++)
    {
        if(board[i][temp] != ' ')
        {
            if(turn == 1)
            {
                 if(board[i][temp] == 'Q' || board[i][temp] == 'B')
                    {return 1;}
                 else
                    break;
            }
            else
            {
                if(count == 0 && board[i][temp] == 'p')
                    {return 1;}
                else if(board[i][temp] == 'q' || board[i][temp] == 'b')
                    {return 1;}
                else
                    break;
            }
        }
        temp--;
        count++;
    }
    count = 0;
    temp = y+1;
    //up right diagonal
    for(int i = x-1; i >= 0 || temp < 8; i--)
    {
        if(board[i][temp] != ' ')
        {
            if(turn == 1)
            {
                if(count == 0 && board[i][temp] == 'P')
                    {return 1;}
                else if((board[i][temp] == 'Q' || board[i][temp] == 'B') && count != 0)
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(board[i][temp] == 'q' || board[i][temp] == 'b')
                    {return 1;}
                else
                    break;
            }
        }
        temp++;
        count++;
    }
    //left horizontal
    for(int i = y-1; i >= 0 ; i--)    
    {
        if(board[x][i] != ' ')
        {
            if(turn == 1)
            {
                if(board[x][i] == 'Q' || board[x][i] == 'R')
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(board[x][i] == 'q' || board[x][i] == 'r')
                    {return 1;}
                else
                    break;
            }
        }
    }
    //right horizontal
    for(int i = y+1; i < 8; i++)
    {
        if(board[x][i] != ' ')
        {
            if(turn == 1)
            {
                if(board[x][i] == 'Q' || board[x][i] == 'R')
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(board[x][i] == 'q' || board[x][i] == 'r')
                    {return 1;}
                else
                    break;
            }
        }
    }
    count = 0;
    //bottom vertical
    for(int i = x+1; i < 8; i++)
    {
        if(board[i][y] != ' ')
        {
            if(turn == 1)
            {
                if(board[i][y] == 'Q' || board[i][y] == 'R')
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(board[i][y] == 'q' || board[i][y] == 'r')
                    {return 1;}
                else
                    break;     
            }
        }
    }
    //top vetical
    for(int i = x-1; i >= 0; i--)
    {
        if(board[i][y] != ' ')
        {
            if(turn == 1)
            {
                if(board[i][y] == 'Q' || board[i][y] == 'R')
                    {return 1;}
                else
                    break;
            }
            else
            {
                if(board[i][y] == 'q' || board[i][y] == 'r')
                    {return 1;}
                else
                    break;
            }
        }
    }
    //All lines below this is for Knight Check
    if((x-2 >= 0 || x+2 <= 8) && (y-2 >= 0 || y+2 <= 8)){
        if(turn == 1){
            if(board[x-2][y-1] == 'N' || board[x-2][y+1] == 'N' || board[x+2][y-1] == 'N' || board[x+2][y+1] == 'N' || board[x+1][y-2] == 'N' || board[x-1][y-2] == 'N' || board[x+1][y+2] == 'N' || board[x-1][y+2] == 'N')
                {return 1;}
        }
        else{
            if(board[x-2][y-1] == 'n' || board[x-2][y+1] == 'n' || board[x+2][y-1] == 'n' || board[x+2][y+1] == 'n' || board[x+1][y-2] == 'n' || board[x-1][y-2] == 'n' || board[x+1][y+2] == 'n' || board[x-1][y+2] == 'n')
                {return 1;}
        }
    }
    //if king is on top edge
    else if(x == 0 && (y-2 >= 0 || y+2 <= 8)){
        if(turn == 1){
            if(board[x-2][y-1] == 'N' || board[x-2][y+1] == 'N')
                {return 1;}
        }
        else{
            if(board[x-2][y-1] == 'n' || board[x-2][y+1] == 'n')
                {return 1;}
        }
    }
    //if king is on bottom edge
    else if(x == 8 && (y-2 >= 0 || y+2 <= 0)){
        if(turn == 1){
            if(board[x+2][y-1] == 'N' || board[x+2][y+1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+2][y-1] == 'n' || board[x+2][y+1] == 'n')
                {return 1;}
        }
    }
    //if king is on left edge
    else if(y == 0 && (x-2 >= 0 || x+2 <= 0)){
        if(turn == 1){
            if(board[x+1][y+2] == 'N' || board[x-1][y+2] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y+2] == 'n' || board[x-1][y+2] == 'n')
                {return 1;}
        }
    }
    //if king is on right edge
    else if(y == 8 && (x-2 >= 0 || x+2 <= 0)){
        if(turn == 1){
            if(board[x+1][y-2] == 'N' || board[x-1][y-2] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y-2] == 'n' || board[x-1][y-2] == 'n')
                {return 1;}
        }
    }
    //top left corner
    else if(x == 0 && y == 0){
        if(turn == 1){
            if(board[x+1][y+2] == 'N' || board[x+2][y+1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y+2] == 'n' || board[x+2][y+1] == 'n')
                {return 1;}
        }
    }
    //top right corner
    else if(x == 0 && y == 8){
        if(turn == 1){
            if(board[x+1][y-2] == 'N' || board[x+2][y-1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y-2] == 'n' || board[x+2][y-1] == 'n')
                {return 1;}
        }
    }
    //bottom left corner
    else if(x == 8 && y == 0){
        if(turn == 1){
            if(board[x+1][y+2] == 'N' || board[x+2][y+1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y+2] == 'n' || board[x+2][y+1] == 'n')
                {return 1;}
        }
    }
    //bottom right corner
    else if(x == 8 && y == 8){
        if(turn == 1){
            if(board[x+1][y-2] == 'N' || board[x+2][y-1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y-2] == 'n' || board[x+2][y-1] == 'n')
                {return 1;}
        }
    }
    //if king is 1 space away from the left side
    else if(x-2 == 0 && y-1 == 0){
        if(turn == 1){
            if(board[x+2][y-1] == 'N' || board[x+2][y+1] == 'N' || board[x-2][y-1] == 'N' || board[x-2][y+1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+2][y-1] == 'n' || board[x+2][y+1] == 'n' || board[x-2][y-1] == 'n' || board[x-2][y+1] == 'n')
                {return 1;}
        }
    }
    //if king is 1 space away from the right side
    else if(x-2 == 8 && y+1 == 8){
        if(turn == 1){
            if(board[x+2][y-1] == 'N' || board[x+2][y+1] == 'N' || board[x-2][y-1] == 'N' || board[x-2][y+1] == 'N')
                {return 1;}
        }
        else{
            if(board[x+2][y-1] == 'n' || board[x+2][y+1] == 'n' || board[x-2][y-1] == 'n' || board[x-2][y+1] == 'n')
                {return 1;}
        }
    }
    //if king is 1 space away from the top side
    else if(x-1 == 0 && y-2 == 0){
        if(turn == 1){
            if(board[x+1][y-2] == 'N' || board[x+1][y+2] == 'N' || board[x-1][y-2] == 'N' || board[x-1][y+2] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y-2] == 'n' || board[x+1][y+2] == 'n' || board[x-1][y-2] == 'n' || board[x-1][y+2] == 'n')
                {return 1;}
        }
    }
    //if king is 1 space away from the bottom side
    else if(x+1 == 8 && y-2 == 0){
        if(turn == 1){
            if(board[x+1][y-2] == 'N' || board[x+1][y+2] == 'N' || board[x-1][y-2] == 'N' || board[x-1][y+2] == 'N')
                {return 1;}
        }
        else{
            if(board[x+1][y-2] == 'n' || board[x+1][y+2] == 'n' || board[x-1][y-2] == 'n' || board[x-1][y+2] == 'n')
                {return 1;}
        }
    }
    //if king is in square B7
    else if(x == 1 && y == 1){
        if(turn == 1){
            if(board[x-2][y+1] == 'N' || board[x-2][y-1] == 'N' || board[x+1][y+2] == 'N' || board[x-1][y+2] == 'N')
                {return 1;}
        }
        else{
            if(board[x-2][y+1] == 'n' || board[x-2][y-1] == 'n' || board[x+1][y+2] == 'n' || board[x-1][y+2] == 'n')
                {return 1;}
        }
    }
    //if king is in square G7
    else if(x == 1 && y == 7){
        if(turn == 1){
            if(board[x-2][y+1] == 'N' || board[x-2][y-1] == 'N' || board[x+1][y-2] == 'N' || board[x-1][y-2] == 'N')
                {return 1;}
        }
        else{
            if(board[x-2][y+1] == 'n' || board[x-2][y-1] == 'n' || board[x+1][y-2] == 'n' || board[x-1][y-2] == 'n')
                {return 1;}
        }
    }
    //if king is in square B2
    else if(x == 7 && y == 1){
        if(turn == 1){
            if(board[x+2][y+1] == 'N' || board[x+2][y-1] == 'N' || board[x+1][y+2] == 'N' || board[x-1][y+2] == 'N')
                {return 1;}
        }
        else{
            if(board[x+2][y+1] == 'n' || board[x+2][y-1] == 'n' || board[x+1][y+2] == 'n' || board[x-1][y+2] == 'n')
                {return 1;}
        }
    }
    //if king is in square G2
    else if(x == 7 && y == 7){
        if(turn == 1){
            if(board[x+2][y+1] == 'N' || board[x+2][y-1] == 'N' || board[x+1][y-2] == 'N' || board[x-1][y-2] == 'N')
                {return 1;}
        }
        else{
            if(board[x+2][y+1] == 'n' || board[x+2][y-1] == 'n' || board[x+1][y-2] == 'n' || board[x-1][y-2] == 'n')
                {return 1;}
        }
    }
    return 0;
}
int WinCheck(char board [8][8], int turn)
{
    char search;
    int count = 0;
    int x;
    int y;
    int turn2;
    if(turn == 1){
        turn2 = 2;
    }
    else{
        turn2 = 1;
    }
    //used to find King
    if(turn == 1)
        search = 'k';
    else
        search = 'K';
    for(int i = 0; i < 8; i++)
    {
        for(int j = 0; j < 8; j++)
        {
            if(board[i][j] == search)   
            {
                x = i;
                y = j;
            }
        }
    }

    //Checks non-edges
    if(x != 0 && x != 7)   
    {
        if(y != 0 && y != 7)
        {
            for(int i = x-1; i <= x+1; i++)
            {
                for(int j = y-1; i <= y+1; i++)
                {
                    if(CheckMove(board, turn, x, y, i, j) != 0)
                    {
                        count++;
                    }
                }
            }
        }
    }

    //Top Left Corner Check
    else if(x == 0 && y == 0)\
    { 
        if(CheckMove(board, turn, x, y, x, y+1) != 0)
            count++;
        if(CheckMove(board, turn, x, y, x+1, y) != 0)
            count++;
        if(CheckMove(board, turn, x, y, x+1, y+1) != 0)
            count++;
    }
    
    //Top Right Corner Check
    else if(x == 0 && y == 7)
    {
        if(CheckMove(board, turn, x, y, x, y-1) != 0)
            count++;
        if(CheckMove(board, turn, x, y, x+1, y) != 0)
            count++;
        if(CheckMove(board, turn, x, y, x+1, y-1) != 0)
            count++;
    }   

    //Bottom Left Corner Check
    else if(x == 7 && y == 0)
    {
        if(CheckMove(board, turn, x, y, x, y+1) != 0)
            count++;
        if(CheckMove(board, turn, x, y, x-1, y) != 0)
            count++;
        if(CheckMove(board, turn, x, y, x-1, y+1) != 0)
            count++;
    }

    //Bottom Right Corner Check
    else if(x == 7 && y == 7)
    {
        if(CheckMove(board, turn, x, y, x, y-1) != 0)
            count++;
        if(CheckMove(board, turn, x, y, x-1, y) != 0)
            count++;
        if(CheckMove(board, turn, x, y, x-1, y-1) != 0)
            count++;
    }

    //Top Edge Check
    else if(x == 0 && y != 0 && y != 7)
    {
        for(int i = y-1; i <= y+1 ; i++)
        {
            if(CheckMove(board, turn, x, y, 0, i) != 1)
                count++;
            if(CheckMove(board, turn, x, y, 1, i) != 1)
                count++;
        }
    }

    //Bottom Edge Check
    else if(x == 7 && y != 0 && y != 7)
    {
        for(int i = y-1; i <= y+1 ; i++)
        {
            if(CheckMove(board, turn, x, y, 6, i) != 1)
                count++;
            if(CheckMove(board, turn, x, y, 7, i) != 1)
                count++;
        }
    }

    //Left Edge Check
    else if(y == 0 && x != 0 && x != 7)
    {
        for(int i = x-1; i <= x+1 ; i++)
        {
            if(CheckMove(board, turn, x, y, i, 0) != 1)
                count++;
            if(CheckMove(board, turn, x, y, i, 1) != 1)
                count++;
        }
    }

    //Right Edge Check
    else if(y == 7 && x != 0 && x != 7)
    {
        for(int i = x-1; i <= x+1 ; i++)
        {
            if(CheckMove(board, turn, x, y, i, 6) != 1)
                count++;
            if(CheckMove(board, turn, x, y, i, 7) != 1)
                count++;
        }
    }
    int direction = 0;
    int enemyX = -1;
    int enemyY = -1;
    int bigger;
    int smaller;
    //down right diagonal
    if(y < x){
        bigger = x;
        smaller = y;
    }
    else{
        bigger = y;
        smaller = x;
    }
    for(int i = 1; i < 8-bigger; i++)
    {
        if(board[x+i][y+i] != ' ')
        {
            if(turn == 1)
            {
                if(board[x+i][y+i] == 'Q' || board[x+i][y+i] == 'B'){
                    enemyX = x+i;
                    enemyY = y+i;
                    direction = 1;
                }
                else
                    break;
            }
            else
            {
                if(count == 0 && board[x+i][y+i] == 'p'){
                    enemyX = x+i;
                    enemyY = y+i;
                    direction = 1;
                }
                else if(board[x+i][y+i] == 'q' || board[x+i][y+i] == 'b'){
                    enemyX = x+i;
                    enemyY = y+i;
                    direction = 1;
                }
                else
                    break;
            }
        }
        count++;
    }
    count = 0;
    //up left diagonal
    for(int i = 1,l = smaller; l >= 0; l--, i++)
    {
        if(board[x-i][y-i] != ' ')
        {
            if(turn == 1)
            {
                if(count == 0 && board[x-i][y-i] == 'P'){
                    enemyX = x-i;
                    enemyY = y-i;
                    direction = 2;
                }
                else if(board[x-i][y-i] == 'Q' || board[x-i][y-i] == 'B'){
                    enemyX = x-i;
                    enemyY = y-i;
                    direction = 2;
                }
                else
                    break;
            }
            else
            {
                if(board[x-i][y-i] == 'q' || board[x-i][y-i] == 'b'){
                    enemyX = x-i;
                    enemyY = y-i;
                    direction = 2;
                }
                else
                    break;
            }
        }
        count++;
    }
    count = 0;
    //down left diagonal
    int temp = y-1;
    for(int i = x+1; i < 8 || temp > 0; i++)
    {
        if(board[i][temp] != ' ')
        {
            if(turn == 1)
            {
                 if(board[i][temp] == 'Q' || board[i][temp] == 'B'){
                    enemyX = i;
                    enemyY = temp;
                    direction = 3;
                 }
                 else
                    break;
            }
            else
            {
                if(count == 0 && board[i][temp] == 'p'){
                    enemyX = i;
                    enemyY = temp;
                    direction = 3;
                }
                else if(board[i][temp] == 'q' || board[i][temp] == 'b'){
                    enemyX = i;
                    enemyY = temp;
                    direction = 3;
                }   
                else
                    break;
            }
        }
        temp--;
        count++;
    }
    count = 0;
    temp = y+1;
    //up right diagonal
    for(int i = x-1; i >= 0 || temp < 8; i--)
    {
        if(board[i][temp] != ' ')
        {
            if(turn == 1)
            {
                if(count == 0 && board[i][temp] == 'P'){
                    enemyX = i;
                    enemyY = temp;
                    direction = 4;
                }
                else if((board[i][temp] == 'Q' || board[i][temp] == 'B') && count != 0){
                    enemyX = i;
                    enemyY = temp;
                    direction = 4;
                }
                else
                    break;
            }
            else
            {
                if(board[i][temp] == 'q' || board[i][temp] == 'b'){
                    enemyX = i;
                    enemyY = temp;
                    direction = 4;
                }
                else
                    break;
            }
        }
        temp++;
        count++;
    }
    //left horizontal
    for(int i = y-1; i >= 0 ; i--)    
    {
        if(board[x][i] != ' ')
        {
            if(turn == 1)
            {
                if(board[x][i] == 'Q' || board[x][i] == 'R'){
                    enemyX = x;
                    enemyY = i;
                    direction = 5;
                }
                else
                    break;
            }
            else
            {
                if(board[x][i] == 'q' || board[x][i] == 'r'){
                    enemyX = x;
                    enemyY = i;
                    direction = 5;
                }
                else
                    break;
            }
        }
    }
    //right horizontal
    for(int i = y+1; i < 8; i++)
    {
        if(board[x][i] != ' ')
        {
            if(turn == 1)
            {
                if(board[x][i] == 'Q' || board[x][i] == 'R'){
                    enemyX = x;
                    enemyY = i;
                    direction = 6;
                }
                else
                    break;
            }
            else
            {
                if(board[x][i] == 'q' || board[x][i] == 'r'){
                    enemyX = x;
                    enemyY = i;
                    direction = 6;
                }
                else
                    break;
            }
        }
    }
    count = 0;
    //bottom vertical
    for(int i = x+1; i < 8; i++)
    {
        if(board[i][y] != ' ')
        {
            if(turn == 1)
            {
                if(board[i][y] == 'Q' || board[i][y] == 'R'){
                    enemyX = i;
                    enemyY = y;
                    direction = 7;
                }
                else
                    break;
            }
            else
            {
                if(board[i][y] == 'q' || board[i][y] == 'r'){
                    enemyX = i;
                    enemyY = y;
                    direction = 7;
                }
                else
                    break;     
            }
        }
    }
    //top vetical
    for(int i = x-1; i >= 0; i--)
    {
        if(board[i][y] != ' ')
        {
            if(turn == 1)
            {
                if(board[i][y] == 'Q' || board[i][y] == 'R'){
                    enemyX = i;
                    enemyY = y;
                    direction = 8;
                }
                else
                    break;
            }
            else
            {
                if(board[i][y] == 'q' || board[i][y] == 'r'){
                    enemyX = i;
                    enemyY = y;
                    direction = 8;
                }
                else
                    break;
            }
        }
    }
    for(int i = 0; i < 8; i++){
        for(int j = 0; j < 8; j++){
            if(turn == 1){
                if(board[i][j] == 'N'){
                    if(CheckMove(board, turn2, i, j, x, y) == 1){
                        enemyX = i;
                        enemyY = j;
                        direction = 9;
                    }
                }
            }
            else{
                if(board[i][j] == 'n'){
                    if(CheckMove(board, turn2, i, j, x, y) == 1){
                        enemyX = i;
                        enemyY = j;
                        direction = 9;
                    }
                }
            }
        }
    }
    //printf("Direction %d\n", direction);
    int canKill = 0;
    if(direction != 0){
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                if(board[i][j] != ' '){
                    if(CheckMove(board, turn, i, j, enemyX, enemyY) == 1 && SameColor(board, i, j, enemyX, enemyY) == 1 && BlockingPiece(board, i, j, enemyX, enemyY) == 1){
                        canKill = 1;
                        //printf("Kill Piece %d %d\n", i, j);
                        i = 9; 
                        break;
                    }
                }
            }
        }
    }
    int l = smaller;
    int canBlock = 0;
    //down right diagonal
    if(direction == 1){
        for(int i = 1; i< 8 - bigger; i++){
            for(int j = 0; j < 8; j++){
                for(int k = 0; k < 8; k++){
                    if(board[j][k] != ' '){
                        if(CheckMove(board, turn, j, k, x+i, y+i) == 1 && SameColor(board, j, k, x+i, y+i) == 1 && BlockingPiece(board, j, k , x+i, y+i) == 1){
                            canBlock = 1;
                            //printf("Block Piece %d %d\n", j, k);
                            i = j = 9;
                            break;
                        }
                    }
                }
            }
        }
    }
    //up left diagonal
    else if(direction == 2){
        count = 0;
        for(int i = 1; l >= 0 ; l--, i++){
            for(int j = 0; j < 8; j++){
                for(int k = 0; k < 8; k++){
                    if(board[j][k] != ' '){
                        if(CheckMove(board, turn, j, k, i, i) == 1 && SameColor(board, j, k, i, i) == 1 && BlockingPiece(board, j, k, i, i) == 1){
                            canBlock = 1;
                            //printf("Block Piece %d %d\n", j, k);
                            i = -1;
                            j = 9;
                            break;
                        }
                    }
                }
            }
        }
    }
    //down left diagonal
    else if(direction == 3){
        count = 0;
        temp = y-1;
        for(int i = x+1; i < 8 || temp > 0; i++) {
            for(int j = 0; j < 8; j++){
                for(int k = 0; k < 8; k++){
                    if(board[j][k] != ' '){
                        if(CheckMove(board, turn, j, k, i, temp) == 1 && SameColor(board, j, k, i, temp) == 1 && BlockingPiece(board, j, j, i, temp) == 1){
                            canBlock = 1;
                            //printf("Block Piece %d %d\n", j, k);
                            i = j = 9;
                            break;
                        }
                    }
                }
            }
            temp--;
        }
    }
    else if(direction == 4){   
        temp = y+1;
        //up right diagonal
        for(int i = x-1; i >= 0 || temp < 8; i--){
            for(int j = 0; j < 8; j++){
                for(int k = 0; k < 8; k++){
                    if(board[j][k] != ' '){
                        if(i == 6 && j == 6)
                            //printf("yes %c\n", board[i][j]);
                        if(CheckMove(board, turn, j, k, i, temp) == 1 && SameColor(board, j, k, i, temp) == 1 && BlockingPiece(board, j, k, i, temp) == 1){
                            canBlock = 1;
                            //printf("Block Piece %d %d\n", j, k);
                            i = -1;
                            j = 9;
                            break;
                        }
                    }
                }   
            }
            temp++;
        }
    }
    else if(direction == 5){
        //left horizontal
        for(int i = y-1; i >= 0 ; i--){
            for(int j = 0; j < 8; j++){
                for(int k = 0; k < 8; k++){
                    if(board[j][k] != ' '){
                        if(CheckMove(board, turn, j, k, x, i) == 1 && SameColor(board, j, k, x, i) == 1 && BlockingPiece(board, j, k, x, i) == 1){
                            canBlock = 1;
                            //printf("Block Piece %d %d\n", j, k);
                            i = -1;
                            j = 9;
                            break;
                        }
                    }
                }
            }
        }
    }
    else if(direction == 6){
    //right horizontal
        for(int i = y+1; i < 8; i++){
            for(int j = 0; j < 8; j++){
                for(int k = 0; k < 8; k++){
                    if(board[j][k] != ' '){
                        if(CheckMove(board, turn, j, k, x, i) == 1 && SameColor(board, j, k, x, i) == 1 && BlockingPiece(board, j, k, x, i) == 1){
                            canBlock = 1;
     //                       printf("Block Piece %d %d\n", j, k);
                            i = j = 9;
                            break;
                        }
                    }
                }
            }
        }
    }
    else if(direction == 7){
        //bottom vertical
        for(int i = x+1; i < 8; i++){
            for(int j = 0; j < 8; j++){
                for(int k = 0; k < 8; k++){
                    if(board[j][k] != ' '){
                        if(CheckMove(board, turn, j, k, i, y) == 1 && SameColor(board, j, k, i, y) == 1 && BlockingPiece(board, j, k, i, y) == 1){
                            canBlock = 1;
     //                       printf("Block Piece %d %d\n", j, k);
                            i = j = 9;
                            break;
                        }
                    }
                }
            }
        }
    }
    else if(direction == 8){
        //top vetical
        for(int i = x-1; i >= 0; i--){
            for(int j = 0; j < 8; j++){
                for(int k = 0; k < 8; k++){
                    if(board[j][k] != ' '){
                        if(CheckMove(board, turn, j, k, i, y) == 1 && SameColor(board, j, k, i, y) == 1 && BlockingPiece(board, j, k, i, y) == 1){
                            canBlock = 1;
     //                       printf("Block Piece %d %d\n", j, k);
                            i = -1;
                            j = 9;
                            break;
                        }
                    }
                }
            }
        }
    }
    //printf("enemyX %d enemyY %d\n", enemyX, enemyY);
    //printf("canKill %d\n", canKill);
   // printf("canBlock %d\n", canBlock);
    //int yes = isCheck(Board, turn);
    if(count == 0 && isCheck(board, turn) && canKill == 0 && canBlock == 0)
        {return 1;}
    
    return 0;
}

/*
int check_en_passant(char board [8][8], int turn, int w_premove_row, int w_premove_col, int w_postmove_row, int w_postmove_col, 
						  int b_premove_row, int b_premove_col, int b_postmove_row, int b_postmove_col)
{
	int legal=0; //break if en passant condition not met	
	int n; //for loop counter
	
	if (turn==1)//white move
	{
		for(n=0; n<8; n++)
		{
			if(b_premove_row==1 && b_premove_col==n && b_postmove_row==3 && b_postmove_col==n && board[b_postmove_row][b_postmove_col]=='P' 
		           && board[b_premove_row][b_premove_col]==' ')//check condition if black moved pawn 2 squares up
			{
				if(w_premove_row==3 && (w_premove_col==n-1 || w_premove_col==n+1) && w_postmove_row==2 && w_postmove_col=n
				   && board[w_premove_row][w_premove_col]=='p' && board[w_postmove_row][w_postmove_col]==' ') 
					//if white inputs right coordinate
				{
					board[2][n] = 'p';
					board[3][n] = ' ';
					legal=1;
				}
			}
		}
	}

	 if (turn == 2)//black move
	 {
		for(n=0; n<8; n++)
		{
			if(w_premove_row==6 && w_premove_col==n && w_postmove_row==4 && w_postmove_col==n && board[w_postmove_row][w_postmove_col]=='p'
	                && board[w_premove_row][w_premove_col]==' ')//check condition if white moved pawn 2 squares up
			{
				if(b_premove_row==4 && (b_premove_col==n-1 || b_postmove_col==n+1) && b_postmove_row==5 && b_postmove_col=n) //if white inputs right coordinate
				{
					board[5][n] = 'P';
					board[4][n] = ' ';
					legal=1;
				}
			}
		}
	 }

	return legal;
}
*/
/* EOF */
