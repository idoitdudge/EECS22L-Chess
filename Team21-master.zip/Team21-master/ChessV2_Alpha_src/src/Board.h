/*********************************************************************/
/* Board.h                                                           */
/* header file for board structure                                   */ 
/*                                                                   */
/* Authors: Christina Wong                                           */ 
/*          Michael Choi                                             */
/* Modifications:                                                    */
/* 05/10/21 CW  updated Board components for replay                  */
/* 04/25/21 MC  fixed compilation errors                             */
/* 04/24/21 CW  added list functions                                 */
/* 04/23/21 CW  initial version                                      */
/*********************************************************************/

#include <stdio.h>
#include <stdlib.h>

#ifndef BOARD_H
#define BOARD_H

// ***************** PLAYER *****************
//player structure
typedef struct
{
    int pnum; //differentiate player 1 or 2
    char pcolor; //white or black
    int points;
}PLAYER;

//Return the pointer to the player
PLAYER *CreatePlayer(int pnum, char pcolor, int points);

//Free memory for values in PLAYER struct 
void DeletePlayer(PLAYER *player);


// ***************** BOARD ***************** 
typedef struct Board
{
    char newboard[8][8];
    char precol; //pre move column
    char prerow; // pre move row
    char postcol; // post move column
    char postrow; // post move row   
    int player; // who's turn
    
}BOARD;

// Returns the pointer to the board
BOARD *CreateBoard(char board[8][8], int precol, int prerow, int postcol, int postrow, int ai);

//Free memory for values in BOARD struct
void DeleteBoard(BOARD *newboard);

typedef struct BoardList LIST;
typedef struct BoardEntry ENTRY;

struct BoardList 
{
    int Length;
    ENTRY *First;
    ENTRY *Last;
};

struct BoardEntry
{
    LIST *List;
    ENTRY *Next;
    ENTRY *Prev;
    BOARD *board;
};

//allocate a new board entry 
ENTRY *NewBoardEntry(BOARD *newboard);

//deletes a board entry 
BOARD *DeleteBoardEntry(ENTRY *entry);

//allocates a new newboard list 
LIST *NewBoardList(void);

//deletes a board list (and all its entries) 
void DeleteBoardList(LIST *list);

//append a board at the end of the list 
void AppendBoard(LIST *list, BOARD *newboard);

//removes the last newboard from the list 
BOARD *RemoveLastBoard(LIST *list);

// removes last 2 boards in list ~~ used for takeback against ai
BOARD *aitakeback(BOARD *newboard, LIST *list, char board[8][8]);

// removes last board in list ~~ used for take back in HvH
BOARD *humtakeback(BOARD *newboard, LIST *list, char board[8][8]);

#endif

/* EOF */
