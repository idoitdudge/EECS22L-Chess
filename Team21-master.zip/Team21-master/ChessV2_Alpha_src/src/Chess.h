/* Chess.h: main chess function header file */

#include <stdio.h>
#include <stdlib.h>
#include "BoardFunctions.h"
#include "Board.h"

#ifndef BOARDFUNCTIONS_H
#define BOARDFUNCTIONS_H

// Handle Menu Options
int print_menu();

// Settings Menu 
int print_settings();

// Handles Settings Options
void settings(char board[8][8], PLAYER *player1, PLAYER *player2);

//Main function for Chess
int Chess();

#endif 
/* EOF */