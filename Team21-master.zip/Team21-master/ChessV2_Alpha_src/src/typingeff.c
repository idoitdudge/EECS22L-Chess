/*********************************************************************/
/* typingeff.c                                                       */
/* creates "typing effect" for titles                                */ 
/*                                                                   */
/* Authors: Christina Wong                                           */
/* Modifications:                                                    */
/* 05/02/21 CW  initial version                                      */
/*********************************************************************/

#include "BoardFunctions.h"

// to take up time (create delay)
int fib(int n) {
	return n <= 1 ? n : fib(n-1) + fib(n-2);
}

void stall(double seconds) {
	clock_t start = clock(); // initializes to current time 
	clock_t end = clock(); // initializes to current time 
	while((double) (end - start) / CLOCKS_PER_SEC < seconds) {
		fib(10);  // SLOW OPERATION 2^n (tested with 15 and 30) // basically takes up time (creating delay)
		end = clock(); // set end time to new time 
	}
}

void type(char* str, double delay_seconds) {
	int len = strlen(str);
	for (int i = 0; i < len; i++) {
		stall(delay_seconds); // create delay 
		printf("%c", str[i]); // prints one character at a time 
		fflush(stdout); // flushes out buffer created by printf statement 
	}
}


//*** extra functions for countdown that we don't need right now
/*void reset() {
        printf("\x1b[0G\x1b[K");
}

void countdown() {
  for (int i = 30; i >= 0; i--) {
    printf("%d", i);
    fflush(stdout);
    sleep(1);
    reset();
    fflush(stdout);
  }
}*/

/*tried to make program where it constantly updates time but i gave up
#include <time.h>
#include <stdio.h>
int main () {
   clock_time, start_time, end_time;
   int i;

   start_t = clock();
   printf("Starting of the program, start_t = %ld\n", start_t);

   printf("Going to scan a big loop, start_t = %ld\n", start_t);
   for(i=0; i< 10000000; i++) {
   }
   end_t = clock();
   printf("End of the program end_t = %ld\n", end_t);

   return(0);
}*/
