/* ClockClient.c: simple interactive TCP/IP client for ClockServer
 * Author: Rainer Doemer, 2/16/15 (updated 2/20/17)
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include "Chess.h"

/* #define DEBUG */	/* be verbose */

/*** global variables ****************************************************/

const char *Program	/* program name for descriptive diagnostics */
	= NULL;

/*** global functions ****************************************************/

void FatalError(		/* print error diagnostics and abort */
	const char *ErrorMsg)
{
    fputs(Program, stderr);
    fputs(": ", stderr);
    perror(ErrorMsg);
    fputs(Program, stderr);
    fputs(": Exiting!\n", stderr);
    exit(20);
} /* end of FatalError */

/* LOGIN */
// format: LOGIN|USERNAME|PASSWORD
// '|' is the separator that will be turned into a null character when relaying info to server
void Login(char SendBuf[1024]){
	char username[64];
	char password[64];

	printf("\n\x1b[1;34m*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\x1b[0m\n");

//	strcpy(SendBuf, "LOGIN|\0");
	printf("Enter a username: ");
	fflush(stdout);
	scanf("%s", username);
	printf("Enter a password: ");
	fflush(stdout);
	scanf("%s", password);
	
	printf("\x1b[1;34m*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\x1b[0m\n");
	
	strncat(SendBuf, username, strlen(username));
	strcat(SendBuf, "|");
	strncat(SendBuf, password, strlen(password));
	strcat(SendBuf, "|");
	strcat(SendBuf, "l");
} /* end of Login */

void Register(char SendBuf[1024]){
	//int spaces = 0; // checks for spaces in input
	//int separator = 0; // looks for '|'
	//int validuser = 0; // checks for valid username
	//int validpass = 0; // checks for valid password
	//int l = 0; // length 
	int i; // used in for loops
	//char tempuser[64]; // to hold username before checking validity
	//char temppass[64]; // to hold password before checkign validity
	char username[64]; // to hold finalized username
	char password[64]; // to hold finalized password
	
	// DESIGN
	printf("\n\x1b[1;34m*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\n");
	type("\t\tHello New User!", 0.075);
	printf("\n*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\x1b[0m\n"
			"\x1b[1;36m***Restrictions:\n\t1.) Do not use the symbol '|'\n"
			"\t2.) Do not use spaces\n"
			"\t3.) Length is limited to 63 characters\n\x1b[0m");
	printf("\x1b[1;34m*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\x1b[0m\n");

	/* CHECK VALIDITY OF USERNAME */
	//while (validuser == 0){ // keeps running until a valid username is entered
		printf("Please enter a username: ");
		scanf("%s", username);

		/*if (l < 64){ // if length of username is within limit (valid length-wise)
			for (i = 0; i < 64; i++){
				if (username[i] == '|'){
					separator++; // track if username uses our designated separator 
				}
				// THIS DOESN'T WORK RN
				if (username[i] == ' '){ // IDEA: convert spaces to '-' (like in discord)
					spaces++; // track spaces in username
				}
			}
			if (separator == 0){
				//for (i = 0; i < l; i++){
				//	username[i] = tempuser[i]; // if passes tests, set input to username
				//}
                
				validuser = 1; // breaks out of loop with legal username
			}
		}
		if (separator > 0){ // if username contains '|', invalid
			printf("\x1b[1;31mInvalid username!\x1b[0m Cannot contain '|' in username. Try again!\n");
			separator = 0; // reset for next input
		}
		if (spaces > 0){ // if username contains ' ', invalid
			printf("\x1b[1;31mInvalid username!\x1b[0m Cannot contain spaces in username. Try again!\n");
			spaces = 0; // reset for next input
		}
		if (l > 64){
			printf("\x1b[1;31mInvalid username!\x1b[0m Exceeded character limit. Try again!\n");
		} */
	//}

	//separator = 0;
	//spaces = 0;
	//l = 0;

	/* CHECK VALIDITY OF PASSWORD */
	//while (validpass == 0){
		printf("Please enter a password: ");
		scanf("%s", password);
        /*
		if (l < 64){ // if length of password is within limit (valid length-wise)
			for (i = 0; i < 64; i++){
				if (password[i] == '|'){
					separator++; // track if password uses our designated separator 
				}
				// SPACES DON'T DO ANYTHING RN
				if (password[i] == ' '){ // IDEA: convert spaces to '-' (like in discord)
					spaces++; // track spaces in password
				}
			}
			if (separator == 0){
				validpass = 1; // breaks out of loop with legal password
			}
		}
		if (separator > 0){ // if password contains '|', invalid
			printf("\x1b[1;31mInvalid password!\x1b[0m Cannot contain '|' in password. Try again!\n");
			separator = 0; // reset for next input
		}
		if (spaces > 0){ // if password contains ' ', invalid
			printf("\x1b[1;31mInvalid password!\x1b[0m Cannot contain spaces in password. Try again!\n");
			spaces = 0; // reset for next input
		}
		if (l > 64){
			printf("\x1b[1;31mInvalid password!\x1b[0m Exceeded character limit. Try again!\n");
		}*/
	//}
	strncat(SendBuf, username, strlen(username));
	strcat(SendBuf, "|"); // adding separator (for reading later)
	strncat(SendBuf, password, strlen(password));
	strcat(SendBuf, "|"); // adding separator (for reading later)
	strcat(SendBuf, "r");

	printf("\x1b[1;34m*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\x1b[0m\n");
}

int main(int argc, char *argv[])
{
    int l, n;
	int token; // for identifying unique clients
    int SocketFD,	/* socket file descriptor */
	PortNo;		/* port number */

    struct sockaddr_in
	ServerAddress;	/* server address we connect with */

    struct hostent
	*Server;	/* server host */

    char SendBuf[1024];	/* message buffer for sending a message */
    char RecvBuf[1024];	/* message buffer for receiving a response */

	char move[4]; // holds player's move
	int option; // holds user's choice from menu

	char board[8][8] = {{ 'R' , 'N' , 'B' , 'Q' , 'K' , 'B' , 'N' , 'R' },
                        { 'P' , 'P' , 'P' , 'P' , 'P' , 'P' , 'P' , 'P' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { 'p' , 'p' , 'p' , 'p' , 'p' , 'p' , 'p' , 'p' },
                        { 'r' , 'n' , 'b' , 'q' , 'k' , 'b' , 'n' , 'r' }};

    Program = argv[0];	/* publish program name (for diagnostics) */

    if (argc < 3)
    {   fprintf(stderr, "Usage: %s hostname port\n", Program);
	exit(10);
    }

    Server = gethostbyname(argv[1]);

    if (Server == NULL)
    {   fprintf(stderr, "%s: no such host named '%s'\n", Program, argv[1]);
        exit(10);
    }

    PortNo = atoi(argv[2]);

    if (PortNo <= 2000)
    {   fprintf(stderr, "%s: invalid port number %d, should be >2000\n",
		Program, PortNo);
        exit(10);
    }

    ServerAddress.sin_family = AF_INET;
    ServerAddress.sin_port = htons(PortNo);
    ServerAddress.sin_addr = *(struct in_addr*)Server->h_addr_list[0];
	
	int lobby = 0;	
	int service = 1;
	do {
	//while (service) {
	/* LOGIN / REGISTRATION */
	SocketFD = socket(AF_INET, SOCK_STREAM, 0);
	if (SocketFD < 0)
    {   FatalError("socket creation failed");
	}

	printf("%s: Connecting to the server at port %d...\n", Program, PortNo);
	if (connect(SocketFD, (struct sockaddr*)&ServerAddress,	sizeof(ServerAddress)) < 0)
	{   FatalError("connecting to server failed");
   	}
    	
	if (lobby == 1){
		strcpy(SendBuf, "LOBBY");
	
		l = strlen(SendBuf);

		n = write(SocketFD, SendBuf, l);
	   		if (n < 0)
	    		{   FatalError("writing to socket failed");
			}

		n = read(SocketFD, RecvBuf, sizeof(RecvBuf)-1);
	    		if (n < 0) 
			{   FatalError("reading from socket failed");
    			}

		RecvBuf[n] = 0;
		
		if(0 == strcmp(RecvBuf, "CHESS")){
			print_board(board);
			//Chess();
			//printf("Hello");
			service = 2;
			close(SocketFD);
		}
		else if (0 == strcmp(RecvBuf, "WAIT")){
			close(SocketFD);
			service = 0;
		}
	}
        else {
    printloginmenu();
	scanf("%d", &option); 
    
	while (option > 3){
		printf("\x1b[1;31mInvalid option!\x1b[0m Please choose another option: ");
		fflush(stdout);
		scanf("%d ", &option); 
		getchar();
	}
	
	//printf("\n%s \n", SendBuf);
	while(option != 3){
		if (option == 1){
		//	strcpy(SendBuf, "REGISTER");
		///	n = read(SocketFD, RecvBuf, sizeof(RecvBuf)-1);
		//	RecvBuf[n] = 0;
		//	if (0 == strcmp(RecvBuf, "NEWREG")){
			Register(SendBuf);
			printf("\n%d, %s \n", option, SendBuf);
		//	}
		}
		else if (option == 2){
			Login(SendBuf);
			printf("\n%d, %s \n", option, SendBuf);
	//		strcpy(SendBuf, "GAME");      // hardcode starts the program 
		}
		
//		strcpy(SendBuf, "SHUTDOWN");
		l = strlen(SendBuf);

		n = write(SocketFD, SendBuf, l);
	    if (n < 0)
	    {   FatalError("writing to socket failed");
		}

		n = read(SocketFD, RecvBuf, sizeof(RecvBuf)-1);
	    if (n < 0) 
		{   FatalError("reading from socket failed");
    	}

		RecvBuf[n] = 0;
	    
	    printf("%s: Received response: %s\n", Program, RecvBuf);
	    
	    // receives from server to start a game 
	    if (0 == strcmp(RecvBuf, "START")){
			Chess();
			//strcpy(SendBuf, "SHUTDOWN");
		}
	   if(0 == strcmp(RecvBuf, "Success")) {
			printf("login successful");
			//Chess();
			printf("Welcome to the game lobby! \n");
			printf("waiting for other players...");
			lobby = 1;
		//	service = 0;
		}
		//strcpy(SendBuf, "SHUTDOWN");
		close(SocketFD);
	//	strncpy(SendBuf, "", sizeof(SendBuf));
		SendBuf[0] = '\0';
		break;
	}
	if (option == 3) {
		break;
	}
	}
	}while (service == 1);
    close(SocketFD);
    printf("%s: Exiting...\n", Program);
    
    return 0;
}


/* EOF client.c */
