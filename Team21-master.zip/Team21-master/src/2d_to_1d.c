
#include <stdio.h>
#include <stdlib.h>

void print_2d_board(char board[8][8]);
void convert_2d_to_1d(char board_2d[8][8], char board_1d[64]);
void convert_1d_to_2d(char board_2d[8][8], char board_1d[64]);

int main(){
char board_1d[64];
char board_2d[8][8] = {{ 'R' , 'N' , 'B' , 'Q' , 'K' , 'B' , 'N' , 'R' },
                        { 'P' , 'P' , 'P' , 'P' , 'P' , 'P' , 'P' , 'P' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { 'p' , 'p' , 'p' , 'p' , 'p' , 'p' , 'p' , 'p' },
                        { 'r' , 'n' , 'b' , 'q' , 'k' , 'b' , 'n' , 'r' }};

print_2d_board(board_2d);

convert_2d_to_1d(board_2d, board_1d);

convert_1d_to_2d(board_2d, board_1d);

return 0;
}


void convert_1d_to_2d(char board_2d[8][8], char board_1d[64])
{
int z;
int x, y;
int k=0;
/*set to x(for testing"*/
for (z=0; z<64; z++)
{
board_1d[z]='x';
printf(" %c ", board_1d[z]);
}

//set 1d to 2d

for(x=0; x<8; x++)
{
	
	for(y=0; y<8; y++)
	{
		board_2d[x][y]=board_1d[k];

		k++;

	}

}

	print_2d_board(board_2d);
}


//conver to 1d
void convert_2d_to_1d(char board_2d[8][8], char board_1d[64])
{

int z=0; 
int k=0;
int x, y;
//convert to 1d array
for(x=0; x<8; x++)
{
	
	for(y=0; y<8; y++)
	{
		board_1d[k] = board_2d[x][y];

//		printf(" %c ", board_1d[k]);
		k++;

	}

//printf(" %c ", board_1d[k]);
}

for (z=0; z<64; z++)
{
printf(" %c ", board_1d[z]);
}
}


// This function prints the board 
void print_2d_board(char board[8][8]){
    int i, j, k;
	
	printf("\n"); // formatting
	
    for(k = 0; k < 8; k++){
        printf("  "); // leave space for vertical indeces
    
        // prints a set of dash lines (row separation)
        for(i = 0; i < 33; i++){ 
            printf("-"); 
        } 
        printf("\n"); 
        
        int a = 8;
        // printf("%d ", k + 1);  // prints vertical indeces from 1-8
        printf("%d ", a - k); // prints vertical indeces from 8-1 
        
        // prints character at the location with adjacent borders
        for(j = 0; j < 8; j++){
            if (j % 2 == 0){
                if (k % 2 != 0)
                    printf("|\x1b[1;37;5;40m %c \x1b[0m", board[k][j]); // white font, black background
                else 
                    printf("|\x1b[1;37;5;44m %c \x1b[0m", board[k][j]); // black font, white background
            }else{
                if (k % 2 == 0)
                    printf("|\x1b[1;37;5;40m %c \x1b[0m", board[k][j]); // white font, black background
                else 
                    printf("|\x1b[1;37;5;44m %c \x1b[0m", board[k][j]); // black font, white background
            }
        }
        printf("| \n");
    }

    printf("  "); // formatting of last line of dashes
    
    // prints last line of dashes 
    for(i = 0; i < 33; i++){ 
        printf("-"); 
    }
    printf("\n ");

    // prints horizontal indeces A-H 
    for(i = 65; i < 73; i++){
        printf("   %c", i);
    }
    printf("\n\n");
}
