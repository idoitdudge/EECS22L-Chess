/* header file for account_creator */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	char* username;
	char* password;
	int online;
} Account;

//const char ACCOUNT_FILE[] = "accounts.ssv";
//const int MAX_ACCOUNTS = 1024;

//const int MAX_USERNAME_LENGTH = 64;
//const int MAX_PASSWORD_LENGTH = 64;

int number_of_accounts(Account** all_accounts);

Account** load_accounts();

void save_accounts(Account** all_accounts);

void print_account(Account* a);

int add_one_account(Account** all_accounts, char* username, char* password);

int remove_one_account(Account** all_accounts, char* username);



