#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "account_creator.h"
/*typedef struct {
	char* username;
	char* password;
	int online;
} Account; // pointer array that holds pointers to specific account information
*/
const char ACCOUNT_FILE[] = "accounts.ssv";	// Space separated values format
const int MAX_ACCOUNTS = 1024;	// 2^2 = 4, 2^4 = 16, 2^6 = 64, 2^8 = 256, 2^10 = 1024, 2^12 = 4096
const int MAX_USERNAME_LENGTH = 64;
const int MAX_PASSWORD_LENGTH = 64;

/* returns number of accounts in the pointer array */
int number_of_accounts(Account** all_accounts) {
	int num = 0;
	for (int i = 0; i < MAX_ACCOUNTS; i++) {  // keeps number of accounts in range of our limit
		if (all_accounts[i] == NULL) return num;  //stops when there are no more accounts
		num++; // otherwise, keep counting accounts
	}
	return num;
}

/* loads all account info to be put into the array of pointers to reference later */
Account** load_accounts() {
	FILE* fp;
	fp = fopen(ACCOUNT_FILE, "r"); // open for reading

	Account** all_accounts = calloc(MAX_ACCOUNTS, sizeof(Account*)); // allocating memory and for 1024 account pointers 

	while (1) {
		Account* a = malloc(sizeof(Account)); // allocating memory for a single account
		a->username = calloc(MAX_USERNAME_LENGTH + 1, sizeof(char)); // allocating memory for username
		a->password = calloc(MAX_USERNAME_LENGTH + 1, sizeof(char)); // allocating memory for password
		a->online = 0; // automatically setting status to "offline"
		
		if (a == NULL) {
			// TOOD: Handlecleanup
		}

		// USERNAME PASSWORD ONLINE < format
		// fscanf() returns 1 for every matched argument; returns 0 if not matched 
		int matched = fscanf(fp, "%s %s %d\n", a->username, a->password, &(a->online));
		// fscanf() must take in 3 arguments --> return 3

		if (matched < 3) { 
			free(a);
			break;
		} 
		else {
			// Check for overflow (makes sure it doesn't exceed length limit)
			a->username[MAX_USERNAME_LENGTH] = '\0'; 
			a->password[MAX_PASSWORD_LENGTH] = '\0';

			// Got the account!
			int idx = number_of_accounts(all_accounts);	// Current index 
			if (idx == MAX_ACCOUNTS) {
				// Too many stored accounts
				// Handle errors if you want
				free(a);
				break;
			}
			all_accounts[idx] = a; // put account into the array of account pointers
		}
	}
	fclose(fp); // ALWAYS close -- will leak data
	return all_accounts;
}

/* updates account info in file */
void save_accounts(Account** all_accounts) {
	FILE* fp; // File pointer
	fp = fopen(ACCOUNT_FILE, "w"); // open for writing
	for (int i = 0; i < number_of_accounts(all_accounts); i++) {
		Account* a = all_accounts[i];
		fprintf(fp, "%s %s %d\n", a->username, a->password, a->online);
	}
	// You need to free things on your own later
	fclose(fp);
}

/* prints account info for specified account */
void print_account(Account* a) {
	printf("Username: %s\nPassword: %s\nStatus: %s\n---\n", a->username, a->password, a->online ? "ONLINE" : "OFFLINE");
}

/* get account information for specified account */
Account* get_one_account(Account** all_accounts, char* username) {
	for (int i = 0; i < number_of_accounts(all_accounts); i++) {  // find account that corresponds with specified username
		if (strcmp(all_accounts[i]->username, username) == 0) {
			// We have a match
			return all_accounts[i];
		}
	}
	return NULL;
}

// CRITICAL FUNCTION
/* creates new account */
// Returns 1 if success and 0 if failed
int add_one_account(Account** all_accounts, char* username, char* password) {
	if (get_one_account(all_accounts, username) != NULL) return 0; // return 0 if an account with the same username is 
	if (number_of_accounts(all_accounts) == MAX_ACCOUNTS) return 0;
	Account* a = malloc(sizeof(Account)); // allocates memory for the new account
	a->username = username;
	a->password = password;
	a->online = 0;
	all_accounts[number_of_accounts(all_accounts)] = a;
	return 1; // If you want to handle errors; you can do so here
}

// CRITICAL FUNCTION
/* remove specified account's information */
int remove_one_account(Account** all_accounts, char* username) {
	int len = number_of_accounts(all_accounts); // numbe of accounts
	for (int i = 0; i < len; i++) {
		if (strcmp(all_accounts[i]->username, username) == 0) {
			// We have a match
			// First: clean it up
			//Account* a = all_accounts[i]; 
			//free(a->username); // uncomment when we use variables in the parameters rather than hardcoding the string
			//free(a->password);
			//free(a);
			if (i == len - 1) {
				all_accounts[i] = NULL;
			} else {
				// Not the last account
				all_accounts[i] = all_accounts[len - 1]; // Moving the last pointer to current index
				all_accounts[len - 1] = NULL;
			}
			return 1;
		}
	}
	return 0;
}

// ALWAYS SAVE THE FILE AFTER YOU MODIFY AN ACCOUNT (use save_accounts to save)
/*int main() {
	Account** all_accounts = load_accounts(); // Now load into memory
	for (int i = 0; i < number_of_accounts(all_accounts); i++) {
		all_accounts[i]->online = 0; 
		print_account(all_accounts[i]);
	}
	printf("Add success: %d\n", add_one_account(all_accounts, "Hello", "Nice"));
	printf("Add success: %d\n", add_one_account(all_accounts, "Hello", "Bro"));
	remove_one_account(all_accounts, "Hello");
    printf("test\n");
	save_accounts(all_accounts);		// Technically, you should save sparsely (save in critical areas)
	printf("TIME TO FETCH:\n");
	print_account(get_one_account(all_accounts, "username"));
	return 0;
}*/
