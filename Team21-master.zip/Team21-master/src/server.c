/* server.c */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <time.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <assert.h>
#include "Chess.h"
#include "account_creator.h"

// type definitions
typedef void (*ClientHandler)(int DataSocketFD); //  
typedef void (*TimeoutHandler)(void); // variable used in parameter of ServerMainLoop as a function caller (calls )

// global variables
const char *Program = NULL; // program name for descriptive diagnostics
int Shutdown = 0; // keep running until Shutdown == 1
char ClockBuffer[26] = ""; // current time in printable format

/*** global functions ****************************************************/

/* prints error diagnostics and abort */
void FatalError(const char *ErrorMsg){ 
	// stderr = standard error message
	fputs(Program, stderr); // adding program name to error message
	fputs(": ", stderr); // adding :
	perror(ErrorMsg); // error message (what's wrong)
	fputs(Program, stderr); 
	fputs(": Exiting!\n", stderr);
	exit(20);
} /* end of FatalError */

/* creates a socket on this server */
int MakeServerSocket(uint16_t PortNo){ 
    int opt = 1;
	int ServSocketFD;
    struct sockaddr_in ServSocketName;

    ServSocketFD = socket(PF_INET, SOCK_STREAM, 0); // creates socket 

    if (ServSocketFD < 0){   
        FatalError("service socket creation failed");
    }

	if( setsockopt(ServSocketFD, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, 
          sizeof(opt)) < 0 )  
    {  
        perror("setsockopt");  
        exit(EXIT_FAILURE);  
    }  
     
 	int flags = fcntl(ServSocketFD, F_GETFL, fcntl (ServSocketFD, F_GETFL, 0) | O_NONBLOCK);
	if (flags == -1){
  		perror("calling fcntl");
  		// handle the error.  By the way, I've never seen fcntl fail in this way
	}   
    /* bind the socket to this server */
    ServSocketName.sin_family = AF_INET; // connects server to internet domain
	ServSocketName.sin_port = htons(PortNo); // sets server to specified port number
	ServSocketName.sin_addr.s_addr = htonl(INADDR_ANY); // sets server to an unspecified host server
	
   // bind(int socketfd, sockaddr, addrlen): binds socket to the address & port number specified
	if(bind(ServSocketFD, (struct sockaddr*)&ServSocketName, sizeof(ServSocketName)) < 0){
		FatalError("binding the server to a socket failed");
	}

	// listen(int sockfd, int backlog): puts server socket in passive mode, where it waits for 
	//				the client to approach the server to make a connection
	if(listen(ServSocketFD, 5) < 0){
		FatalError("listening to socket failed");
	}

    return ServSocketFD;
} /* end of MakeServerSocket */

/* prints/updates the current real time */
void PrintCurrentTime(void){
    time_t CurrentTime; // seconds since 1970
	char *TimeString; // printable time string
	char Wheel, *WheelChars = "|/-\\"; // spinning wheel animation
	static int WheelIndex = 0;

    CurrentTime = time(NULL); // get current real time (in seconds)
	TimeString = ctime(&CurrentTime); // converts time_t value to string
	strncpy(ClockBuffer, TimeString, 25); // copies 25 characters from CLockBuffer to TimeString
	ClockBuffer[24] = 0; // remove unwanted '\n' at then end
    
    WheelIndex = (WheelIndex + 1) % 4; // decides index of WheelChars
	Wheel = WheelChars[WheelIndex]; // prints the stage of the wheel
	// \r -- prints from beginning of current line
	printf("\rClock: %s %c", ClockBuffer, Wheel); // prints time plus a rotating wheel
	fflush (stdout); // flushes out the buffer created by the printf statement	
} /* end of PrintCurrentTime */

/* process a time request by a client */
void ProcessRequest(int DataSocketFD){ 
	int l; // stores string length of input SendBuf
	int n; // stores return value of read() and write()
	char SendBuf[1024]; // message buffer for sending a message
					   // stores input data in buffer
	char RecvBuf[1024]; // message buffer for receiving a response
					   // stores output data in buffer

	n = read(DataSocketFD, RecvBuf, sizeof(RecvBuf) - 1); // reading received message from buffer
    if (n < 0){
		FatalError("reading from data socket failed");
	}

    RecvBuf[n] = 0; // sets last character of buffer to NULL
#ifdef DEBUG
    printf("%s: Received message: %s\n", Program, RecvBuf);
#endif

    if (0 == strcmp(RecvBuf, "TIME")){ // checking if input command was TIME
		strncpy(SendBuf, "OK TIME: ", sizeof(SendBuf) - 1); // putting text into buffer to send to user (limited to size of SendBuf)
		SendBuf[sizeof(SendBuf) - 1] = 0; // last character = NULL
		strncat(SendBuf, ClockBuffer, sizeof(SendBuf) - 1 - strlen(SendBuf)); // concatentate printable clock information
	}
	else if (0 == strcmp(RecvBuf, "SHUTDOWN")){
		Shutdown = 1;
		strncpy(SendBuf, "OK SHUTDOWN", sizeof(SendBuf) - 1); // putting text into buffer to send to user
		SendBuf[sizeof(SendBuf) - 1] = 0; // last character = NULL
	}
	else if (0 == strcmp(RecvBuf, "GAME")){
		strncpy(SendBuf, "Starting the chess game...", sizeof(SendBuf) - 1); 
		//printf("\n%s\n", SendBuf);
		//Chess(SendBuf);
		//printf("\n%s\n", SendBuf);
		SendBuf[sizeof(SendBuf) - 1] = 0;
		//Chess();
		strncpy(SendBuf, "START", sizeof(SendBuf) -1);
	} 
/*	else if (0 == strcmp(RecvBuf, "REGISTER")){
		SendBuf[sizeof(SendBuf) -1] = 0;
		strncpy(SendBuf, "NEWREG", sizeof(SenfBuf) -1);
	}*/
/*	else{ //if (0 == strcmp(RecvBuf, "REGISTER2")){
		FILE *fp;
		fp = fopen("registrations.txt", "w");
		if (fp == NULL){
			printf("Error opening file");
			exit(1);
		}
		char *writeaccount = RecvBuf;
		fprintf(fp,"%s", writeaccount);
		fclose(fp);
	//	strncpy(SendBuf, "ERROR unkown command ",sizeof(SendBuf) - 1); // putting text into buffer to send to user
		strncpy(SendBuf, "Information stored", sizeof(SendBuf) - 1);
		SendBuf[sizeof(SendBuf) - 1] = 0; // last character = NULL
		strncat(SendBuf, RecvBuf, sizeof(SendBuf) - 1 - strlen(SendBuf)); // concatentate received message
		
	}*/
	else if (0 == strcmp(RecvBuf, "LOBBY")){
		int onlines = 0;
		
		Account** all_accounts = load_accounts();
        	for(int i = 0; i < number_of_accounts(all_accounts); i++){
			if (all_accounts[i]->online == 1) {
			//strncpy(SendBuf, "CHESS", sizeof(SendBuf));
			onlines += 1;
			}
		}	
		if (onlines != 2) {
			strncpy(SendBuf, "WAIT", sizeof(SendBuf));
		}
		else if (onlines ==2) {
			strncpy(SendBuf, "CHESS", sizeof(SendBuf));
		}
	}
	else {
        char username[64];
        char password[64];
        int place = 0;
	    char reglog; 

        for(int i = 0; i < strlen(RecvBuf); i++){
          if(RecvBuf[i] != '|'){
                username[i] = RecvBuf[i];
                
            } 
	        else {
		        place = i;
		        break;
		    }
        }
        int c = 0;
        while(c < strlen(RecvBuf) - 4){
            if(RecvBuf[place + c + 1] == '|'){
                break;
            }
            password[c] = RecvBuf[place + c + 1];
            c++;
        }
        username[place] = '\0';
        password[c] = '\0';
//	for(int u = place2+1; u < strlen(RecvBuf); u++){
//		reglog[u] = RecvBuf[u];	
//	}
	reglog = RecvBuf[strlen(RecvBuf) -1];
//	printf("%s",reglog);

        //strncpy(SendBuf, "Success", sizeof(SendBuf) - 1);
		//Account** all_accounts = load_accounts();
		/*for (int i = 0; i < number_of_accounts(all_accounts); i++) {
			all_accounts[i]->online = 0;
			print_account(all_accounts[i]);
		}*/
//	if (0 == strncmp(reglog, "reg", 4)){
 	if (reglog == 'r') { 
		Account** all_accounts = load_accounts();
        int k = add_one_account(all_accounts, username, password);
		save_accounts(all_accounts);
		strncpy(SendBuf, password, sizeof(SendBuf)-1);
        }
	else if (reglog == 'l'){
		Account** all_accounts = load_accounts();
        for(int i = 0; i < number_of_accounts(all_accounts); i++){
            if(strcmp(all_accounts[i]->username, username) == 0 && strcmp(all_accounts[i]->password, password) == 0){
                strncpy(SendBuf, "Success", sizeof(SendBuf)-1);
                all_accounts[i]->online = 1;
         //       print_account(all_accounts[i]);
                save_accounts(all_accounts);
                break;
            }
	    else {
		strncpy(SendBuf, "Login failed", sizeof(SendBuf)-1);
		} 
        }
	}
	else{
		strncpy(SendBuf, "Fail", sizeof(SendBuf)-1);
	}
	}

	l = strlen(SendBuf); // string length of buffer to be sent 

#ifdef DEBUG
	printf("%s: Sending response: %s.\n", Program, SendBuf);
#endif

	n = write(DataSocketFD, SendBuf, l); // writes from buffer to file

	if (n < 0){
		FatalError("writing to socket failed");
	}
} /* end of ProcessRequest */

/* simple serer main loop */
void ServerMainLoop(  
	int ServSocketFD,  // server socket file to wait on
	ClientHandler HandleClient, // client handler to call
	TimeoutHandler HandleTimeout, // timout handler to call
	int Timeout){ // timeout: specifies max interval to wait for the selection to complete

	int DataSocketFD [5]; // socket for a new client
	// socklen_t: integer type of width of at least 32 bits
	int max_sd, valread;
	char buffer [1024];
	socklen_t ClientLen; // size of address
	
	int new_socket, sd;

	struct sockaddr_in
	ClientAddress; // client address we connect with

	// fd_set: sets the bit for the file descriptor fd in teh file descriptor set fdset
	fd_set ActiveFDs; // socket file descriptors to select from
	fd_set ReadFDs; //socket file descriptors ready to read from 

	struct timeval TimeVal; // specifies a maximum interval to wait for the selection to complete
	int res; // used to check return value of select()
	int i; // used in for loop

	for (i = 0; i < 5; i++)
		DataSocketFD[i] = 0;

	//FD_ZERO(&ActiveFDs); // set of active sockets
	//FD_SET(ServSocketFD, &ActiveFDs); // server socket is active

    while(!Shutdown){
		FD_ZERO(&ActiveFDs); // set of active sockets
		FD_SET(ServSocketFD, &ActiveFDs); // server socket is active
		ReadFDs = ActiveFDs; // read the active server socket
		TimeVal.tv_sec = Timeout / 1000000; // seconds
		TimeVal.tv_usec = Timeout % 1000000; // microseconds 
		
		max_sd = ServSocketFD;
						
		for ( i = 0; i < 5; i++)
			{
				sd = DataSocketFD[i];
				printf("%d", sd);
				if (sd > 0)
					FD_SET ( sd, &ReadFDs);

				if (sd > max_sd)
					max_sd = sd;
			}

	    /* block until input arrives on active sockets or until timeout */
		res = select(max_sd + 1, &ReadFDs, NULL, NULL, &TimeVal); // block until input arrives on active sockets or until timeout
	    if ((res < 0) && (errno != EINTR)){
			printf ("\n%d\n", res);
			FatalError("wait for input or timeout (select) failed ");
		}
        
        if (res == 0){
#ifdef DEBUG
			printf("%s: Handling timeout...\n", Program);
#endif
			HandleTimeout();
		}

        else{ // some FDs have data ready to read			
			for (i = 0; i < FD_SETSIZE; i++){
				// FD_ISSET(): returns a non-zero value if the bit for the file descriptor fd is set in the file descriptor set pointed by the fdset, and 0 otherwise
				if (FD_ISSET(i, &ReadFDs)){
					if(i == ServSocketFD){ // connection request on a server socket
#ifdef DEBUG
						printf("%s: Accepting new client %d...\n", Program, i);
#endif
						ClientLen = sizeof(ClientAddress); // set to string length of client address
						// accept(socketfd, sockaddr, addrlen): accepts a connection request from a client
						// when a connection is available, socket created is ready to use to read data 
						new_socket = accept(ServSocketFD, (struct sockaddr*)&ClientAddress, &ClientLen);						
						if(new_socket < 0){
							FatalError("data socket creation (accept) failed");
						}
#ifdef DEBUG
						printf("%s: Client %d connected from %s: %hu.\n", 
									Program, i, 
									inet_ntoa(ClientAddress.sin_addr), // converts Internet host address from IPv4 numbers&dots notation into binary 
									ntohs(ClientAddress.sin_port)); // converts unsigned integer from network byte to host byte order
#endif						
						//FD_SET(DataSocketFD, &ActiveFDs); // setting current data socket as active socket
						for (int j = 0; j < 5; j++)
						{
							if ( DataSocketFD[j] == 0)
							{
									DataSocketFD[j] = new_socket;
									printf("Adding to list of sockets as %d\n" , j);
									break;
							}
						}
					}

					else{ // active communication with a client 
#ifdef DEBUG
						printf("%s: Dealing with client %d...\n", Program, i);
#endif
						//HandleClient(i);
						for (int j = 0; j < 5; j++)
						{
							sd = DataSocketFD[j];
							if (FD_ISSET( sd, &ReadFDs))
							{
								HandleClient(i);
								if ((valread = read( sd, buffer, 1024)) == 0)
								{
									close (sd);
									DataSocketFD[j] = 0;
								}
							}
						

							else
							{
								buffer[valread] = '\0';
								send(sd, buffer, strlen(buffer), 0);
							}
						}
#ifdef DEBUG		
						printf("%s: CLosing client %d connection.\n", Program, i);
#endif
						//close(i);
						//FD_CLR(i, &ActiveFDs); // clears the bit for the file descriptor fd in teh file descriptor set fdset
					}
				}
			}
		}
    }
} /* end of ServerMainLoop */

/*** main function *******************************************************/

// main function 
int main(int argc, char *argv[]){
	int ServSocketFD; // socket file descriptor for service
	int PortNo; // port number

	Program = argv[0]; // publish program name (for diagnostics)

#ifdef DEBUG
	printf("%s: Starting...\n", Program);
#endif

	if (argc < 2){ 
		fprintf(stderr, "Usage: %s port\n", Program);
		exit(10);
	} // error is less than 2 arguments entered on command line

	PortNo = atoi(argv[1]); // get port number from command line argument (ascii to integer)

	if (PortNo <= 2000){
		fprintf(stderr, "%s: invalid port number %d, should be >2000\n", Program, PortNo);
		exit(10);
	} 

#ifdef DEBUG
	printf("%s: Creating the server socket...\n", Program);
#endif

	ServSocketFD = MakeServerSocket(PortNo);
	printf("%s: Providing current time at port %d...\n", Program, PortNo);
	ServerMainLoop(ServSocketFD, ProcessRequest, PrintCurrentTime, 250000);
	printf("\n%s: Shutting down.\n", Program);
	close(ServSocketFD);
	return 0;
}

/* EOF ClockServer.c */
