/*********************************************************************/
/* Data Structures                                                   */
/*                                                                   */
/* Authors: Onis Tripathi                                            */ 
/*          Christina Wong                                           */
/* Modifications:                                                    */
/* 05/09/21 CW  optimized settings menu and implemented custom board */
/* 05/08/21 CW  moved custom board function from Gameplay            */
/* 05/07/21 CW  GUI formatting for main/settings menu                */
/* 05/06/21 GF  added settings menu                                  */
/* 05/03/21 CW  adding typing effect to title texts                  */
/* 05/01/21 CW  fixed board presentaton and added color              */
/* 04/27/21 CW  fixed formatting and added color                     */
/* 04/25/21 CW  fixing make errors                                   */
/* 04/24/21 CW  added comments                                       */
/* 04/23/21 CW  created menu and wrote main (board and menu prints)  */
/* 04/23/21 OT  printed out the board                                */ 
/* 04/19/21 OT  initial version                                      */
/*********************************************************************/

#include "Chess.h"

// debugger tool
#define cat(x) # x
#define stringify(x) cat(x)
#define debugf(msg, ...) {\
    printf("\x1b[1;31mDEBUG [L " stringify(__LINE__) "]: " msg "\n\x1b[0m", ##__VA_ARGS__);\
}

// Handle Menu Options
int print_menu(){
    int select = 0;
    printf("1. Start New Game (Human v. Human)\n");
    printf("2. Start New Game (Human v. AI)\n");
    printf("3. Game Settings\n");
    printf("4. Exit Game\n");
    printf("\x1b[1;34mChoose Option:\x1b[0m ");
    scanf("%d",&select);
    getchar();
    
    while(select > 4){
        printf("\x1b[1;31mInvalid option!\x1b[0m Please choose another option: ");
        scanf("%d",&select);
        getchar();
    } 
    return select;
}

// Handle Login Menu Options
void printloginmenu(){
    printf("\n\x1b[1;34m***********************************\n");
    type("\x1b[1;34m     Welcome to Panda Chess!\x1b[0m", 0.075); 
    printf("\n\x1b[1;34m***********************************\x1b[0m\n");
    printf("1. Create New Account\n");
    printf("2. Login\n");
    printf("3. Exit\n");
    printf("\x1b[1;34mChoose Option:\x1b[0m ");
    fflush(stdout);
}

// Settings Menu 
int print_settings(){
    int select = 0;
    printf("1. Change colors\n");
    printf("2. Customize board\n");
    printf("3. Exit settings\n");
    printf("\x1b[36mChoose Option:\x1b[0m ");
    scanf("%d",&select);
    getchar();                              // clears the "\n" char from the input

    while(select > 3){
        printf("\x1b[1;31mInvalid option!\x1b[0m Please choose another option: ");
        scanf("%d",&select);
        getchar();
    } 
    return select;
}

// Handles Settings Options
void settings(char board[8][8], PLAYER *player1, PLAYER *player2){
    char changecolor;
    char piece; //what piece goes where in second for loop
    char col; 
    int row;

    int done = 0;
    while(!done){
        printf("\n\x1b[36m***********************************\x1b[0m\n");
        type("\x1b[36m   Welcome to the Settings Menu!\x1b[0m", 0.075);
        printf("\n\x1b[36m***********************************\x1b[0m\n");
        int setchoice = print_settings();
        
        switch(setchoice){
            // **************** CHANGE COLORS *****************
            case 1: 
                printf("\n\x1b[36mDefault Colors:\x1b[0m \n");
                printf("\tPlayer 1 : White \n");
                printf("\tPlayer 2 : Black\n");
                printf("\x1b[36mSwitch Colors? (Y or N):\x1b[0m ");
                scanf(" %c", &changecolor);
                //debugf("changecolor: %c\n player 1: %c\n player 2: %c\n", changecolor, player1->pcolor, player2->pcolor);
                if (changecolor == 'Y') {
                    player1->pcolor = 'b';
                    player2->pcolor = 'w';
                    printf("Changes made:\n");
                    printf("\tPlayer 1: Black\n");
                    printf("\tPLayer 2: White\n");
                }
                else 
                    printf("No changes were made\n");
                type("\nReturning to settings menu ", 0.025);
                type(".....\n", 0.3);
                break;
           
            // **************** CUSTOMIZABLE BOARD *****************
            case 2:
                printf("\nclearing board");
                type(".....\n", 0.3);
                for(int i = 0; i < 8; i++){
                    for(int j = 0; j < 8; j++){  
                        board[i][j] = ' ';
                    }
                }
        
                print_board(board); //print out blank board
                int count = 0; // used to check if input is first input (for cancellation)                

                for(int x = 0; x < 8; x++){
                    for(int y = 0; y < 8; y++){  
                        printf(" \x1b[36mp\x1b[0m for white pawn     \x1b[36mP\x1b[0m for black pawn\n");
                        printf(" \x1b[36mn\x1b[0m for white knight   \x1b[36mN\x1b[0m for black knight \n");
                        printf(" \x1b[36mb\x1b[0m for white bishop   \x1b[36mB\x1b[0m for black bishop \n");
                        printf(" \x1b[36mr\x1b[0m for white rook     \x1b[36mR\x1b[0m for black rook\n");
                        printf(" \x1b[36mq\x1b[0m for white queen    \x1b[36mQ\x1b[0m for black queen\n");
                        printf(" \x1b[36mk\x1b[0m for white king     \x1b[36mK\x1b[0m for black king \n");
                        printf("\nPress \x1b[1;34mx\x1b[0m to exit piece selection\n");
                        printf("To set back to default board, press \x1b[1;34md\x1b[0m\n");
                       
                        printf("\n\x1b[36mWhat piece would you like to add?\x1b[0m ");
                        scanf(" %c", &piece);
                        getchar();
                        
                        // input handling for piece               
                        while ((piece != 'p') && (piece != 'P') && (piece != 'n') && (piece != 'N') && 
                               (piece != 'b') && (piece != 'B') && (piece != 'r') && (piece != 'R') && 
                               (piece != 'q') && (piece != 'Q') && (piece != 'k') && (piece != 'K') && 
                               (piece != 'x') && (piece != 'd')){
                            printf("\x1b[1;4;31mInvalid choice!\x1b[0m \x1b[36mPlease choose another piece:\x1b[0m ");
                            scanf(" %c", &piece);
                            getchar();
                        }
                        
                        if(piece == 'x'){  //get out of loop and piece selection
                            if(count == 0){    // if x is 1st input, reset board to default (so that it's not an empty board)
                                for (int i = 0; i < 8; i++){
                                    for (int j = 0; j < 8; j++){
                                        if(i == 0){
                                            if (j == 0) board[i][j] = 'R';
                                            if (j == 1) board[i][j] = 'N';
                                            if (j == 2) board[i][j] = 'B';
                                            if (j == 3) board[i][j] = 'Q';
                                            if (j == 4) board[i][j] = 'K';
                                            if (j == 5) board[i][j] = 'B';
                                            if (j == 6) board[i][j] = 'N';
                                            if (j == 7) board[i][j] = 'R';
                                        }
                                        else if(i == 1) board[i][j] = 'P';
                                        else if(i < 6) board[i][j] = ' ';
                                        else if(i == 6) board[i][j] = 'p';
                                        else{
                                            if (j == 0) board[i][j] = 'r';
                                            if (j == 1) board[i][j] = 'n';
                                            if (j == 2) board[i][j] = 'b';
                                            if (j == 3) board[i][j] = 'q';
                                            if (j == 4) board[i][j] = 'k';
                                            if (j == 5) board[i][j] = 'b';
                                            if (j == 6) board[i][j] = 'n';
                                            if (j == 7) board[i][j] = 'r';
                                        }
                                    }
                                }
                                break;
                            }else
                                break;
                        }

                        if(piece == 'd'){   // set board back to default
                            for (int i = 0; i < 8; i++){
                                for (int j = 0; j < 8; j++){
                                    if(i == 0){
                                        if (j == 0) board[i][j] = 'R';
                                        if (j == 1) board[i][j] = 'N';
                                        if (j == 2) board[i][j] = 'B';
                                        if (j == 3) board[i][j] = 'Q';
                                        if (j == 4) board[i][j] = 'K';
                                        if (j == 5) board[i][j] = 'B';
                                        if (j == 6) board[i][j] = 'N';
                                        if (j == 7) board[i][j] = 'R';
                                    }
                                    else if(i == 1) board[i][j] = 'P';
                                    else if(i < 6) board[i][j] = ' ';
                                    else if(i == 6) board[i][j] = 'p';
                                    else{
                                        if (j == 0) board[i][j] = 'r';
                                        if (j == 1) board[i][j] = 'n';
                                        if (j == 2) board[i][j] = 'b';
                                        if (j == 3) board[i][j] = 'q';
                                        if (j == 4) board[i][j] = 'k';
                                        if (j == 5) board[i][j] = 'b';
                                        if (j == 6) board[i][j] = 'n';
                                        if (j == 7) board[i][j] = 'r';
                                    }
                                }
                            }
                            break;
                        }
                        


                        printf("\x1b[36mPlease pick the coordinate (i.e. A2):\x1b[0m ");
                        scanf(" %c%d", &col, &row);
                        getchar();
                        //debugf(" %d %d", col-65, 8-row);

                        int valid = 0; 
                        while (!valid){
                            // input handling for coordinate
                            while (((col - 65) > 8) || (row > 8)){
                                printf("\x1b[1;4;31mInvalid input!\x1b[0m \x1b[36mPlease pick a new coordinate:\x1b[0m ");
                                scanf(" %c%d", &col, &row);
                                getchar();
                                //debugf(" %d %d", col, row);
                            }
                            
                            if (board[(8 - row)][(col - 65)] == ' '){
                                board[(8 - row)][(col - 65)] = piece;
                                print_board(board);
                                valid = 1;
                            }else{
                                printf("\x1b[1;4;31mLocation already taken!\x1b[0m \x1b[36mPlease pick a new coordinate:\x1b[0m ");
                                scanf(" %c%d", &col, &row);
                                getchar();
                            }
                        } 
                        count++;
                    }
                    if(piece == 'x')  //get out of loop and piece selection
                        break;
                    else if(piece == 'd'){
                        printf("Board is now set back to default settings!\n");
                        break;
                    }
                }
                type("\nReturning to settings menu ", 0.025);
                type(".....\n", 0.3);  
                break;
            case 3:
                type("\nReturning to main menu ", 0.025);
                type(".....\n", 0.3); 
                done = 1;
                break;
        } 
    }
}

//Main function for Chess
int Chess(){  

    //initialize player default settings 
	PLAYER *player1 = NULL;
    PLAYER *player2 = NULL;
    player1 = CreatePlayer(1, 'w', 0);
    player2 = CreatePlayer(2, 'b', 0); 
	
    char board[8][8] = {{ 'R' , 'N' , 'B' , 'Q' , 'K' , 'B' , 'N' , 'R' },
                        { 'P' , 'P' , 'P' , 'P' , 'P' , 'P' , 'P' , 'P' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' },
                        { 'p' , 'p' , 'p' , 'p' , 'p' , 'p' , 'p' , 'p' },
                        { 'r' , 'n' , 'b' , 'q' , 'k' , 'b' , 'n' , 'r' }};

    int done=0;
    while(done==0){
        printf("\n\x1b[1;34m***********************************\n");
        type("\t\x1b[1;34mLet's Play!\x1b[0m", 0.075); 
        printf("\n\x1b[1;34m***********************************\x1b[0m\n");

	print_board(board);
//	HumanVsHuman(board, player1, player2);
/*        int option = print_menu();
        
        switch(option){
            case 1:
                HumanVsHuman(board, player1, player2);
                break;
            case 2:
                HumanVsAI(board,player1,player2);
                break;
            case 3:
                settings(board,player1,player2);
                break;
            case 4:
                type("\nThanks for playing! Exiting game ", 0.075);
                type(".....\n", 0.3);
                done = 1;
                break;
        }*/
    }
    return 0;
}

/* EOF */
