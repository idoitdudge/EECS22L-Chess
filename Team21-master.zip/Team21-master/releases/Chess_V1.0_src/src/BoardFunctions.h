/*********************************************************************/
/* BoardFunctions.h                                                  */
/* header file for board functions                                   */ 
/*                                                                   */
/* Authors: Christina Wong, Gianna F.                                */
/* Modifications:                                                    */
/* 04/30/21 GF 	Added HumanVsAI declaration			                 */
/* 04/25/21 CW  fixing make error                                    */
/* 04/25/21 GF  Added HumanVsHuman declaration                       */
/* 04/24/21 CW  initial version                                      */
/*********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "Board.h"

#ifndef BOARDFUNCTIONS_H
#define BOARDFUNCTIONS_H

//function prints the board out
void print_board(char board[8][8]);


// ********* GAMEPLAY **********
void HumanVsHuman(char board[8][8], PLAYER *player1, PLAYER *player2);

void HumanVsAI(char board[8][8], PLAYER *player1, PLAYER *player2);

void gamepoints(char board[8][8], int turn, int postmove1, int postmove2,  PLAYER *player1, PLAYER *player2);

// ********* TYPING EFFECT *********
int fib(int n);

void sleep(double seconds);

void type(char* str, double delay_seconds);

//void reset();

//void countdown();


//********* REPLAY **************
// prints replay if user wants it
void Replay (LIST *list, PLAYER *player1, PLAYER *player2, int ai, int win);

// prints board into file
void FPrintBoard(FILE *file, char board[8][8], PLAYER *player1, PLAYER *player2);

#endif
/* EOF */
