/* CLockClient.c: simple interactive TCP/IP client for CLockServer
 * includes comments and definitions
 */

#include <stdio.h> // standard input output functions
#include <stdlib.h> // standard library
#include <unistd.h> // defines miscellaneous symbolic constants & types and functions
#include <string.h> // functions to manipulate C strings and arrays
#include <netinet/in.h> // internet address/protocol family 
#include <netdb.h> // define the IPPORT_RESERVED macro with the value of the highest IP number

// global variables
const char *Program = NULL; // program name for descriptive diagnostics

// global functions 

void FatalError(const char *ErrorMsg){ // prints error diagnostics and abort
	// stderr = standard error message
	fputs(Program, stderr); // program name 
	fputs(": ", stderr); 
	perror(ErrorMsg); // error message (what's wrong)
	fputs(Program,stderr);
	fputs(": Exiting!\n", stderr);
	exit(20);
} // end of FatalError

int main (int argc, char *argvp[]){
	// argc = number of arguments put in by the user
	// pointer array which points to each argument passed to the program

	int l; // stores string length of input SendBuf
	int n; // stores return value of read() and write()
	int SocketFD; // socket file descriptor
	int PortNo; // port number

	struct sockaddr_in 
	ServerAddress; // server address we connect with

	struct hostent
	*Server; // server host

	char SendBuf[256]; // message buffer for sending a message
					   // stores input data in buffer
	char RecvBuf[256]; // message buffer for receiving a response
					   // stores output data in buffer

	Program = argv[0]; // publish program name (for diagnostics)
					   // almost always "./ClockClient"

#ifdef DEBUG
	printf("%s: Starting...\n", argv[0]);
#endif

	if (argc < 3){
		fprintf(stderr, "Usage: %s hostname port\n", Program);
		exit(10);
	} // checks if client put name of file, server, and port number

	// function is in <netdb.h>
	// gethostbyname() -- returns a structure of the type hostent for the given host name
	Server = gethostbyname(argv[1]); // looks at host server name (i.e. bondi)

	if (Server == NULL){
		fprintf(stderr, "%s: no such host named '%s'\n", Program, argv[1]);
		exit(10);
	} // checks for valid host server name

	// function is in <stdlib.h>
	// int atoi(const char *str) -- converts string argument to an integer
	PortNo = atoi(argv[2]); // looks at third argument on command line (i.e. 10100)

	if (PortNo <= 2000){
		fprintf(stderr, "%s: invalid port number %d, should be >2000\n", Program, PortNo);
		exit(10);
	} // checks for valid port number

	ServerAddress.sin_family = AF_INET; // connects server to internet domain
	// htons() -- converts the unsigned short integer from host byte order to network byte order
	// 		included in <netinet/in.h>
	ServerAddress.sin_port = htons(PortNo); // sets server address port to port number
	ServerAddress.sin_addr = *(struct in_addr*)Server->h_addr_list[0]; // sets server address to localhost (specified host server)

	do{
		printf("%s: Enter a comand to send to the clock server:\n"
		"			'TIME' to obtain the current time,\n"
		"			'SHUTDOWN' to terminate the server,\n"
		"			or 'bye' to quit this client\n"
		"command: ", argv[0]);

		fgets(SendBuf, sizeof(SendBuf), stdin); // takes in user command
		l = strlen(SendBuf); // stores length of buffer

		if (SendBuf[l-1] == '\n'){
			SendBuff[--l] = 0;
		} // set last character to \0 (NULL) (indicates end of string)

		if (0 == strcmp("bye", SendBuf)){
			break; 
		} // compares input string to bye; breaks out of do while if = 0 (S1 equal S2)

		if (1){
			// creating a socket file in the specified domain and of the specific type
			// socket(domain, type, protocol)
			SocketFD = socket(AF_INET, SOCK_STREAM, 0); 

			if(SocketFD < 0){
				FatalError("socket creation failed");
			} // upon fail, socket() returns a negative number

			printf("%s: Connecting to the server at port %d...\n", Program, PortNo);

			// connect(): connects socket to the address & port specified
			// 		success = return 0
			// 		fail = return -1
			if (connect(SocketFD, (struct sockaddr*)&ServerAddress, sizeof(ServerAddress)) < 0){
				FatalError("connecting to server failed");
			} 

			printf("%s: Sending message '%s'...\n", Program, SendBuf);
			n = write(SocketFD, SendBuf, l); // writes up the count bytes from the buffer to the file

			if (n < 0){
				FatalError("writing to socket failed");
			} 
			
#ifdef DEBUG
			printf("%s: Waiting for response...\n", Program);
#endif 
			n = read(SocketFD, RecvBuff, sizeof(RecvBuf)-1); // reading buffer of response

			if (n < 0){
				FatalError("reading from socket failed");
			}

			RecvBuf[n] = 0; // sets last character of buffer to NULL

			printf("%s: Received response: %s\n", Program, RecvBuf);

#ifdef DEBUG
			printf("%s: Closing the connection...\n", Program);
#endif
			close(SocketFD);
		}
	} while (0 != strcmp("SHUTDOWN", SendBuf));

	printf("%s: Exiting...\n", Program);
	return 0;
}
